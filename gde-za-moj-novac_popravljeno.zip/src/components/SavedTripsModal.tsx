import React from 'react';
import { TravelPackage } from '../types/travel';
import { EUR_TO_RSD_RATE } from '../services/travelApi';
import { X, Trash2, ArrowRight } from 'lucide-react';

interface SavedTripsModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedPackages: TravelPackage[];
  onRemove: (packageId: string) => void;
  onSelectPackage: (pkg: TravelPackage) => void;
  currency: 'EUR' | 'RSD';
}

export const SavedTripsModal: React.FC<SavedTripsModalProps> = ({
  isOpen,
  onClose,
  savedPackages,
  onRemove,
  onSelectPackage,
  currency,
}) => {
  if (!isOpen) return null;

  const formatPrice = (eur: number) => {
    if (currency === 'RSD') {
      return `${Math.round(eur * EUR_TO_RSD_RATE).toLocaleString()} RSD`;
    }
    return `${Math.round(eur)} €`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden border border-stone-200">
        <div className="p-6 border-b border-stone-200 flex items-center justify-between">
          <div>
            <h3 className="font-display font-bold text-xl text-stone-900">
              Moja sačuvana putovanja ({savedPackages.length})
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              Lista ponuda koje si sačuvao za kasnije poređenje
            </p>
          </div>
          <button
            onClick={onClose}
            className="cursor-pointer p-2 rounded-full hover:bg-stone-100 text-stone-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {savedPackages.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-sm text-stone-500">
                Još uvek nemaš sačuvanih putovanja. Klikni na ikonicu srca na bilo kojoj kartici da je sačuvaš.
              </p>
            </div>
          ) : (
            savedPackages.map((pkg) => (
              <div
                key={pkg.id}
                className="bg-stone-50 rounded-2xl p-4 border border-stone-200 flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-4">
                  <img
                    src={pkg.heroImage}
                    alt={pkg.destinationName}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 rounded-xl object-cover shrink-0"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=400&q=80';
                    }}
                  />
                  <div>
                    <h4 className="font-bold text-stone-900 text-sm">{pkg.title}</h4>
                    <p className="text-xs text-stone-500 mt-0.5">
                      {pkg.destinationName}, {pkg.country} · {pkg.defaultNights} noći
                    </p>
                    <div className="text-xs font-semibold text-stone-800 mt-1">
                      Početna cena:{' '}
                      <span className="text-amber-800 font-bold tabular-nums">
                        {formatPrice(
                          (pkg.transports[0]?.pricePerPersonEUR || 0) * 2 +
                            (pkg.accommodations[0]?.pricePerNightEUR || 0) * pkg.defaultNights
                        )}
                      </span>{' '}
                      (za 2 os.)
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      onSelectPackage(pkg);
                      onClose();
                    }}
                    className="cursor-pointer px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
                  >
                    <span>Pregledaj</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onRemove(pkg.id)}
                    className="cursor-pointer p-2 text-stone-400 hover:text-red-600 rounded-lg transition-colors"
                    title="Ukloni"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
