import React, { useState } from 'react';
import {
  BORDER_CROSSINGS_DATA,
  getStatusBadge,
} from '../services/borderApi';
import { BorderCountryCode, BorderCrossing } from '../types/border';
import {
  Car,
  Bus,
  Clock,
  Camera,
  Search,
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
  Lightbulb,
  Compass,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';

interface BorderWaitTimesSectionProps {
  onSelectDestination?: (destName: string) => void;
}

export const BorderWaitTimesSection: React.FC<BorderWaitTimesSectionProps> = ({
  onSelectDestination,
}) => {
  const [selectedCountry, setSelectedCountry] = useState<BorderCountryCode>('ALL');
  const [vehicleType, setVehicleType] = useState<'auto' | 'bus'>('auto');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter logic
  const filteredCrossings = BORDER_CROSSINGS_DATA.filter((b) => {
    // 1. Country filter
    if (selectedCountry !== 'ALL' && b.targetCountryCode !== selectedCountry) {
      return false;
    }
    // 2. Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = b.name.toLowerCase().includes(q);
      const matchCountry = b.targetCountryName.toLowerCase().includes(q);
      const matchNeighbor = b.neighborCrossingName?.toLowerCase().includes(q);
      const matchRoute = b.routeHint.toLowerCase().includes(q);
      if (!matchName && !matchCountry && !matchNeighbor && !matchRoute) {
        return false;
      }
    }
    return true;
  });

  const countryFilters: { id: BorderCountryCode; label: string; flag: string }[] = [
    { id: 'ALL', label: 'Svi prelazi', flag: '🌍' },
    { id: 'MK', label: 'S. Makedonija', flag: '🇲🇰' },
    { id: 'GR', label: 'Grčka (Evzoni)', flag: '🇬🇷' },
    { id: 'HU', label: 'Mađarska', flag: '🇭🇺' },
    { id: 'ME', label: 'Crna Gora', flag: '🇲🇪' },
    { id: 'BA', label: 'Bosna i Herc.', flag: '🇧🇦' },
    { id: 'HR', label: 'Hrvatska', flag: '🇭🇷' },
    { id: 'BG', label: 'Bugarska', flag: '🇧🇬' },
    { id: 'RO', label: 'Rumunija', flag: '🇷🇴' },
  ];

  return (
    <section
      id="granice-sekcija"
      className="py-16 sm:py-20 bg-stone-100/70 border-t border-stone-200"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-amber-900 bg-amber-100/80 px-3 py-1 rounded-md uppercase tracking-wider mb-3">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              <span>Okvirne vrednosti · proveri pre polaska</span>
            </div>
            <h2 className="font-display text-2xl sm:text-4xl font-bold text-stone-900 tracking-tight mb-2">
              Stanje na graničnim prelazima
            </h2>
            <p className="text-sm sm:text-base text-stone-600 leading-relaxed">
              Planiraš put sopstvenim automobilom ili autobusom? Pogledaj okvirno vreme čekanja na
              glavnim prelazima Srbije i regiona i otkrij brže alternativne prelaze. Brojevi su
              orijentacioni i ne ažuriraju se automatski, pa pre polaska proveri kamere uživo i
              AMSS.
            </p>
          </div>

          {/* Provera uživo (podaci iznad su orijentacioni) */}
          <div className="flex items-center gap-3 shrink-0">
            <a
              href="https://kamere.amss.org.rs/"
              target="_blank"
              rel="noopener noreferrer"
              className="cursor-pointer px-3.5 py-2 bg-white hover:bg-stone-50 text-stone-800 border border-stone-300 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 shadow-sm"
            >
              <Camera className="w-3.5 h-3.5 text-stone-600" />
              <span>AMSS kamere uživo</span>
            </a>
          </div>
        </div>

        {/* Quick Summary Pill Bar */}
        <div className="bg-white rounded-2xl p-4 border border-stone-200/80 shadow-sm mb-8 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 text-stone-700">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              <strong>Savet za putnike:</strong> Za Mađarsku biraj <strong>Kelebiju</strong> ili <strong>Bačke Vinograde</strong> umesto Horgoša I.
              Za Grčku/Makedoniju proveri <strong>Prohor Pčinjski</strong> i <strong>Dojran</strong>.
            </span>
          </div>
          <div className="flex items-center gap-3 text-stone-500 text-[11px]">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500" /> Prohodno (do 20 min)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-500" /> Umereno (20-45 min)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-rose-500" /> Gužva (45+ min)
            </span>
          </div>
        </div>

        {/* Filter Controls: Countries & Vehicle Type & Search */}
        <div className="space-y-4 mb-8">
          {/* Country Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {countryFilters.map((tab) => {
              const isSelected = selectedCountry === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setSelectedCountry(tab.id)}
                  className={`cursor-pointer px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-stone-900 text-white shadow-sm ring-1 ring-stone-900'
                      : 'bg-white text-stone-700 hover:bg-stone-50 border border-stone-200'
                  }`}
                >
                  <span>{tab.flag}</span>
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Sub Controls: Vehicle Type + Search Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            {/* Vehicle Mode Switcher */}
            <div className="inline-flex items-center p-1 bg-stone-200/80 rounded-xl">
              <button
                onClick={() => setVehicleType('auto')}
                className={`cursor-pointer px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                  vehicleType === 'auto'
                    ? 'bg-white text-stone-900 shadow-sm'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <Car className="w-3.5 h-3.5 text-amber-700" />
                <span>Putnički automobili</span>
              </button>
              <button
                onClick={() => setVehicleType('bus')}
                className={`cursor-pointer px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                  vehicleType === 'bus'
                    ? 'bg-white text-stone-900 shadow-sm'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <Bus className="w-3.5 h-3.5 text-amber-700" />
                <span>Autobusi (Turistički)</span>
              </button>
            </div>

            {/* Quick Search Input */}
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Pretraži prelaz (npr. Horgoš, Preševo, Gostun)..."
                className="w-full pl-9 pr-3 py-2 bg-white border border-stone-300 rounded-xl text-xs text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-600/30 focus:border-amber-600"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-600"
                >
                  ✕
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Border Crossings Cards Grid */}
        {filteredCrossings.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center border border-stone-200">
            <AlertTriangle className="w-8 h-8 text-amber-600 mx-auto mb-2" />
            <h4 className="font-bold text-stone-900 text-sm mb-1">
              Nema graničnih prelaza za uneti filter
            </h4>
            <p className="text-xs text-stone-500 mb-4">
              Pokušaj sa drugim nazivom ili izaberi tab „Svi prelazi“.
            </p>
            <button
              onClick={() => {
                setSelectedCountry('ALL');
                setSearchQuery('');
              }}
              className="cursor-pointer px-4 py-2 bg-stone-900 text-white rounded-xl text-xs font-semibold"
            >
              Resetuj filtere
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredCrossings.map((b) => {
              const waitExit =
                vehicleType === 'auto' ? b.waitPassengerExitMin : b.waitBusExitMin;
              const waitEntry =
                vehicleType === 'auto' ? b.waitPassengerEntryMin : b.waitBusEntryMin;
              const badge = getStatusBadge(b.status);

              return (
                <div
                  key={b.id}
                  className="bg-white rounded-2xl border border-stone-200/90 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    {/* Top Header: Flag, Name, Route */}
                    <div className="flex items-start justify-between gap-3 mb-2.5">
                      <div>
                        <div className="flex items-center gap-1.5 text-xs text-stone-500 font-medium mb-1">
                          <span className="text-base">{b.flagEmoji}</span>
                          <span>{b.countryPair}</span>
                          {b.isIntegratedControl && (
                            <span className="text-[10px] bg-sky-50 text-sky-800 font-bold px-1.5 py-0.2 rounded border border-sky-200">
                              One-Stop
                            </span>
                          )}
                        </div>
                        <h3 className="font-display font-bold text-base text-stone-900 leading-snug">
                          {b.name}
                        </h3>
                        {b.neighborCrossingName && (
                          <span className="text-[11px] text-stone-400 block">
                            Granični par: {b.neighborCrossingName}
                          </span>
                        )}
                      </div>

                      {/* Status indicator pill */}
                      <span
                        className={`text-[10px] font-bold px-2.5 py-1 rounded-full border shrink-0 flex items-center gap-1 ${badge.bgClass} ${badge.textClass} ${badge.borderClass}`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${badge.dotColor}`} />
                        <span>{badge.label.split(' ')[0]}</span>
                      </span>
                    </div>

                    <p className="text-[11px] text-stone-500 leading-relaxed mb-4">
                      {b.routeHint}
                    </p>

                    {/* Wait Times Dual Card */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      {/* Exit from Serbia */}
                      <div className="bg-stone-50 p-3 rounded-xl border border-stone-200/70 text-center">
                        <span className="text-[10px] text-stone-500 font-semibold uppercase tracking-wider block mb-0.5">
                          Izlaz iz Srbije
                        </span>
                        <div className="flex items-center justify-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-stone-400" />
                          <span
                            className={`font-display text-xl font-bold tabular-nums ${
                              waitExit > 45
                                ? 'text-rose-600'
                                : waitExit > 20
                                ? 'text-amber-600'
                                : 'text-emerald-700'
                            }`}
                          >
                            ~{waitExit} min
                          </span>
                        </div>
                        <span className="text-[10px] text-stone-400 block mt-0.5">
                          {vehicleType === 'auto' ? 'Automobili' : 'Autobusi'}
                        </span>
                      </div>

                      {/* Entry to Serbia */}
                      <div className="bg-stone-50 p-3 rounded-xl border border-stone-200/70 text-center">
                        <span className="text-[10px] text-stone-500 font-semibold uppercase tracking-wider block mb-0.5">
                          Ulaz u Srbiju
                        </span>
                        <div className="flex items-center justify-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-stone-400" />
                          <span
                            className={`font-display text-xl font-bold tabular-nums ${
                              waitEntry > 45
                                ? 'text-rose-600'
                                : waitEntry > 20
                                ? 'text-amber-600'
                                : 'text-emerald-700'
                            }`}
                          >
                            ~{waitEntry} min
                          </span>
                        </div>
                        <span className="text-[10px] text-stone-400 block mt-0.5">
                          {vehicleType === 'auto' ? 'Automobili' : 'Autobusi'}
                        </span>
                      </div>
                    </div>

                    {/* Recommended Alternative Banner (if present) */}
                    {b.alternative && (
                      <div className="bg-emerald-50/70 rounded-xl p-3 border border-emerald-200/70 text-xs mb-3 space-y-1">
                        <div className="flex items-center gap-1.5 font-bold text-emerald-950 text-[11px]">
                          <Lightbulb className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>Brža alternativa: {b.alternative.name} (~{b.alternative.waitMinutes} min)</span>
                        </div>
                        <p className="text-[11px] text-emerald-900/80 leading-normal">
                          {b.alternative.note}
                        </p>
                      </div>
                    )}

                    {/* Advisory Note */}
                    {b.advisoryNote && (
                      <div className="text-[11px] text-stone-600 bg-stone-50 px-2.5 py-1.5 rounded-lg border border-stone-200/60 mb-3">
                        ℹ️ {b.advisoryNote}
                      </div>
                    )}
                  </div>

                  {/* Card Bottom Meta & Actions */}
                  <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-[11px]">
                    <span className="text-stone-400">
                      Radno vreme: <strong>{b.workingHours}</strong>
                    </span>

                    {/* Camera Link Button */}
                    {b.hasCamera && (
                      <a
                        href={b.cameraUrl || 'https://kamere.amss.org.rs/'}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-amber-800 hover:text-amber-950 font-bold hover:underline"
                        title="Pogledaj AMSS kamere uživo za ovaj prelaz"
                      >
                        <Camera className="w-3.5 h-3.5 text-amber-600" />
                        <span>Kamere uživo</span>
                        <ExternalLink className="w-3 h-3 text-stone-400" />
                      </a>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
