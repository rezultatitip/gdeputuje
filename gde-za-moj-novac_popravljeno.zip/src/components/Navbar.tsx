import React from 'react';
import { Compass, Heart, Layers, Sparkles, TrendingDown, Clock } from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  currency: 'EUR' | 'RSD';
  onToggleCurrency: () => void;
  savedCount: number;
  onOpenSaved: () => void;
  onOpenApiModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  currency,
  onToggleCurrency,
  savedCount,
  onOpenSaved,
  onOpenApiModal,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => onSelectTab('pretraga')}
          className="text-left group cursor-pointer focus-visible:outline-none"
        >
          <span className="font-display font-bold text-xl tracking-tight text-stone-900 group-hover:text-amber-800 transition-colors whitespace-nowrap shrink-0">
            Gde za moj novac?
          </span>
        </button>

        {/* Zone 2: 4–5 single-line clean text navigation links */}
        <nav className="hidden md:flex items-center gap-5 text-sm font-medium text-stone-600">
          <button
            onClick={() => onSelectTab('pretraga')}
            className={`cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
              currentTab === 'pretraga' ? 'text-amber-900 font-semibold' : 'hover:text-stone-900'
            }`}
          >
            Istraži po budžetu
          </button>

          <button
            onClick={() => onSelectTab('za-150')}
            className={`cursor-pointer transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              currentTab === 'za-150' ? 'text-amber-900 font-semibold' : 'hover:text-stone-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Za 150 €</span>
          </button>

          <button
            onClick={() => onSelectTab('mapa')}
            className={`cursor-pointer transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              currentTab === 'mapa' ? 'text-amber-900 font-semibold' : 'hover:text-stone-900'
            }`}
          >
            <Compass className="w-3.5 h-3.5 text-amber-600" />
            <span>Mapa budžeta</span>
          </button>

          <button
            onClick={() => onSelectTab('granice')}
            className={`cursor-pointer transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              currentTab === 'granice' ? 'text-amber-900 font-semibold' : 'hover:text-stone-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>Granice uživo</span>
          </button>

          <button
            onClick={() => onSelectTab('usteda-agencije')}
            className={`cursor-pointer transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              currentTab === 'usteda-agencije' ? 'text-amber-900 font-semibold' : 'hover:text-stone-900'
            }`}
          >
            <TrendingDown className="w-3.5 h-3.5 text-emerald-600" />
            <span>Ušteda vs Agencije</span>
          </button>

          <button
            onClick={() => onSelectTab('kategorije')}
            className={`cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
              currentTab === 'kategorije' ? 'text-amber-900 font-semibold' : 'hover:text-stone-900'
            }`}
          >
            Banje, Planine & More
          </button>

          <button
            onClick={() => onSelectTab('prevoz-smestaj')}
            className={`cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
              currentTab === 'prevoz-smestaj' ? 'text-amber-900 font-semibold' : 'hover:text-stone-900'
            }`}
          >
            Avion, Bus & Smeštaj
          </button>

          <button
            onClick={onOpenApiModal}
            className="cursor-pointer text-stone-500 hover:text-stone-800 text-xs font-normal whitespace-nowrap shrink-0 flex items-center gap-1"
            title="Arhitektura za integraciju sa avio, bus i booking API servisima"
          >
            <Layers className="w-3.5 h-3.5 text-stone-400" />
            <span>API Arhitektura</span>
          </button>
        </nav>

        {/* Zone 3: 1 primary action cluster */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Currency Toggle */}
          <button
            onClick={onToggleCurrency}
            className="cursor-pointer px-2.5 py-1 text-xs font-semibold rounded border border-stone-200 bg-stone-50 text-stone-700 hover:bg-stone-100 transition-colors whitespace-nowrap"
            title="Promeni valutu prikaza"
          >
            {currency === 'EUR' ? 'EUR (€)' : 'RSD (din)'}
          </button>

          {/* Saved Wishlist */}
          <button
            onClick={onOpenSaved}
            className="cursor-pointer relative p-2 text-stone-600 hover:text-stone-900 transition-colors"
            title="Sačuvana putovanja"
            aria-label="Sačuvana putovanja"
          >
            <Heart className="w-5 h-5" />
            {savedCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-amber-700 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {savedCount}
              </span>
            )}
          </button>

          {/* Primary CTA */}
          <button
            onClick={() => onSelectTab('pretraga')}
            className="cursor-pointer px-4 py-2 text-xs font-semibold text-white bg-stone-900 rounded-lg hover:bg-stone-800 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-sm"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Pronađi put</span>
          </button>
        </div>
      </div>
    </header>
  );
};
