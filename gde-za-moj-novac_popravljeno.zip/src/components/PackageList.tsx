import React from 'react';
import { TravelPackage, SearchFilters } from '../types/travel';
import { PackageCard } from './PackageCard';
import { SlidersHorizontal, RotateCcw } from 'lucide-react';

interface PackageListProps {
  packages: TravelPackage[];
  filters: SearchFilters;
  onFilterChange: <K extends keyof SearchFilters>(key: K, value: SearchFilters[K]) => void;
  onResetFilters: () => void;
  savedIds: Set<string>;
  onToggleSave: (pkg: TravelPackage) => void;
  onOpenDetails: (pkg: TravelPackage) => void;
}

export const PackageList: React.FC<PackageListProps> = ({
  packages,
  filters,
  onFilterChange,
  onResetFilters,
  savedIds,
  onToggleSave,
  onOpenDetails,
}) => {
  return (
    <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="rezultati-pretrage">
      {/* Control bar: Title, Count, Sort dropdown */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-stone-200 mb-8">
        <div>
          <h2 className="font-display text-2xl font-bold text-stone-900 tracking-tight">
            Pronađena putovanja u tvom budžetu
          </h2>
          <p className="text-xs text-stone-500 mt-1">
            Prikazano <span className="font-semibold text-stone-800 tabular-nums">{packages.length}</span> opcija{' '}
            {filters.originCity !== 'Svi gradovi' ? `sa polaskom iz ${filters.originCity}` : 'iz svih gradova'} · do {filters.maxBudgetEUR} €
          </p>
        </div>

        {/* Sort & Filter utilities */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-white border border-stone-200 rounded-lg px-3 py-1.5 text-xs text-stone-700 shadow-sm">
            <SlidersHorizontal className="w-3.5 h-3.5 text-stone-500" />
            <span className="font-medium text-stone-500">Sortiraj:</span>
            <select
              value={filters.sortBy}
              onChange={(e) => onFilterChange('sortBy', e.target.value as SearchFilters['sortBy'])}
              className="bg-transparent font-medium text-stone-800 focus:outline-none cursor-pointer"
            >
              <option value="price_asc">Najniža ukupna cena</option>
              <option value="budget_fit">Najbolje uklopljeno u budžet</option>
              <option value="savings_desc">Najveći preostali džeparac</option>
              <option value="rating">Najbolje ocenjen smeštaj</option>
            </select>
          </div>

          <button
            onClick={onResetFilters}
            className="cursor-pointer p-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-lg transition-colors"
            title="Resetuj filtere"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Package Grid or Empty State */}
      {packages.length === 0 ? (
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center max-w-xl mx-auto shadow-sm">
          <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-700 flex items-center justify-center mx-auto mb-4 font-bold text-lg">
            !
          </div>
          <h3 className="font-display text-lg font-bold text-stone-900 mb-2">
            Nema pronađenih putovanja za zadate filtere
          </h3>
          <p className="text-sm text-stone-600 mb-6 leading-relaxed">
            Pokušaj da povećaš budžet za 30–50 €, izabereš „Sve destinacije“ ili promeniš mesto polaska.
          </p>
          <button
            onClick={onResetFilters}
            className="cursor-pointer px-5 py-2.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-xl transition-colors"
          >
            Resetuj sve filtere
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {packages.map((pkg) => (
            <PackageCard
              key={pkg.id}
              pkg={pkg}
              filters={filters}
              isSaved={savedIds.has(pkg.id)}
              onToggleSave={onToggleSave}
              onOpenDetails={onOpenDetails}
            />
          ))}
        </div>
      )}
    </section>
  );
};
