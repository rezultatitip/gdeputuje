import React from 'react';
import { DestinationCategory, TripDurationType } from '../types/travel';
import { IMAGES } from '../services/travelApi';
import { Sparkles, ArrowRight } from 'lucide-react';

interface CategoriesShowcaseProps {
  onSelectCategory: (cat: DestinationCategory) => void;
  onSelectDuration: (dur: TripDurationType) => void;
}

export const CategoriesShowcase: React.FC<CategoriesShowcaseProps> = ({
  onSelectCategory,
  onSelectDuration,
}) => {
  const categories = [
    {
      id: 'banje' as DestinationCategory,
      title: 'Banje i Termalni Spa',
      subtitle: 'Vrnjačka Banja, Sokobanja, Koviljača',
      image: IMAGES.hero,
      tag: 'Odmor & Zdravlje',
      priceFrom: 'od 28 €/noć',
    },
    {
      id: 'planine' as DestinationCategory,
      title: 'Planine i Brvnare',
      subtitle: 'Tara, Zlatibor, Kopaonik, Durmitor',
      image: IMAGES.tara,
      tag: 'Svež vazduh & Priroda',
      priceFrom: 'od 25 €/noć',
    },
    {
      id: 'more' as DestinationCategory,
      title: 'Morska obala & Egej',
      subtitle: 'Boka Kotorska, Budva, Solun, Halkidiki',
      image: IMAGES.kotor,
      tag: 'Sunce & Miris mora',
      priceFrom: 'od 32 €/noć',
    },
    {
      id: 'jezera' as DestinationCategory,
      title: 'Jezera i Odmor uz vodu',
      subtitle: 'Ohridsko jezero, Palić, Zaovine',
      image: IMAGES.ohrid,
      tag: 'Mir & Romantika',
      priceFrom: 'od 22 €/noć',
    },
  ];

  return (
    <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="kategorije-sekcija">
      {/* Quick Vacation Styles Strip (Vikend, Last Minute, Kratki odmor) */}
      <div className="mb-10 bg-gradient-to-r from-stone-900 to-stone-800 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Kratki odmori i vikend aranžmani</span>
          </div>
          <h3 className="font-display text-xl sm:text-2xl font-bold">
            Nemaš mnogo slobodnih dana? Putuj za vikend!
          </h3>
          <p className="text-xs sm:text-sm text-stone-300 mt-1 max-w-xl">
            Odaberi format odmora i pronađi najpovoljniji prevoz i smeštaj koji se savršeno uklapaju u slobodne dane.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <button
            onClick={() => onSelectDuration('vikend')}
            className="cursor-pointer px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 border border-white/10"
          >
            <span>Vikend (2 noći)</span>
            <ArrowRight className="w-3 h-3 text-amber-400" />
          </button>
          <button
            onClick={() => onSelectDuration('last_minute')}
            className="cursor-pointer px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Last Minute ponude</span>
          </button>
          <button
            onClick={() => onSelectDuration('kratki')}
            className="cursor-pointer px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 border border-white/10"
          >
            <span>Kratak odmor (3–4 noći)</span>
            <ArrowRight className="w-3 h-3 text-amber-400" />
          </button>
        </div>
      </div>

      {/* 4 Thematic Category Cards */}
      <div className="mb-6">
        <h2 className="font-display text-2xl font-bold text-stone-900 tracking-tight">
          Destinacije po tipu odmora
        </h2>
        <p className="text-xs text-stone-500 mt-1">
          Istraži omiljene regije u Srbiji i komšiluku sa dokazano najpovoljnijim cenama.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((cat) => (
          <div
            key={cat.id}
            onClick={() => onSelectCategory(cat.id)}
            className="cursor-pointer group relative rounded-2xl overflow-hidden bg-stone-900 h-72 shadow-sm hover:shadow-lg transition-all"
          >
            <img
              src={cat.image}
              alt={cat.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-60"
              onError={(e) => {
                (e.target as HTMLImageElement).src =
                  'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80';
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent" />

            <div className="absolute top-3 left-3 text-[11px] font-semibold text-amber-300 bg-black/40 backdrop-blur-sm px-2.5 py-0.5 rounded">
              {cat.tag}
            </div>

            <div className="absolute bottom-4 left-4 right-4 text-white">
              <span className="text-[11px] text-stone-300 font-medium block mb-0.5">
                {cat.priceFrom}
              </span>
              <h3 className="font-display font-bold text-lg leading-tight group-hover:text-amber-300 transition-colors">
                {cat.title}
              </h3>
              <p className="text-xs text-stone-300 mt-1 line-clamp-1">
                {cat.subtitle}
              </p>

              <div className="mt-3 flex items-center gap-1 text-xs font-semibold text-amber-400 opacity-0 group-hover:opacity-100 transition-opacity">
                <span>Prikaži ponude</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
