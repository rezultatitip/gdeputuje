import React, { useState, useEffect } from 'react';
import { TravelPackage, SearchFilters } from '../types/travel';
import { calculateTripFinancials, EUR_TO_RSD_RATE } from '../services/travelApi';
import { getLiveWeather, LiveWeatherInfo } from '../services/liveApis';
import { Heart, Bus, Plane, Car, Star, CheckCircle2, AlertCircle, TrendingDown } from 'lucide-react';

interface PackageCardProps {
  pkg: TravelPackage;
  filters: SearchFilters;
  isSaved: boolean;
  onToggleSave: (pkg: TravelPackage) => void;
  onOpenDetails: (pkg: TravelPackage) => void;
}

export const PackageCard: React.FC<PackageCardProps> = ({
  pkg,
  filters,
  isSaved,
  onToggleSave,
  onOpenDetails,
}) => {
  const [weather, setWeather] = useState<LiveWeatherInfo | null>(null);

  useEffect(() => {
    let isMounted = true;
    if (pkg.coordinates) {
      getLiveWeather(pkg.coordinates.lat, pkg.coordinates.lng).then((res) => {
        if (isMounted && res) {
          setWeather(res);
        }
      });
    }
    return () => {
      isMounted = false;
    };
  }, [pkg.coordinates]);
  const fin = calculateTripFinancials(
    pkg,
    undefined,
    undefined,
    pkg.defaultNights,
    filters.persons,
    filters.maxBudgetEUR,
    filters.originCity
  );

  const formatPrice = (eur: number) => {
    if (filters.currency === 'RSD') {
      return `${Math.round(eur * EUR_TO_RSD_RATE).toLocaleString()} RSD`;
    }
    return `${Math.round(eur)} €`;
  };

  const getTransportIcon = (type: string) => {
    if (type === 'flight') return <Plane className="w-4 h-4 text-sky-600" />;
    if (type === 'car') return <Car className="w-4 h-4 text-stone-600" />;
    return <Bus className="w-4 h-4 text-amber-600" />;
  };

  const getCategoryLabel = (cat: string) => {
    switch (cat) {
      case 'banje':
        return 'Banje i Spa';
      case 'jezera':
        return 'Jezero';
      case 'planine':
        return 'Planina';
      case 'more':
        return 'More i obala';
      case 'gradovi':
        return 'City Break';
      default:
        return cat;
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-stone-200 shadow-sm hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group">
      {/* Top Image Preview */}
      <div className="relative h-52 overflow-hidden bg-stone-100">
        <img
          src={pkg.heroImage}
          alt={pkg.destinationName}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=800&q=80';
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-950/20 to-transparent" />

        {/* Top Floating Tags */}
        <div className="absolute top-3 inset-x-3 flex items-center justify-between">
          <div className="text-[11px] font-semibold text-white drop-shadow flex items-center gap-1.5 bg-black/40 backdrop-blur-sm px-2.5 py-1 rounded-md">
            <span>{pkg.destinationName}</span>
            <span aria-hidden="true">·</span>
            <span>{pkg.country}</span>
            {weather && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-amber-300 font-bold flex items-center gap-1" title={`Trenutno: ${weather.conditionText}`}>
                  <span>{weather.icon}</span>
                  <span>{weather.temperature}°C</span>
                </span>
              </>
            )}
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleSave(pkg);
            }}
            className={`cursor-pointer p-2 rounded-full backdrop-blur-md transition-colors ${
              isSaved
                ? 'bg-red-500 text-white'
                : 'bg-white/80 text-stone-700 hover:bg-white hover:text-red-500'
            }`}
            aria-label={isSaved ? 'Ukloni iz omiljenih' : 'Dodaj u omiljene'}
          >
            <Heart className="w-4 h-4 fill-current" />
          </button>
        </div>

        {/* Bottom Image Overlay Title */}
        <div className="absolute bottom-3 inset-x-3 text-white">
          <div className="text-xs text-amber-300 font-medium mb-0.5">
            {getCategoryLabel(pkg.category)} · {pkg.defaultNights} noćenja
          </div>
          <h3 className="font-display font-bold text-lg leading-tight drop-shadow-sm">
            {pkg.title}
          </h3>
        </div>
      </div>

      {/* Middle: Details & Features */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        {/* Unboxed Metadata & Transport Specs */}
        <div className="space-y-3">
          {/* Transport summary */}
          <div className="flex items-start gap-2.5 text-xs text-stone-700 pb-2.5 border-b border-stone-100">
            <div className="mt-0.5">{getTransportIcon(fin.transport.type)}</div>
            <div>
              <div className="font-medium text-stone-900">
                {fin.transport.provider} ({fin.transport.originCity} → {fin.transport.destinationCity})
              </div>
              <div className="text-stone-500 text-[11px] mt-0.5">
                {fin.transport.durationHours}h vožnje · {fin.transport.baggageNote}
              </div>
              {fin.advisoryNote && (
                <div className="text-[10px] text-amber-800 bg-amber-50 px-2 py-0.5 rounded mt-1">
                  🚗 {fin.advisoryNote}
                </div>
              )}
            </div>
          </div>

          {/* Accommodation summary */}
          <div className="flex items-start gap-2.5 text-xs text-stone-700 pb-2.5 border-b border-stone-100">
            <div className="mt-0.5">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
            </div>
            <div>
              <div className="font-medium text-stone-900 flex items-center gap-1.5">
                <span>{fin.accommodation.name}</span>
                <span className="text-amber-800 font-bold bg-amber-50 px-1.5 py-0.2 rounded text-[10px]">
                  {fin.accommodation.rating}
                </span>
              </div>
              <div className="text-stone-500 text-[11px] mt-0.5">
                {fin.accommodation.roomType} · {fin.accommodation.locationDescription}
              </div>
            </div>
          </div>

          {/* Highlights checklist */}
          <div className="flex flex-wrap gap-1.5 pt-1">
            {pkg.highlights.slice(0, 3).map((h, i) => (
              <span
                key={i}
                className="text-[11px] text-stone-600 bg-stone-100 px-2 py-0.5 rounded"
              >
                {h}
              </span>
            ))}
          </div>
        </div>

        {/* Pricing Box & CTA */}
        <div className="pt-3 border-t border-stone-100">
          <div className="flex items-end justify-between mb-3">
            <div>
              <span className="text-[11px] text-stone-500 block">
                Ukupno ({filters.persons} {filters.persons === 1 ? 'osoba' : 'osobe'} / {pkg.defaultNights} noći):
              </span>
              <div className="flex items-baseline gap-1.5">
                <span className="font-display text-2xl font-bold text-stone-900 tabular-nums">
                  {formatPrice(fin.totalBaseCostEUR)}
                </span>
                {filters.persons > 1 && (
                  <span className="text-xs text-stone-500 tabular-nums">
                    ({formatPrice(fin.costPerPersonEUR)} / os.)
                  </span>
                )}
              </div>
            </div>

            {/* Budget status badge */}
            <div className="text-right">
              {fin.isWithinBudget ? (
                <div className="flex items-center gap-1 text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-1 rounded-md">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Ostaje {formatPrice(fin.remainingBudgetEUR)}</span>
                </div>
              ) : (
                <div className="flex items-center gap-1 text-[11px] text-amber-700 font-medium bg-amber-50 px-2 py-1 rounded-md">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>+{formatPrice(Math.abs(fin.remainingBudgetEUR))} iznad</span>
                </div>
              )}
            </div>
          </div>

          {/* Agency Savings Comparison */}
          {fin.savingsEUR > 0 && (
            <div className="flex items-center justify-between text-[11px] bg-emerald-50/70 border border-emerald-200/70 text-emerald-950 px-2.5 py-1.5 rounded-lg mb-3">
              <span className="flex items-center gap-1 font-medium text-stone-600">
                <TrendingDown className="w-3.5 h-3.5 text-emerald-600" />
                Agencija: <span className="line-through text-stone-400 font-normal">{formatPrice(fin.totalAgencyCostEUR)}</span>
              </span>
              <span className="font-bold text-emerald-700">
                Štediš {formatPrice(fin.savingsEUR)} (-{fin.savingsPercentage}%)
              </span>
            </div>
          )}

          <button
            type="button"
            onClick={() => onOpenDetails(pkg)}
            className="cursor-pointer w-full py-2.5 px-4 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 shadow-sm"
          >
            <span>Prilagodi prevoz & rezerviši</span>
            <span>→</span>
          </button>
        </div>
      </div>
    </div>
  );
};
