import React, { useState } from 'react';
import { getQuickBudgetHighlights, EUR_TO_RSD_RATE } from '../services/travelApi';
import { TravelPackage } from '../types/travel';
import { Sparkles, ArrowRight, Bus, Plane, Car, Check } from 'lucide-react';

interface Quick150FeatureProps {
  currency: 'EUR' | 'RSD';
  onSelectPackage: (pkg: TravelPackage) => void;
  originCity?: string;
}

const BUDGET_TIERS = [100, 150, 200, 250, 300];

export const Quick150Feature: React.FC<Quick150FeatureProps> = ({
  currency,
  onSelectPackage,
  originCity = 'Beograd',
}) => {
  const [activeBudget, setActiveBudget] = useState<number>(150);
  const [persons, setPersons] = useState<number>(1);

  const matchedTrips = getQuickBudgetHighlights(activeBudget, persons, originCity);

  const formatPrice = (eur: number) => {
    if (currency === 'RSD') {
      return `${Math.round(eur * EUR_TO_RSD_RATE).toLocaleString()} RSD`;
    }
    return `${Math.round(eur)} €`;
  };

  const getTransportIcon = (type: string) => {
    if (type === 'flight') return <Plane className="w-3.5 h-3.5 text-sky-600" />;
    if (type === 'car') return <Car className="w-3.5 h-3.5 text-stone-600" />;
    return <Bus className="w-3.5 h-3.5 text-amber-600" />;
  };

  return (
    <section className="py-12 bg-stone-100/70 border-b border-stone-200" id="za-150-sekcija">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-800 uppercase tracking-wider mb-2">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <span>Glavna funkcija platforme</span>
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-stone-900 tracking-tight">
              „Gde mogu da otputujem za {activeBudget} €?“
            </h2>
            <p className="text-sm text-stone-600 mt-1 max-w-xl">
              Kompletan proračun sa povratnim prevozom i proverenim smeštajem. Pogledaj tačno
              koliko trošiš i koliko ti novca ostaje za provod i hranu.
            </p>
          </div>

          {/* Quick Selectors */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-stone-500 mr-1">Izaberi budžet:</span>
            {BUDGET_TIERS.map((tier) => (
              <button
                key={tier}
                onClick={() => setActiveBudget(tier)}
                className={`cursor-pointer px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                  activeBudget === tier
                    ? 'bg-amber-600 text-white shadow-sm ring-2 ring-amber-600/30'
                    : 'bg-white border border-stone-300 text-stone-700 hover:bg-stone-50'
                }`}
              >
                {tier} €
              </button>
            ))}

            {/* Persons switch */}
            <div className="flex items-center gap-1 bg-white border border-stone-300 rounded-lg p-1 ml-2">
              <button
                onClick={() => setPersons(1)}
                className={`cursor-pointer px-2 py-0.5 text-xs font-medium rounded transition-colors ${
                  persons === 1 ? 'bg-stone-900 text-white' : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                1 osoba
              </button>
              <button
                onClick={() => setPersons(2)}
                className={`cursor-pointer px-2 py-0.5 text-xs font-medium rounded transition-colors ${
                  persons === 2 ? 'bg-stone-900 text-white' : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                2 osobe
              </button>
            </div>
          </div>
        </div>

        {/* Results Grid */}
        {matchedTrips.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center border border-stone-200">
            <p className="text-stone-600 text-sm">
              Za budžet od {activeBudget} € za {persons} putnika trenutno nema direktnih paketa.
              Povećajte budžet na 150 € ili 200 € za bogatiji izbor.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {matchedTrips.map(({ package: pkg, financials }) => {
              const remainingMoney = financials.remainingBudgetEUR;
              return (
                <div
                  key={pkg.id}
                  className="bg-white rounded-2xl border border-stone-200/90 shadow-sm hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group"
                >
                  {/* Card Media Preview */}
                  <div className="relative h-44 overflow-hidden bg-stone-100">
                    <img
                      src={pkg.heroImage}
                      alt={pkg.destinationName}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src =
                          'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=800&q=80';
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-stone-950/70 via-stone-950/20 to-transparent" />

                    <div className="absolute top-3 left-3 text-xs font-medium text-white/90 drop-shadow">
                      <span>{pkg.destinationName}</span>
                      <span className="mx-1.5" aria-hidden="true">·</span>
                      <span>{pkg.country}</span>
                    </div>

                    <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between text-white">
                      <div>
                        <h3 className="font-display font-bold text-lg leading-snug drop-shadow-sm">
                          {pkg.title}
                        </h3>
                        <p className="text-xs text-stone-200 drop-shadow-sm">
                          {pkg.defaultNights} noćenja · {persons} {persons === 1 ? 'osoba' : 'osobe'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Financial Breakdown Body */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div className="space-y-3 mb-4">
                      {/* Transport row */}
                      <div className="flex items-center justify-between text-xs py-1 border-b border-stone-100">
                        <div className="flex items-center gap-1.5 text-stone-700">
                          {getTransportIcon(financials.transport.type)}
                          <span className="font-medium">{financials.transport.provider}</span>
                          <span className="text-stone-400">({financials.transport.originCity})</span>
                        </div>
                        <span className="font-semibold text-stone-900 tabular-nums">
                          {formatPrice(financials.totalTransportCostEUR)}
                        </span>
                      </div>

                      {/* Accommodation row */}
                      <div className="flex items-center justify-between text-xs py-1 border-b border-stone-100">
                        <div className="text-stone-700">
                          <span className="font-medium truncate block max-w-[200px]">
                            {financials.accommodation.name}
                          </span>
                          <span className="text-stone-400">
                            {financials.actualNights} noći ({financials.accommodation.rating} ★)
                          </span>
                        </div>
                        <span className="font-semibold text-stone-900 tabular-nums">
                          {formatPrice(financials.totalAccommodationCostEUR)}
                        </span>
                      </div>

                      {/* Total equation & remaining budget highlight */}
                      <div className="bg-amber-50/70 rounded-xl p-3 border border-amber-200/60">
                        <div className="flex items-center justify-between text-xs font-medium text-stone-700 mb-1">
                          <span>Ukupan trošak paketa:</span>
                          <span className="font-bold text-stone-950 text-sm tabular-nums">
                            {formatPrice(financials.totalBaseCostEUR)}
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-xs text-emerald-800 font-semibold pt-1 border-t border-amber-200/50">
                          <span className="flex items-center gap-1">
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            Ostaje ti za džeparac:
                          </span>
                          <span className="tabular-nums">
                            +{formatPrice(remainingMoney)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Button */}
                    <button
                      onClick={() => onSelectPackage(pkg)}
                      className="cursor-pointer w-full py-2.5 px-4 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
                    >
                      <span>Pogledaj detalje & prilagodi</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
