import React, { useState, useRef, useEffect } from 'react';
import { PRESET_CITIES, CITY_COORDINATES } from '../services/travelApi';
import { MapPin, Search, ChevronDown, Check, Car, Sparkles, X } from 'lucide-react';

interface CityComboboxProps {
  value: string;
  onChange: (city: string) => void;
  variant?: 'hero' | 'map' | 'compact';
}

export const CityCombobox: React.FC<CityComboboxProps> = ({
  value,
  onChange,
  variant = 'hero',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (city: string) => {
    onChange(city);
    setQuery('');
    setIsOpen(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (query.trim()) {
        handleSelect(query.trim());
      } else {
        setIsOpen(false);
      }
    } else if (e.key === 'Escape') {
      setIsOpen(false);
    }
  };

  const filteredPresetCities = PRESET_CITIES.filter((city) =>
    city.toLowerCase().includes(query.toLowerCase())
  );

  const serbianCities = filteredPresetCities.filter((c) =>
    [
      'Beograd',
      'Novi Sad',
      'Niš',
      'Kragujevac',
      'Subotica',
      'Vranje',
      'Leskovac',
      'Čačak',
      'Užice',
      'Kruševac',
      'Kraljevo',
      'Valjevo',
      'Šabac',
      'Novi Pazar',
      'Pančevo',
      'Zrenjanin',
      'Sombor',
      'Pirot',
      'Zaječar',
      'Požarevac',
    ].includes(c)
  );

  const regionalCities = filteredPresetCities.filter((c) =>
    [
      'Zagreb',
      'Skoplje',
      'Sofija',
      'Podgorica',
      'Sarajevo',
      'Banjaluka',
      'Tuzla',
      'Mostar',
      'Ljubljana',
      'Budimpešta',
      'Temišvar',
      'Split',
    ].includes(c)
  );

  const isCustomCity =
    query.trim().length > 0 &&
    !PRESET_CITIES.some((c) => c.toLowerCase() === query.trim().toLowerCase());

  const hasDirectBusOrFlight = ['Beograd', 'Niš', 'Novi Sad'].includes(value);

  return (
    <div ref={containerRef} className="relative w-full">
      {/* Combobox Trigger Field */}
      <div
        onClick={() => {
          setIsOpen(!isOpen);
          setTimeout(() => inputRef.current?.focus(), 50);
        }}
        className={`cursor-pointer w-full flex items-center justify-between transition-colors ${
          variant === 'map'
            ? 'bg-stone-800/95 border border-stone-700 text-white rounded-xl px-3 py-1.5 text-xs'
            : 'bg-white border border-stone-300 rounded-lg px-3 py-2 text-sm text-stone-800 focus-within:ring-2 focus-within:ring-amber-500'
        }`}
      >
        <div className="flex items-center gap-2 truncate">
          <MapPin
            className={`shrink-0 ${
              variant === 'map' ? 'w-3.5 h-3.5 text-amber-400' : 'w-4 h-4 text-amber-600'
            }`}
          />
          <span className="font-semibold truncate">
            {value || 'Izaberi ili upiši grad...'}
          </span>
        </div>
        <ChevronDown
          className={`w-4 h-4 shrink-0 transition-transform ${
            variant === 'map' ? 'text-stone-400' : 'text-stone-500'
          } ${isOpen ? 'rotate-180' : ''}`}
        />
      </div>

      {/* Advisory hint if smaller town/car trip */}
      {variant === 'hero' && value && value !== 'Svi gradovi' && !hasDirectBusOrFlight && (
        <div className="flex items-center gap-1 text-[11px] text-amber-700 mt-1.5 font-medium">
          <Car className="w-3.5 h-3.5 text-amber-600 shrink-0" />
          <span>Polazak iz {value} (proračunat sopstveni automobil)</span>
        </div>
      )}

      {/* Dropdown Popover */}
      {isOpen && (
        <div
          className={`absolute left-0 z-50 mt-1.5 w-full min-w-[280px] max-w-sm rounded-2xl shadow-2xl border p-2 animate-in fade-in zoom-in-95 duration-150 ${
            variant === 'map'
              ? 'bg-stone-900 border-stone-700 text-white'
              : 'bg-white border-stone-200 text-stone-800'
          }`}
        >
          {/* Search or Free-text Input Bar */}
          <div
            className={`flex items-center gap-2 px-3 py-2 rounded-xl border mb-2 ${
              variant === 'map'
                ? 'bg-stone-800 border-stone-700 text-white'
                : 'bg-stone-50 border-stone-200 text-stone-900'
            }`}
          >
            <Search className="w-4 h-4 text-stone-400 shrink-0" />
            <input
              ref={inputRef}
              type="text"
              placeholder="Upiši grad (npr. Vranje, Zagreb...)"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full bg-transparent text-xs sm:text-sm focus:outline-none placeholder:text-stone-400"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Prompt if typing custom town */}
          {isCustomCity && (
            <button
              type="button"
              onClick={() => handleSelect(query.trim())}
              className="w-full text-left p-2.5 mb-2 rounded-xl bg-amber-500/10 border border-amber-500/30 hover:bg-amber-500/20 text-amber-600 dark:text-amber-300 text-xs font-semibold flex items-center justify-between transition-colors"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>
                  Postavi polazak iz: <strong>"{query.trim()}"</strong>
                </span>
              </div>
              <span className="text-[10px] bg-amber-600 text-white px-2 py-0.5 rounded font-bold">
                Izaberi
              </span>
            </button>
          )}

          {/* Scrollable List of Cities */}
          <div className="max-h-64 overflow-y-auto space-y-3 pr-1 text-xs">
            {/* 1. All Cities Option */}
            {(!query || 'svi gradovi'.includes(query.toLowerCase())) && (
              <div>
                <button
                  type="button"
                  onClick={() => handleSelect('Svi gradovi')}
                  className={`w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between font-medium transition-colors ${
                    value === 'Svi gradovi'
                      ? 'bg-amber-600 text-white font-bold'
                      : 'hover:bg-stone-100 dark:hover:bg-stone-800'
                  }`}
                >
                  <span>Svi gradovi (sve opcije)</span>
                  {value === 'Svi gradovi' && <Check className="w-3.5 h-3.5" />}
                </button>
              </div>
            )}

            {/* 2. Srbija (Veći gradovi, Vranje, Leskovac, Užice, itd.) */}
            {serbianCities.length > 0 && (
              <div>
                <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-3 py-1">
                  🇷🇸 Srbija ({serbianCities.length})
                </div>
                <div className="space-y-0.5">
                  {serbianCities.map((city) => (
                    <button
                      key={city}
                      type="button"
                      onClick={() => handleSelect(city)}
                      className={`w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between transition-colors ${
                        value === city
                          ? 'bg-amber-600 text-white font-bold'
                          : 'hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span>{city}</span>
                        {['Vranje', 'Leskovac', 'Čačak', 'Užice'].includes(city) && (
                          <span className="text-[9px] text-stone-400">
                            (sopstveni auto / bus)
                          </span>
                        )}
                      </div>
                      {value === city && <Check className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* 3. Region & Susedstvo (Zagreb, Skoplje, Sofija, Podgorica, Sarajevo...) */}
            {regionalCities.length > 0 && (
              <div>
                <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-3 py-1 border-t border-stone-100 dark:border-stone-800 pt-2">
                  🌍 Region & Susedstvo (Zagreb, Sofija, Skoplje...)
                </div>
                <div className="space-y-0.5">
                  {regionalCities.map((city) => (
                    <button
                      key={city}
                      type="button"
                      onClick={() => handleSelect(city)}
                      className={`w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between transition-colors ${
                        value === city
                          ? 'bg-amber-600 text-white font-bold'
                          : 'hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      <span>{city}</span>
                      {value === city && <Check className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {filteredPresetCities.length === 0 && !isCustomCity && (
              <div className="text-center py-4 text-stone-400 text-xs">
                Nema rezultata. Pritisni Enter da postaviš uneti grad.
              </div>
            )}
          </div>

          {/* Quick Footer Note */}
          <div className="text-[10px] text-stone-400 border-t border-stone-200 dark:border-stone-800 pt-2 px-2 mt-2 flex items-center justify-between">
            <span>Možeš uneti bilo koji grad ili selo</span>
            <span className="font-semibold text-amber-500">Enter ↵</span>
          </div>
        </div>
      )}
    </div>
  );
};
