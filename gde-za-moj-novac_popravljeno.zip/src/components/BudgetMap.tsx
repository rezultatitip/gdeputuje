import React, { useState, useEffect } from 'react';
import { TravelPackage, SearchFilters } from '../types/travel';
import { calculateTripFinancials, EUR_TO_RSD_RATE, CITY_COORDINATES } from '../services/travelApi';
import { getLiveWeather, LiveWeatherInfo } from '../services/liveApis';
import {
  Compass,
  Bus,
  Plane,
  Car,
  MapPin,
  Sparkles,
  ArrowRight,
  Maximize2,
  Minimize2,
  Check,
  Clock,
} from 'lucide-react';
import { getBorderCrossingsForDestination } from '../services/borderApi';
import { CityCombobox } from './CityCombobox';

interface BudgetMapProps {
  packages: TravelPackage[];
  filters: SearchFilters;
  onFilterChange: <K extends keyof SearchFilters>(key: K, value: SearchFilters[K]) => void;
  onSelectPackage: (pkg: TravelPackage) => void;
}

// Bounding box for Balkans & Central/Southern Europe
const MIN_LNG = 11.2;
const MAX_LNG = 25.8;
const MIN_LAT = 39.8;
const MAX_LAT = 48.6;

const MAP_WIDTH = 920;
const MAP_HEIGHT = 620;

function projectCoords(lat: number, lng: number) {
  const x = ((lng - MIN_LNG) / (MAX_LNG - MIN_LNG)) * MAP_WIDTH;
  const y = ((MAX_LAT - lat) / (MAX_LAT - MIN_LAT)) * MAP_HEIGHT;
  return { x, y };
}

export const BudgetMap: React.FC<BudgetMapProps> = ({
  packages,
  filters,
  onFilterChange,
  onSelectPackage,
}) => {
  const [hoveredPkgId, setHoveredPkgId] = useState<string | null>(null);
  const [selectedPkgId, setSelectedPkgId] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [mapWeather, setMapWeather] = useState<LiveWeatherInfo | null>(null);

  // Selected or active package
  const activePkg =
    packages.find((p) => p.id === (selectedPkgId || hoveredPkgId)) ||
    packages[0];

  useEffect(() => {
    let isMounted = true;
    if (activePkg?.coordinates) {
      getLiveWeather(activePkg.coordinates.lat, activePkg.coordinates.lng).then((res) => {
        if (isMounted) setMapWeather(res);
      });
    }
    return () => {
      isMounted = false;
    };
  }, [activePkg]);

  const originCoords =
    CITY_COORDINATES[filters.originCity] || CITY_COORDINATES['Beograd'];

  const originPoint = projectCoords(originCoords.lat, originCoords.lng);

  const formatPrice = (eur: number) => {
    if (filters.currency === 'RSD') {
      return `${Math.round(eur * EUR_TO_RSD_RATE).toLocaleString()} RSD`;
    }
    return `${Math.round(eur)} €`;
  };

  const getTransportIcon = (type: string) => {
    if (type === 'flight') return <Plane className="w-3 h-3 text-sky-400" />;
    if (type === 'car') return <Car className="w-3 h-3 text-stone-300" />;
    return <Bus className="w-3 h-3 text-amber-400" />;
  };

  return (
    <section className="py-12 bg-stone-900 text-white border-b border-stone-800" id="mapa-budzeta-sekcija">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
              <Compass className="w-4 h-4 text-amber-400" />
              <span>Interaktivni radar za tvoj džep</span>
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Mapa budžeta: Gde možeš da stigneš za {filters.maxBudgetEUR} €?
            </h2>
            <p className="text-xs sm:text-sm text-stone-300 mt-1 max-w-xl">
              Zeleni pinovi prikazuju destinacije koje se 100% uklapaju u tvoj budžet (povratni prevoz + smeštaj).
              Klikni na bilo koji pin na mapi da istražiš troškove i linije.
            </p>
          </div>

          {/* Quick Origin & Budget Switchers */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="min-w-[190px]">
              <CityCombobox
                value={filters.originCity}
                onChange={(city) => onFilterChange('originCity', city)}
                variant="map"
              />
            </div>

            <div className="flex items-center gap-1 bg-stone-800/90 border border-stone-700 rounded-xl p-1">
              {[100, 150, 200, 300].map((b) => (
                <button
                  key={b}
                  onClick={() => onFilterChange('maxBudgetEUR', b)}
                  className={`cursor-pointer px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                    filters.maxBudgetEUR === b
                      ? 'bg-amber-600 text-white'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  {b} €
                </button>
              ))}
            </div>

            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-xl bg-stone-800 border border-stone-700 text-stone-300 hover:text-white transition-colors hidden sm:block"
              title={isFullscreen ? 'Zatvori uvećan prikaz' : 'Uvećaj mapu'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Map Container Canvas & Sidebar */}
        <div
          className={`grid grid-cols-1 lg:grid-cols-12 gap-6 bg-stone-950 rounded-3xl border border-stone-800 p-4 sm:p-6 shadow-2xl relative overflow-hidden transition-all duration-300 ${
            isFullscreen ? 'fixed inset-4 z-50 overflow-y-auto max-w-none' : ''
          }`}
        >
          {/* Main SVG Vector Canvas */}
          <div className="lg:col-span-8 bg-gradient-to-b from-[#131b26] to-[#0c121a] rounded-2xl border border-stone-800/80 relative overflow-hidden min-h-[460px] flex items-center justify-center">
            {/* Ambient Water & Radar Radial Grid */}
            <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:24px_24px]" />

            <svg
              viewBox={`0 0 ${MAP_WIDTH} ${MAP_HEIGHT}`}
              className="w-full h-full max-h-[580px] select-none"
            >
              <defs>
                {/* Glow Filter */}
                <filter id="radar-glow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
                {/* Linear gradient for route paths */}
                <linearGradient id="route-gradient-emerald" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#10b981" stopOpacity="0.9" />
                </linearGradient>
                <linearGradient id="route-gradient-muted" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#78716c" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#78716c" stopOpacity="0.2" />
                </linearGradient>
              </defs>

              {/* Water Bodies (Adriatic Sea, Ionian, Aegean) Background Shapes */}
              {/* Jadransko more (Adriatic Sea) approximation polygon */}
              <polygon
                points="160,280 240,240 380,390 480,480 430,530 310,480 230,410 160,340"
                fill="#091421"
                opacity="0.8"
              />
              {/* Egejsko more (Aegean Sea) approximation */}
              <polygon
                points="660,510 740,510 820,580 730,620 650,560"
                fill="#091421"
                opacity="0.8"
              />

              {/* Simplified River Danube Flow curve */}
              <path
                d="M 430,70 Q 470,120 480,180 T 520,270 Q 560,280 620,290 T 780,310"
                fill="none"
                stroke="#1e3a5f"
                strokeWidth="2.5"
                strokeDasharray="4 3"
                opacity="0.6"
              />
              <text x="510" y="260" fill="#38bdf8" fontSize="10" opacity="0.4" className="italic font-sans">
                Dunav
              </text>

              {/* Major Region Reference Labels */}
              <text x="310" y="440" fill="#64748b" fontSize="11" opacity="0.4" letterSpacing="2" className="font-bold">
                JADRANSKO MORE
              </text>
              <text x="700" y="550" fill="#64748b" fontSize="11" opacity="0.4" letterSpacing="2" className="font-bold">
                EGEJSKO MORE
              </text>
              <text x="500" y="140" fill="#64748b" fontSize="11" opacity="0.4" letterSpacing="1">
                PANONSKA NIZIJA
              </text>
              <text x="560" y="380" fill="#64748b" fontSize="12" opacity="0.35" letterSpacing="3" className="font-bold">
                BALKAN
              </text>

              {/* Animated Routes from Origin to Packages */}
              {packages.map((pkg) => {
                if (!pkg.coordinates) return null;
                const dest = projectCoords(pkg.coordinates.lat, pkg.coordinates.lng);
                const fin = calculateTripFinancials(
                  pkg,
                  undefined,
                  undefined,
                  pkg.defaultNights,
                  filters.persons,
                  filters.maxBudgetEUR,
                  filters.originCity
                );
                const isHovered = hoveredPkgId === pkg.id || selectedPkgId === pkg.id;

                // Bezier curve control point with slight arc
                const midX = (originPoint.x + dest.x) / 2;
                const midY = (originPoint.y + dest.y) / 2 - 25;

                return (
                  <path
                    key={`route-${pkg.id}`}
                    d={`M ${originPoint.x} ${originPoint.y} Q ${midX} ${midY} ${dest.x} ${dest.y}`}
                    fill="none"
                    stroke={
                      isHovered
                        ? '#fbbf24'
                        : fin.isWithinBudget
                        ? 'url(#route-gradient-emerald)'
                        : 'url(#route-gradient-muted)'
                    }
                    strokeWidth={isHovered ? '2.5' : fin.isWithinBudget ? '1.5' : '1'}
                    strokeDasharray={isHovered ? 'none' : '4 4'}
                    className="transition-all duration-300"
                    opacity={isHovered ? 1 : fin.isWithinBudget ? 0.75 : 0.25}
                  />
                );
              })}

              {/* Origin City Pulsing Marker */}
              <g transform={`translate(${originPoint.x}, ${originPoint.y})`}>
                <circle r="14" fill="#f59e0b" opacity="0.2" className="animate-ping" />
                <circle r="8" fill="#f59e0b" opacity="0.4" />
                <circle r="4.5" fill="#ffffff" stroke="#f59e0b" strokeWidth="2" />
                <text
                  x="8"
                  y="-8"
                  fill="#fbbf24"
                  fontSize="11"
                  fontWeight="bold"
                  className="drop-shadow-md select-none font-sans"
                >
                  {filters.originCity} (Polazak)
                </text>
              </g>

              {/* Destination Markers */}
              {packages.map((pkg) => {
                if (!pkg.coordinates) return null;
                const pt = projectCoords(pkg.coordinates.lat, pkg.coordinates.lng);
                const fin = calculateTripFinancials(
                  pkg,
                  undefined,
                  undefined,
                  pkg.defaultNights,
                  filters.persons,
                  filters.maxBudgetEUR,
                  filters.originCity
                );
                const isSelected = selectedPkgId === pkg.id;
                const isHovered = hoveredPkgId === pkg.id;
                const isAffordable = fin.isWithinBudget;

                return (
                  <g
                    key={`pin-${pkg.id}`}
                    transform={`translate(${pt.x}, ${pt.y})`}
                    onClick={() => {
                      setSelectedPkgId(pkg.id);
                      setHoveredPkgId(pkg.id);
                    }}
                    onMouseEnter={() => setHoveredPkgId(pkg.id)}
                    className="cursor-pointer group"
                  >
                    {/* Pulsing ring for affordable destinations */}
                    {isAffordable && (
                      <circle
                        r="12"
                        fill="#10b981"
                        opacity={isHovered || isSelected ? 0.35 : 0.15}
                        className={isHovered || isSelected ? 'animate-pulse' : ''}
                      />
                    )}

                    {/* Pin Circle */}
                    <circle
                      r={isSelected || isHovered ? '9' : '7'}
                      fill={
                        isSelected || isHovered
                          ? '#f59e0b'
                          : isAffordable
                          ? '#10b981'
                          : '#64748b'
                      }
                      stroke="#ffffff"
                      strokeWidth="1.5"
                      className="transition-all duration-200"
                    />

                    {/* Floating Price Pill Label */}
                    <g
                      transform={`translate(${isSelected || isHovered ? 12 : 10}, ${
                        isSelected || isHovered ? -12 : -8
                      })`}
                      className="transition-all duration-200"
                    >
                      <rect
                        rx="6"
                        ry="6"
                        x="0"
                        y="-12"
                        width={
                          pkg.destinationName.length * 6.5 +
                          (filters.currency === 'RSD' ? 65 : 45)
                        }
                        height="20"
                        fill={
                          isSelected || isHovered
                            ? '#1c1917'
                            : isAffordable
                            ? '#064e3b'
                            : '#292524'
                        }
                        stroke={
                          isSelected || isHovered
                            ? '#fbbf24'
                            : isAffordable
                            ? '#059669'
                            : '#44403c'
                        }
                        strokeWidth="1"
                        opacity="0.95"
                      />
                      <text
                        x="6"
                        y="2"
                        fill={
                          isSelected || isHovered
                            ? '#fef08a'
                            : isAffordable
                            ? '#ecfdf5'
                            : '#a8a29e'
                        }
                        fontSize="10"
                        fontWeight="600"
                        className="font-sans"
                      >
                        {pkg.destinationName} · {Math.round(fin.totalBaseCostEUR)} €
                      </text>
                    </g>
                  </g>
                );
              })}
            </svg>

            {/* Bottom Map Legend */}
            <div className="absolute bottom-3 left-3 bg-stone-900/90 backdrop-blur-md rounded-xl p-2.5 border border-stone-800 text-[11px] flex items-center gap-4 text-stone-300">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500/50" />
                <span>U budžetu (do {filters.maxBudgetEUR} €)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-stone-500" />
                <span>Prekoračuje budžet</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                <span>Mesto polaska</span>
              </div>
            </div>
          </div>

          {/* Right Column: Live Destination Inspector Card */}
          <div className="lg:col-span-4 flex flex-col justify-between bg-stone-900 rounded-2xl p-5 border border-stone-800">
            {activePkg ? (
              (() => {
                const fin = calculateTripFinancials(
                  activePkg,
                  undefined,
                  undefined,
                  activePkg.defaultNights,
                  filters.persons,
                  filters.maxBudgetEUR,
                  filters.originCity
                );
                return (
                  <div className="space-y-4 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Destination Thumbnail & Badges */}
                      <div className="relative h-36 rounded-xl overflow-hidden mb-3 bg-stone-800">
                        <img
                          src={activePkg.heroImage}
                          alt={activePkg.destinationName}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src =
                              'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=600&q=80';
                          }}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent" />
                        <div className="absolute top-2 left-2 text-[10px] font-bold text-amber-300 bg-black/50 backdrop-blur-sm px-2 py-0.5 rounded">
                          {activePkg.category.toUpperCase()} · {activePkg.defaultNights} NOĆI
                        </div>
                        {mapWeather && (
                          <div className="absolute top-2 right-2 text-[10px] font-bold text-emerald-300 bg-emerald-950/80 backdrop-blur-sm px-2 py-0.5 rounded border border-emerald-500/40 flex items-center gap-1">
                            <span>{mapWeather.icon}</span>
                            <span>{mapWeather.temperature}°C</span>
                            <span className="text-[9px] text-stone-300">Uživo</span>
                          </div>
                        )}
                        <div className="absolute bottom-2 left-2 right-2 text-white">
                          <h4 className="font-display font-bold text-base leading-tight">
                            {activePkg.destinationName}, {activePkg.country}
                          </h4>
                          <p className="text-[11px] text-stone-300 truncate">
                            {activePkg.title}
                          </p>
                        </div>
                      </div>

                      {/* Route & Transport Summary */}
                      <div className="bg-stone-950/60 rounded-xl p-3 border border-stone-800/80 space-y-2 mb-3">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-stone-400 flex items-center gap-1.5">
                            {getTransportIcon(fin.transport.type)}
                            <span>Prevoznik:</span>
                          </span>
                          <span className="font-semibold text-white">
                            {fin.transport.provider}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-stone-400">Ruta:</span>
                          <span className="text-stone-200">
                            {filters.originCity} ➔ {fin.transport.destinationCity} (~{fin.transport.durationHours}h)
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-stone-400">Preporučeni smeštaj:</span>
                          <span className="text-stone-200 font-medium truncate max-w-[150px]">
                            {fin.accommodation.name} ({fin.accommodation.rating} ★)
                          </span>
                        </div>

                        {/* Advisory badge if no direct transport / car fallback */}
                        {fin.advisoryNote && (
                          <div className="p-2 rounded-lg bg-amber-950/40 border border-amber-800/60 text-[11px] text-amber-300 flex items-start gap-1.5 mt-2">
                            <Car className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                            <span className="leading-tight">{fin.advisoryNote}</span>
                          </div>
                        )}

                        {/* Border wait time for international destinations */}
                        {activePkg.country !== 'Srbija' && (() => {
                          const mapBorders = getBorderCrossingsForDestination(activePkg.destinationName, activePkg.country);
                          if (mapBorders.length === 0) return null;
                          const b = mapBorders[0];
                          return (
                            <div className="flex items-center justify-between text-[11px] bg-stone-900/90 border border-stone-800 p-2 rounded-lg text-stone-300 mt-2">
                              <span className="flex items-center gap-1.5 text-stone-400">
                                <Clock className="w-3.5 h-3.5 text-amber-400" />
                                <span>Granica ({b.name.split('(')[0]}):</span>
                              </span>
                              <span className="font-bold text-amber-300 tabular-nums">
                                ~{b.waitPassengerExitMin} min ({b.status})
                              </span>
                            </div>
                          );
                        })()}
                      </div>

                      {/* Financial Calculation Equation */}
                      <div className="bg-stone-800/50 rounded-xl p-3 border border-stone-700/60 space-y-1.5 text-xs">
                        <div className="flex justify-between text-stone-300">
                          <span>Prevoz ({filters.persons} os.):</span>
                          <span className="font-semibold tabular-nums text-white">
                            {formatPrice(fin.totalTransportCostEUR)}
                          </span>
                        </div>
                        <div className="flex justify-between text-stone-300">
                          <span>Smeštaj ({activePkg.defaultNights} noći):</span>
                          <span className="font-semibold tabular-nums text-white">
                            {formatPrice(fin.totalAccommodationCostEUR)}
                          </span>
                        </div>
                        <div className="pt-2 border-t border-stone-700 flex justify-between items-baseline">
                          <span className="font-bold text-stone-200">Ukupan aranžman:</span>
                          <span className="font-display font-bold text-xl text-white tabular-nums">
                            {formatPrice(fin.totalBaseCostEUR)}
                          </span>
                        </div>

                        {/* Budget Status Indicator */}
                        <div className="pt-1">
                          {fin.isWithinBudget ? (
                            <div className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Ostaje ti {formatPrice(fin.remainingBudgetEUR)} za džeparac!</span>
                            </div>
                          ) : (
                            <div className="text-[11px] text-amber-400">
                              Zahteva još {formatPrice(Math.abs(fin.remainingBudgetEUR))} preko budžeta
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Action Button */}
                    <div className="pt-3">
                      <button
                        onClick={() => onSelectPackage(activePkg)}
                        className="cursor-pointer w-full py-2.5 px-4 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-2 shadow-lg shadow-amber-600/20"
                      >
                        <span>Otvori detalje & rezerviši</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })()
            ) : (
              <div className="text-center py-12 text-stone-500 text-xs">
                Izaberi tačku na mapi za prikaz detalja
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
