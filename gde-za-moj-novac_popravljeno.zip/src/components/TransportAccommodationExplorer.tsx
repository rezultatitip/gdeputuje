import React, { useState } from 'react';
import { DEMO_PACKAGES, EUR_TO_RSD_RATE } from '../services/travelApi';
import { Bus, Plane, Hotel, Clock, MapPin, Search } from 'lucide-react';

interface TransportAccommodationExplorerProps {
  currency: 'EUR' | 'RSD';
}

export const TransportAccommodationExplorer: React.FC<TransportAccommodationExplorerProps> = ({
  currency,
}) => {
  const [activeTab, setActiveTab] = useState<'avion' | 'autobus' | 'smestaj'>('avion');
  const [searchQuery, setSearchQuery] = useState('');

  const formatPrice = (eur: number) => {
    if (currency === 'RSD') {
      return `${Math.round(eur * EUR_TO_RSD_RATE).toLocaleString()} RSD`;
    }
    return `${Math.round(eur)} €`;
  };

  // Extract all flights from demo data
  const allFlights = DEMO_PACKAGES.flatMap((pkg) =>
    pkg.transports
      .filter((t) => t.type === 'flight')
      .map((t) => ({ ...t, destination: pkg.destinationName, country: pkg.country }))
  ).filter(
    (f) =>
      f.destination.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.provider.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.originCity.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Extract all buses
  const allBuses = DEMO_PACKAGES.flatMap((pkg) =>
    pkg.transports
      .filter((t) => t.type === 'bus')
      .map((t) => ({ ...t, destination: pkg.destinationName, country: pkg.country }))
  ).filter(
    (b) =>
      b.destination.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.provider.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.originCity.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Extract all accommodations
  const allAccommodations = DEMO_PACKAGES.flatMap((pkg) =>
    pkg.accommodations.map((a) => ({
      ...a,
      destination: pkg.destinationName,
      country: pkg.country,
      category: pkg.category,
    }))
  ).filter(
    (a) =>
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.destination.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.locationDescription.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section className="py-12 bg-white border-b border-stone-200" id="prevoz-smestaj-sekcija">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="text-xs font-semibold text-amber-800 uppercase tracking-wider mb-1">
              Direktna pretraga komponenti putovanja
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-stone-900 tracking-tight">
              Pretraga letova, autobusa i smeštaja
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 mt-1 max-w-xl">
              Pregledaj pojedinačne cene i linije nezavisno od aranžmana. Podaci su pripremljeni
              za povezivanje sa Skyscanner, BalkanViator i Booking servisima.
            </p>
          </div>

          {/* Tab buttons */}
          <div className="flex items-center gap-1.5 p-1 bg-stone-100 rounded-xl">
            <button
              onClick={() => setActiveTab('avion')}
              className={`cursor-pointer px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeTab === 'avion'
                  ? 'bg-white text-stone-900 shadow-sm'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Plane className="w-3.5 h-3.5 text-sky-600" />
              <span>Avio karte</span>
            </button>
            <button
              onClick={() => setActiveTab('autobus')}
              className={`cursor-pointer px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeTab === 'autobus'
                  ? 'bg-white text-stone-900 shadow-sm'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Bus className="w-3.5 h-3.5 text-amber-600" />
              <span>Autobuske linije</span>
            </button>
            <button
              onClick={() => setActiveTab('smestaj')}
              className={`cursor-pointer px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeTab === 'smestaj'
                  ? 'bg-white text-stone-900 shadow-sm'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Hotel className="w-3.5 h-3.5 text-emerald-600" />
              <span>Hoteli i apartmani</span>
            </button>
          </div>
        </div>

        {/* Live Filter Search Input */}
        <div className="relative mb-6 max-w-md">
          <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Pretraži po destinaciji, prevozniku ili nazivu..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>

        {/* Tab 1: Flights Table / Cards */}
        {activeTab === 'avion' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {allFlights.length === 0 ? (
              <p className="text-stone-500 text-xs col-span-3">Nema letova koji odgovaraju pretrazi.</p>
            ) : (
              allFlights.map((f, i) => (
                <div key={i} className="bg-stone-50 rounded-xl p-4 border border-stone-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-sky-900 flex items-center gap-1.5">
                      <Plane className="w-3.5 h-3.5 text-sky-600" />
                      {f.provider}
                    </span>
                    <span className="font-display font-bold text-stone-900 text-base tabular-nums">
                      {formatPrice(f.pricePerPersonEUR)}
                    </span>
                  </div>

                  <div className="text-xs font-semibold text-stone-800">
                    {f.originCity} ➔ {f.destinationCity}
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-stone-500 pt-2 border-t border-stone-200">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-stone-400" />
                      {f.durationHours}h let · {f.isDirect ? 'Direktan' : 'Sa presedanjem'}
                    </span>
                    <span>{f.baggageNote}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Tab 2: Buses Table / Cards */}
        {activeTab === 'autobus' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {allBuses.length === 0 ? (
              <p className="text-stone-500 text-xs col-span-3">Nema autobusa koji odgovaraju pretrazi.</p>
            ) : (
              allBuses.map((b, i) => (
                <div key={i} className="bg-stone-50 rounded-xl p-4 border border-stone-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                      <Bus className="w-3.5 h-3.5 text-amber-600" />
                      {b.provider}
                    </span>
                    <span className="font-display font-bold text-stone-900 text-base tabular-nums">
                      {formatPrice(b.pricePerPersonEUR)}
                    </span>
                  </div>

                  <div className="text-xs font-semibold text-stone-800">
                    {b.originCity} ➔ {b.destinationCity}
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-stone-500 pt-2 border-t border-stone-200">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-stone-400" />
                      Polazak: {b.departureTime} (~{b.durationHours}h)
                    </span>
                    <span>{b.baggageNote}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Tab 3: Accommodations Table / Cards */}
        {activeTab === 'smestaj' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {allAccommodations.length === 0 ? (
              <p className="text-stone-500 text-xs col-span-3">Nema smeštaja koji odgovara pretrazi.</p>
            ) : (
              allAccommodations.map((a, i) => (
                <div key={i} className="bg-stone-50 rounded-xl p-4 border border-stone-200 space-y-2.5">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-stone-900">{a.name}</h4>
                      <p className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-stone-400" />
                        {a.destination}, {a.country} · {a.locationDescription}
                      </p>
                    </div>
                    <span className="font-display font-bold text-stone-900 text-base tabular-nums shrink-0 ml-2">
                      {formatPrice(a.pricePerNightEUR)}
                      <span className="text-[10px] text-stone-500 font-normal"> /noć</span>
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-[11px]">
                    <span className="bg-amber-100 text-amber-900 font-bold px-1.5 py-0.5 rounded">
                      {a.rating} ★
                    </span>
                    <span className="text-stone-500">({a.reviewCount} recenzija)</span>
                    <span className="text-stone-400">·</span>
                    <span className="text-stone-600 font-medium">{a.roomType}</span>
                  </div>

                  <div className="flex flex-wrap gap-1 pt-1">
                    {a.amenities.slice(0, 3).map((am, idx) => (
                      <span key={idx} className="text-[10px] text-stone-500 bg-white px-2 py-0.5 rounded border border-stone-200">
                        {am}
                      </span>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </section>
  );
};
