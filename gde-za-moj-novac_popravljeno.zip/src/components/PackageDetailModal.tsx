import React, { useState, useEffect } from 'react';
import { TravelPackage } from '../types/travel';
import { calculateTripFinancials, EUR_TO_RSD_RATE } from '../services/travelApi';
import {
  getLiveWeather,
  LiveWeatherInfo,
  searchDuffelFlightsLive,
  DuffelFlightOffer,
} from '../services/liveApis';
import {
  X,
  Bus,
  Plane,
  Car,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  Calendar,
  Send,
  Printer,
  ChevronRight,
  ShieldCheck,
  Building2,
  TrendingDown,
  Camera,
  RefreshCw,
} from 'lucide-react';
import { getBorderCrossingsForDestination } from '../services/borderApi';

const DEST_IATA_MAP: Record<string, string> = {
  'Rim': 'FCO',
  'Beč': 'VIE',
  'Budimpešta': 'BUD',
  'Sofija': 'SOF',
  'Solun': 'SKG',
  'Skoplje': 'SKP',
  'Atina': 'ATH',
  'Podgorica': 'TGD',
  'Tivat': 'TIV',
  'Sarajevo': 'SJJ',
  'Zagreb': 'ZAG',
  'Ljubljana': 'LJU',
  'Banjaluka': 'BNX',
};

interface PackageDetailModalProps {
  pkg: TravelPackage | null;
  onClose: () => void;
  currency: 'EUR' | 'RSD';
  initialPersons: number;
  userBudgetEUR: number;
  originCity?: string;
}

export const PackageDetailModal: React.FC<PackageDetailModalProps> = ({
  pkg,
  onClose,
  currency,
  initialPersons,
  userBudgetEUR,
  originCity = 'Beograd',
}) => {
  if (!pkg) return null;

  const [selectedTransportId, setSelectedTransportId] = useState<string>(
    pkg.defaultTransportId || pkg.transports[0]?.id
  );
  const [selectedAccommodationId, setSelectedAccommodationId] = useState<string>(
    pkg.defaultAccommodationId || pkg.accommodations[0]?.id
  );
  const [nights, setNights] = useState<number>(pkg.defaultNights);
  const [persons, setPersons] = useState<number>(initialPersons || 2);
  const [activeTab, setActiveTab] = useState<'kombinacija' | 'itinerer' | 'saveti' | 'rezervacija'>('kombinacija');

  // Booking simulation state
  const [guestName, setGuestName] = useState('');
  const [guestContact, setGuestContact] = useState('');
  const [travelDate, setTravelDate] = useState('2026-11-20');
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  const [bookingRefNumber, setBookingRefNumber] = useState('');
  const [weather, setWeather] = useState<LiveWeatherInfo | null>(null);

  // Duffel.com live flight offers in modal
  const [showDuffelFlightSearch, setShowDuffelFlightSearch] = useState(false);
  const [duffelLiveOffers, setDuffelLiveOffers] = useState<DuffelFlightOffer[]>([]);
  const [isLoadingDuffelInModal, setIsLoadingDuffelInModal] = useState(false);

  const handleLoadDuffelFlights = async () => {
    const destIata = DEST_IATA_MAP[pkg.destinationName] || 'FCO';
    const originIata = originCity.toLowerCase().includes('niš') ? 'INI' : 'BEG';
    setIsLoadingDuffelInModal(true);
    setShowDuffelFlightSearch(true);
    const offers = await searchDuffelFlightsLive(originIata, destIata);
    setDuffelLiveOffers(offers);
    setIsLoadingDuffelInModal(false);
  };

  useEffect(() => {
    let isMounted = true;
    if (pkg.coordinates) {
      getLiveWeather(pkg.coordinates.lat, pkg.coordinates.lng).then((res) => {
        if (isMounted && res) {
          setWeather(res);
        }
      });
    }
    return () => {
      isMounted = false;
    };
  }, [pkg.coordinates]);

  const fin = calculateTripFinancials(
    pkg,
    selectedTransportId,
    selectedAccommodationId,
    nights,
    persons,
    userBudgetEUR,
    originCity
  );

  const routeBorders = getBorderCrossingsForDestination(pkg.destinationName, pkg.country);

  const formatPrice = (eur: number) => {
    if (currency === 'RSD') {
      return `${Math.round(eur * EUR_TO_RSD_RATE).toLocaleString()} RSD`;
    }
    return `${Math.round(eur)} €`;
  };

  const getTransportIcon = (type: string) => {
    if (type === 'flight') return <Plane className="w-4 h-4 text-sky-600" />;
    if (type === 'car') return <Car className="w-4 h-4 text-stone-600" />;
    return <Bus className="w-4 h-4 text-amber-600" />;
  };

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim()) return;
    const ref = `GZM-${Math.floor(100000 + Math.random() * 900000)}`;
    setBookingRefNumber(ref);
    setBookingConfirmed(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden border border-stone-200">
        {/* Header Bar */}
        <div className="relative bg-stone-900 text-white p-6 sm:p-8 overflow-hidden shrink-0">
          <img
            src={pkg.heroImage}
            alt={pkg.destinationName}
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover opacity-30"
            onError={(e) => {
              (e.target as HTMLImageElement).src =
                'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=1200&q=80';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-stone-950 via-stone-900/90 to-stone-900/40" />

          <button
            onClick={onClose}
            className="cursor-pointer absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Zatvori prozor"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="relative z-10 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-300 tracking-wider uppercase mb-2">
              <span>{pkg.destinationName}</span>
              <span aria-hidden="true">·</span>
              <span>{pkg.country}</span>
              <span aria-hidden="true">·</span>
              <span>Preporučena sezona: {pkg.bestSeason}</span>
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-tight mb-2">
              {pkg.title}
            </h2>
            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
              {pkg.description}
            </p>

            {weather && (
              <div className="mt-3 inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-3 py-1.5 rounded-xl text-xs text-white border border-white/15">
                <span className="text-base">{weather.icon}</span>
                <span className="font-bold text-amber-300">{weather.temperature}°C</span>
                <span className="text-stone-300">· {weather.conditionText}</span>
                <span className="text-stone-400">· Vetar {weather.windSpeed} km/h</span>
                <span className="text-emerald-400 text-[10px] uppercase font-bold tracking-wider bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/30">
                  Uživo vreme
                </span>
              </div>
            )}
          </div>

          {/* Modal Tab Switcher */}
          <div className="relative z-10 flex items-center gap-2 mt-6 overflow-x-auto pb-1">
            <button
              onClick={() => setActiveTab('kombinacija')}
              className={`cursor-pointer px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'kombinacija'
                  ? 'bg-amber-600 text-white'
                  : 'bg-white/10 hover:bg-white/20 text-stone-200'
              }`}
            >
              Prilagodi prevoz i smeštaj
            </button>
            <button
              onClick={() => setActiveTab('itinerer')}
              className={`cursor-pointer px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'itinerer'
                  ? 'bg-amber-600 text-white'
                  : 'bg-white/10 hover:bg-white/20 text-stone-200'
              }`}
            >
              Šta videti & Atrakcije
            </button>
            <button
              onClick={() => setActiveTab('saveti')}
              className={`cursor-pointer px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'saveti'
                  ? 'bg-amber-600 text-white'
                  : 'bg-white/10 hover:bg-white/20 text-stone-200'
              }`}
            >
              Saveti za uštedu
            </button>
            <button
              onClick={() => setActiveTab('rezervacija')}
              className={`cursor-pointer px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'rezervacija'
                  ? 'bg-amber-600 text-white'
                  : 'bg-white/10 hover:bg-white/20 text-stone-200'
              }`}
            >
              Simulacija rezervacije
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {activeTab === 'kombinacija' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column: Selectors */}
              <div className="lg:col-span-2 space-y-6">
                {/* Duration & Persons Steppers */}
                <div className="grid grid-cols-2 gap-4 bg-stone-50 p-4 rounded-2xl border border-stone-200">
                  <div>
                    <label className="text-xs font-bold text-stone-700 block mb-1.5">
                      Broj noćenja:
                    </label>
                    <div className="flex items-center gap-2">
                      {[2, 3, 4, 7].map((n) => (
                        <button
                          key={n}
                          type="button"
                          onClick={() => setNights(n)}
                          className={`cursor-pointer px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                            nights === n
                              ? 'bg-stone-900 text-white'
                              : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-100'
                          }`}
                        >
                          {n} noći
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-stone-700 block mb-1.5">
                      Broj osoba:
                    </label>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4].map((p) => (
                        <button
                          key={p}
                          type="button"
                          onClick={() => setPersons(p)}
                          className={`cursor-pointer px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                            persons === p
                              ? 'bg-stone-900 text-white'
                              : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-100'
                          }`}
                        >
                          {p} {p === 1 ? 'osoba' : 'osobe'}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Transport Options Section */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                      1. Izaberi opciju prevoza
                    </h4>
                    <span className="text-[11px] text-stone-500">
                      Cene su po osobi u oba smera
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {/* Advisory note if custom town */}
                    {fin.advisoryNote && (
                      <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
                        <Car className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                        <span>{fin.advisoryNote}</span>
                      </div>
                    )}

                    {(fin.isAutoGeneratedCar && !pkg.transports.some((t) => t.id === fin.transport.id)
                      ? [fin.transport, ...pkg.transports]
                      : pkg.transports
                    ).map((t) => {
                      const isSelected = selectedTransportId === t.id;
                      return (
                        <div
                          key={t.id}
                          onClick={() => setSelectedTransportId(t.id)}
                          className={`cursor-pointer p-3.5 rounded-xl border transition-all ${
                            isSelected
                              ? 'border-amber-600 bg-amber-50/40 ring-1 ring-amber-600/30'
                              : 'border-stone-200 bg-white hover:border-stone-300'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <div className="flex items-center gap-2">
                              {getTransportIcon(t.type)}
                              <span className="font-semibold text-stone-900 text-sm">
                                {t.provider}
                              </span>
                              <span className="text-xs text-stone-500">
                                ({t.originCity} ➔ {t.destinationCity})
                              </span>
                            </div>
                            <span className="font-bold text-stone-900 text-sm tabular-nums">
                              {formatPrice(t.pricePerPersonEUR)} / os.
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-3 text-xs text-stone-500 mt-1">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5 text-stone-400" />
                              Polazak: {t.departureTime} · Povratak: {t.returnDepartureTime} (~{t.durationHours}h)
                            </span>
                            <span aria-hidden="true">·</span>
                            <span>{t.baggageNote}</span>
                          </div>

                          <div className="text-[11px] text-stone-400 mt-1 italic">
                            Napomena: {t.bookingNote}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Border Crossings status on this route if international */}
                  {routeBorders.length > 0 && (
                    <div className="bg-amber-50/70 rounded-xl p-3.5 border border-amber-200 text-xs space-y-2 mt-3">
                      <div className="flex items-center justify-between">
                        <div className="font-bold text-amber-950 flex items-center gap-1.5 text-xs">
                          <Clock className="w-3.5 h-3.5 text-amber-700" />
                          <span>Zadržavanje na granici za ovu rutu (Uživo AMSS):</span>
                        </div>
                        <a
                          href="https://kamere.amss.org.rs/"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[11px] font-bold text-amber-800 hover:text-amber-950 flex items-center gap-1 hover:underline"
                        >
                          <Camera className="w-3 h-3 text-amber-600" />
                          <span>Kamere uživo</span>
                        </a>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {routeBorders.slice(0, 2).map((b) => (
                          <div
                            key={b.id}
                            className="bg-white p-2.5 rounded-lg border border-amber-200/80 flex items-center justify-between shadow-2xs"
                          >
                            <div>
                              <div className="font-semibold text-stone-900 text-[11px] flex items-center gap-1">
                                <span>{b.flagEmoji}</span>
                                <span>{b.name.split('(')[0]}</span>
                              </div>
                              <div className="text-[10px] text-stone-500">
                                {b.alternative ? `Brža alt: ${b.alternative.name}` : b.routeHint.slice(0, 28)}
                              </div>
                            </div>
                            <div className="text-right">
                              <span
                                className={`text-xs font-bold tabular-nums block ${
                                  b.waitPassengerExitMin > 40 ? 'text-rose-600' : 'text-emerald-700'
                                }`}
                              >
                                ~{b.waitPassengerExitMin} min
                              </span>
                              <span className="text-[9px] text-stone-400">izlaz iz SRB</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Duffel.com Live Flight Offers Box (for flight destinations) */}
                  {(DEST_IATA_MAP[pkg.destinationName] || pkg.transports.some((t) => t.type === 'flight')) && (
                    <div className="mt-3 bg-sky-50/70 border border-sky-200/90 rounded-xl p-3.5 space-y-2.5">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center font-bold shrink-0">
                            <Plane className="w-3.5 h-3.5" />
                          </div>
                          <div>
                            <h5 className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                              <span>Pravi letovi uživo preko Duffel API-ja</span>
                              <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                                GDS Feed
                              </span>
                            </h5>
                            <p className="text-[10px] text-stone-500">
                              Direktan uvid u avio karte ({originCity.toLowerCase().includes('niš') ? 'INI Niš' : 'BEG Beograd'} ➔ {DEST_IATA_MAP[pkg.destinationName] || pkg.destinationName})
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={handleLoadDuffelFlights}
                          disabled={isLoadingDuffelInModal}
                          className="cursor-pointer text-[11px] font-bold text-sky-900 bg-white hover:bg-sky-100 border border-sky-300 px-3 py-1.5 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-2xs shrink-0"
                        >
                          <RefreshCw className={`w-3 h-3 ${isLoadingDuffelInModal ? 'animate-spin' : ''}`} />
                          <span>{isLoadingDuffelInModal ? 'Učitavam letove...' : 'Proveri letove uživo'}</span>
                        </button>
                      </div>

                      {showDuffelFlightSearch && (
                        <div className="pt-2 border-t border-sky-200/70 space-y-2">
                          {isLoadingDuffelInModal ? (
                            <div className="p-3 text-center text-xs text-stone-500">
                              <RefreshCw className="w-3.5 h-3.5 animate-spin mx-auto mb-1 text-sky-600" />
                              <span>Pretražujem ponude avio-kompanija preko Duffel sistema...</span>
                            </div>
                          ) : duffelLiveOffers.length > 0 ? (
                            <div className="space-y-1.5">
                              {duffelLiveOffers.map((offer) => (
                                <div
                                  key={offer.id}
                                  className="bg-white p-2.5 rounded-lg border border-sky-200 flex items-center justify-between text-xs hover:border-sky-300 transition-colors shadow-2xs"
                                >
                                  <div className="flex items-center gap-2">
                                    {offer.airlineLogoUrl ? (
                                      <img
                                        src={offer.airlineLogoUrl}
                                        alt={offer.airlineName}
                                        className="w-5 h-5 object-contain"
                                        onError={(e) => {
                                          (e.target as HTMLElement).style.display = 'none';
                                        }}
                                      />
                                    ) : (
                                      <Plane className="w-4 h-4 text-sky-600" />
                                    )}
                                    <div>
                                      <div className="font-bold text-stone-900 text-xs">
                                        {offer.airlineName}{' '}
                                        <span className="font-normal text-stone-400 text-[10px]">
                                          ({offer.flightNumber})
                                        </span>
                                      </div>
                                      <div className="text-[10px] text-stone-500">
                                        {offer.departingAt} ➔ {offer.arrivingAt} · {offer.duration}
                                      </div>
                                    </div>
                                  </div>

                                  <div className="text-right">
                                    <div className="font-bold text-emerald-800 text-xs">
                                      {formatPrice(offer.totalAmountEUR)} / os.
                                    </div>
                                    <div className="text-[9px] text-stone-400">
                                      {offer.stopsCount === 0 ? 'Direktan let' : `${offer.stopsCount} presedanje`}
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="p-2.5 text-center text-[11px] text-stone-500 bg-white rounded-lg border border-sky-200">
                              Nema pronađenih letova za zadatu rutu u test okruženju, preporučuje se standardna ponuda prevoza.
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Accommodation Options Section */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                      2. Izaberi smeštaj
                    </h4>
                    <span className="text-[11px] text-stone-500">
                      Cena za celu sobu / apartman po noći
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {pkg.accommodations.map((acc) => {
                      const isSelected = selectedAccommodationId === acc.id;
                      return (
                        <div
                          key={acc.id}
                          onClick={() => setSelectedAccommodationId(acc.id)}
                          className={`cursor-pointer p-3.5 rounded-xl border transition-all ${
                            isSelected
                              ? 'border-amber-600 bg-amber-50/40 ring-1 ring-amber-600/30'
                              : 'border-stone-200 bg-white hover:border-stone-300'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold text-stone-900 text-sm">
                                {acc.name}
                              </span>
                              <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded">
                                {acc.rating} ★ ({acc.reviewCount} recenzija)
                              </span>
                            </div>
                            <span className="font-bold text-stone-900 text-sm tabular-nums">
                              {formatPrice(acc.pricePerNightEUR)} / noć
                            </span>
                          </div>

                          <div className="text-xs text-stone-600 mb-1.5">
                            {acc.roomType} · {acc.locationDescription}
                          </div>

                          <div className="flex flex-wrap gap-1.5">
                            {acc.amenities.map((am, idx) => (
                              <span
                                key={idx}
                                className="text-[10px] text-stone-500 bg-stone-100 px-2 py-0.5 rounded"
                              >
                                {am}
                              </span>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Right Column: Live Financial Calculator Box */}
              <div className="bg-stone-50 rounded-2xl p-5 border border-stone-200 h-fit space-y-4">
                <div>
                  <h4 className="font-display font-bold text-stone-900 text-base mb-1">
                    Kalkulator troškova
                  </h4>
                  <p className="text-[11px] text-stone-500">
                    Proračun za {persons} {persons === 1 ? 'osobu' : 'osobe'} i {nights} noćenja
                  </p>
                </div>

                <div className="space-y-2 text-xs py-2 border-y border-stone-200">
                  <div className="flex justify-between text-stone-600">
                    <span>
                      Prevoz ({fin.transport.provider} × {persons}):
                    </span>
                    <span className="font-semibold text-stone-900 tabular-nums">
                      {formatPrice(fin.totalTransportCostEUR)}
                    </span>
                  </div>

                  <div className="flex justify-between text-stone-600">
                    <span>
                      Smeštaj ({fin.accommodation.name} × {nights} noći):
                    </span>
                    <span className="font-semibold text-stone-900 tabular-nums">
                      {formatPrice(fin.totalAccommodationCostEUR)}
                    </span>
                  </div>

                  <div className="flex justify-between text-stone-600">
                    <span>Procenjen džeparac / hrana:</span>
                    <span className="font-semibold text-stone-500 tabular-nums">
                      ~{formatPrice(fin.recommendedSpendingTotalEUR)}
                    </span>
                  </div>
                </div>

                {/* Total Sum */}
                <div className="bg-white p-3.5 rounded-xl border border-stone-200">
                  <div className="flex items-baseline justify-between mb-1">
                    <span className="text-xs text-stone-600 font-medium">Ukupno za platiti:</span>
                    <span className="font-display text-2xl font-bold text-stone-900 tabular-nums">
                      {formatPrice(fin.totalBaseCostEUR)}
                    </span>
                  </div>
                  {persons > 1 && (
                    <div className="text-right text-[11px] text-stone-500 tabular-nums">
                      {formatPrice(fin.costPerPersonEUR)} po osobi
                    </div>
                  )}

                  {/* Budget comparison */}
                  <div className="mt-3 pt-3 border-t border-stone-100">
                    {fin.isWithinBudget ? (
                      <div className="text-xs font-semibold text-emerald-800 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Ostaje ti {formatPrice(fin.remainingBudgetEUR)} iz budžeta!</span>
                      </div>
                    ) : (
                      <div className="text-xs font-medium text-amber-800 flex items-center gap-1.5">
                        <AlertCircle className="w-4 h-4 text-amber-600" />
                        <span>Prekoračuje budžet za {formatPrice(Math.abs(fin.remainingBudgetEUR))}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Agency Benchmark Comparison */}
                {fin.savingsEUR > 0 && (
                  <div className="bg-emerald-50/90 border border-emerald-200 rounded-xl p-3.5 text-xs space-y-1.5">
                    <div className="flex items-center justify-between text-stone-600">
                      <span className="flex items-center gap-1.5 font-medium">
                        <Building2 className="w-3.5 h-3.5 text-stone-500" />
                        Agencijski paket ({persons} {persons === 1 ? 'osoba' : 'osobe'}):
                      </span>
                      <span className="line-through text-stone-400 font-semibold tabular-nums">
                        ~{formatPrice(fin.totalAgencyCostEUR)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-emerald-950 font-bold">
                      <span className="flex items-center gap-1.5">
                        <TrendingDown className="w-3.5 h-3.5 text-emerald-600" />
                        Tvoja direktna ušteda:
                      </span>
                      <span className="text-emerald-700 font-extrabold text-sm tabular-nums">
                        {formatPrice(fin.savingsEUR)} (-{fin.savingsPercentage}%)
                      </span>
                    </div>
                    <p className="text-[10px] text-emerald-800/80 leading-tight pt-1.5 border-t border-emerald-200/60">
                      Ušteda ostvarena samostalnim kombinovanjem bez agencijskih marži i provizija.
                    </p>
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => setActiveTab('rezervacija')}
                  className="cursor-pointer w-full py-3 px-4 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-2 shadow-sm"
                >
                  <span>Nastavi ka rezervaciji</span>
                  <ChevronRight className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-2 text-[11px] text-stone-500">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Garancija tačnosti proračuna i bez skrivenih troškova</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'itinerer' && (
            <div className="space-y-6">
              <div>
                <h4 className="font-display font-bold text-stone-900 text-lg mb-2">
                  Šta posetiti u mestu {pkg.destinationName}
                </h4>
                <p className="text-xs text-stone-600 mb-4">
                  Ključne znamenitosti i atrakcije koje vredi obići tokom boravka.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {pkg.whatToSee.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 text-xs text-stone-800 font-medium flex items-center gap-2.5"
                    >
                      <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 font-bold flex items-center justify-center shrink-0">
                        {idx + 1}
                      </span>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-amber-50/60 rounded-2xl p-5 border border-amber-200/80">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-900 uppercase tracking-wider mb-2">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>Preporučeni raspored za {nights} noćenja</span>
                </div>
                <div className="space-y-3 text-xs text-stone-700">
                  <p>
                    <strong>Dan 1:</strong> Dolazak prevozom ({fin.transport.provider}), prijava u{' '}
                    {fin.accommodation.name}, popodnevna lagana šetnja i lokalni obrok.
                  </p>
                  <p>
                    <strong>Dan 2:</strong> Glavni dan za obilaske: {pkg.whatToSee[0]} i{' '}
                    {pkg.whatToSee[1] || 'relaksaciju'}.
                  </p>
                  {nights > 2 && (
                    <p>
                      <strong>Dan 3:</strong> Izlet u prirodu, odmor ili šoping. Večernji opušteni
                      izlazak.
                    </p>
                  )}
                  <p>
                    <strong>Zadnji dan:</strong> Odjava, kafa pred polazak i povratak u{' '}
                    {fin.transport.originCity}.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'saveti' && (
            <div className="space-y-4">
              <h4 className="font-display font-bold text-stone-900 text-lg mb-2">
                Kako maksimalno uštedeti u mestu {pkg.destinationName}
              </h4>
              <div className="space-y-3">
                {pkg.budgetTips.map((tip, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-stone-50 rounded-xl border border-stone-200 text-xs text-stone-700 flex items-start gap-3"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span className="leading-relaxed">{tip}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'rezervacija' && (
            <div className="max-w-xl mx-auto">
              {!bookingConfirmed ? (
                <form onSubmit={handleBookingSubmit} className="space-y-4">
                  <div>
                    <h4 className="font-display font-bold text-stone-900 text-lg mb-1">
                      Simulacija rezervacije i slanje vaučera
                    </h4>
                    <p className="text-xs text-stone-600">
                      Unesi osnovne podatke kako bi generisao personalizovan plan putovanja i sačuvao cenu.
                    </p>
                  </div>

                  <div className="bg-stone-50 p-4 rounded-xl border border-stone-200 space-y-3">
                    <div className="flex justify-between text-xs">
                      <span className="text-stone-500">Izabrani paket:</span>
                      <span className="font-semibold text-stone-900">{pkg.title}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-stone-500">Prevoz i smeštaj:</span>
                      <span className="font-semibold text-stone-900">
                        {fin.transport.provider} + {fin.accommodation.name}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-stone-500">Ukupno za uplatu:</span>
                      <span className="font-bold text-stone-900 tabular-nums">
                        {formatPrice(fin.totalBaseCostEUR)}
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-stone-700 block mb-1">
                      Ime i prezime putnika
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="npr. Marko Marković"
                      value={guestName}
                      onChange={(e) => setGuestName(e.target.value)}
                      className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-sm text-stone-800 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-stone-700 block mb-1">
                        Broj telefona ili Email
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="+381 6..."
                        value={guestContact}
                        onChange={(e) => setGuestContact(e.target.value)}
                        className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-sm text-stone-800 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-stone-700 block mb-1">
                        Datum polaska
                      </label>
                      <input
                        type="date"
                        value={travelDate}
                        onChange={(e) => setTravelDate(e.target.value)}
                        className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-sm text-stone-800 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="cursor-pointer w-full py-3 px-4 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-2 shadow-sm"
                  >
                    <Send className="w-4 h-4" />
                    <span>Generiši vaučer i plan putovanja</span>
                  </button>
                </form>
              ) : (
                <div className="bg-emerald-50 rounded-2xl p-6 border border-emerald-200 text-center space-y-4">
                  <div className="w-12 h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>

                  <div>
                    <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider block">
                      Potvrda plana putovanja
                    </span>
                    <h3 className="font-display text-xl font-bold text-stone-900">
                      Vaučer #{bookingRefNumber} uspešno kreiran!
                    </h3>
                    <p className="text-xs text-stone-600 mt-1">
                      Poštovani <strong>{guestName}</strong>, vaša rezervacija za{' '}
                      <strong>{pkg.destinationName}</strong> ({nights} noći, {persons} putnika)
                      sa polaskom {travelDate} je evidentirana.
                    </p>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-emerald-100 text-left text-xs space-y-2">
                    <div className="flex justify-between">
                      <span className="text-stone-500">Prevoznik:</span>
                      <span className="font-semibold text-stone-800">{fin.transport.provider}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">Smeštaj:</span>
                      <span className="font-semibold text-stone-800">{fin.accommodation.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">Ukupan iznos paketa:</span>
                      <span className="font-bold text-stone-900">{formatPrice(fin.totalBaseCostEUR)}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-3 pt-2">
                    <button
                      onClick={() => window.print()}
                      className="cursor-pointer px-4 py-2 bg-stone-900 text-white text-xs font-semibold rounded-lg hover:bg-stone-800 transition-colors flex items-center gap-1.5"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Štampaj / Sačuvaj PDF</span>
                    </button>
                    <button
                      onClick={() => setBookingConfirmed(false)}
                      className="cursor-pointer px-4 py-2 bg-white border border-stone-300 text-stone-700 text-xs font-semibold rounded-lg hover:bg-stone-100 transition-colors"
                    >
                      Izmeni podatke
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
