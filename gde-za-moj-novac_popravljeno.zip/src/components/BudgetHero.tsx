import React, { useState, useEffect } from 'react';
import {
  DestinationCategory,
  SearchFilters,
  TransportType,
} from '../types/travel';
import { EUR_TO_RSD_RATE, IMAGES } from '../services/travelApi';
import { getLiveExchangeRate, LiveExchangeRateInfo } from '../services/liveApis';
import { MapPin, Users, Euro, Sparkles } from 'lucide-react';

import { CityCombobox } from './CityCombobox';

interface BudgetHeroProps {
  filters: SearchFilters;
  onFilterChange: <K extends keyof SearchFilters>(key: K, value: SearchFilters[K]) => void;
  onQuickPreset: (amountEUR: number) => void;
  totalMatches: number;
  onScrollToResults: () => void;
}

export const CITIES = [
  'Svi gradovi',
  'Beograd',
  'Novi Sad',
  'Niš',
  'Kragujevac',
  'Subotica',
  'Sarajevo',
  'Banjaluka',
  'Podgorica',
  'Skoplje',
];

export const CATEGORIES: { id: DestinationCategory | 'sve'; label: string }[] = [
  { id: 'sve', label: 'Sve destinacije' },
  { id: 'banje', label: 'Banje i Spa' },
  { id: 'jezera', label: 'Jezera' },
  { id: 'planine', label: 'Planine' },
  { id: 'more', label: 'More i obala' },
  { id: 'gradovi', label: 'Evropski gradovi' },
];

export const TRANSPORTS: { id: TransportType | 'sve'; label: string }[] = [
  { id: 'sve', label: 'Bilo koji prevoz' },
  { id: 'bus', label: 'Autobus' },
  { id: 'flight', label: 'Avion' },
  { id: 'car', label: 'Sopstveni auto' },
];

const PRESETS = [100, 150, 200, 250, 300, 450];

export const BudgetHero: React.FC<BudgetHeroProps> = ({
  filters,
  onFilterChange,
  onQuickPreset,
  totalMatches,
  onScrollToResults,
}) => {
  const [liveRate, setLiveRate] = useState<LiveExchangeRateInfo | null>(null);

  useEffect(() => {
    getLiveExchangeRate().then((res) => {
      if (res) setLiveRate(res);
    });
  }, []);

  const rateVal = liveRate?.rate || EUR_TO_RSD_RATE;
  const currentRSD = Math.round(filters.maxBudgetEUR * rateVal);

  return (
    <div className="relative bg-stone-900 text-white overflow-hidden border-b border-stone-800">
      {/* Background Photography with Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src={IMAGES.hero}
          alt="Balkanski pejzaž i planinsko jezero"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-40 scale-105"
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1600&q=80';
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-900/80 to-stone-950/60" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-16 lg:pt-16 lg:pb-20">
        {/* Editorial Header */}
        <div className="max-w-3xl">
          <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-amber-300 tracking-wider uppercase mb-3">
            <span>Pametna regionalna turistička platforma</span>
            <span aria-hidden="true">·</span>
            <span>Srbija & Balkan</span>
            {liveRate && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-400 font-bold bg-emerald-950/70 px-2 py-0.5 rounded border border-emerald-500/30 normal-case tracking-normal flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Kurs uživo: 1 € = {liveRate.rate} RSD (ECB)</span>
                </span>
              </>
            )}
          </div>

          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white text-balance leading-tight mb-4">
            Koliko novca imaš? Mi ti pronalazimo celo putovanje.
          </h1>

          <p className="text-base sm:text-lg text-stone-300 leading-relaxed max-w-2xl text-pretty mb-8">
            Kombinujemo autobuske i avionske rute sa pristupačnim hotelima i apartmanima.
            Izaberi budžet i odmah vidi gde možeš da otputuješ bez skrivenih troškova.
          </p>
        </div>

        {/* Master Interactive Search Console */}
        <div className="bg-white text-stone-900 rounded-2xl p-5 sm:p-7 shadow-2xl border border-stone-200/80 backdrop-blur-md">
          {/* Preset Buttons Bar */}
          <div className="flex flex-wrap items-center gap-2 mb-6">
            <span className="text-xs font-medium text-stone-500 mr-2 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              Brzi izbor budžeta:
            </span>
            {PRESETS.map((amt) => {
              const isSelected = filters.maxBudgetEUR === amt;
              return (
                <button
                  key={amt}
                  type="button"
                  onClick={() => onQuickPreset(amt)}
                  className={`cursor-pointer px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                    isSelected
                      ? 'bg-amber-600 text-white shadow-sm ring-2 ring-amber-600/30'
                      : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                  }`}
                >
                  {amt} €{' '}
                  <span className="text-[11px] opacity-75 font-normal">
                    ({Math.round(amt * EUR_TO_RSD_RATE).toLocaleString()} din)
                  </span>
                </button>
              );
            })}
          </div>

          {/* Main Controls Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {/* 1. Budget Slider / Input */}
            <div className="bg-stone-50 rounded-xl p-3.5 border border-stone-200">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-stone-700 flex items-center gap-1.5">
                  <Euro className="w-4 h-4 text-amber-600" />
                  Maksimalni budžet
                </label>
                <span className="text-xs text-stone-500 tabular-nums">
                  ≈ {currentRSD.toLocaleString()} RSD
                </span>
              </div>
              <div className="flex items-baseline gap-2 mb-2">
                <span className="font-display text-2xl font-bold text-stone-900 tabular-nums">
                  {filters.maxBudgetEUR} €
                </span>
                <span className="text-xs text-stone-500 font-medium">ukupno za put</span>
              </div>
              <input
                type="range"
                min="50"
                max="600"
                step="10"
                value={filters.maxBudgetEUR}
                onChange={(e) => onFilterChange('maxBudgetEUR', Number(e.target.value))}
                className="w-full h-2 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-amber-600"
              />
              <div className="flex justify-between text-[10px] text-stone-400 mt-1">
                <span>50 €</span>
                <span>300 €</span>
                <span>600 €</span>
              </div>
            </div>

            {/* 2. Departure City */}
            <div className="bg-stone-50 rounded-xl p-3.5 border border-stone-200">
              <label className="text-xs font-semibold text-stone-700 flex items-center justify-between gap-1.5 mb-2">
                <span className="flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-amber-600" />
                  Mesto polaska
                </span>
                <span className="text-[10px] text-stone-500 font-normal">Srbija & Region</span>
              </label>
              <CityCombobox
                value={filters.originCity}
                onChange={(city) => onFilterChange('originCity', city)}
                variant="hero"
              />
              <p className="text-[11px] text-stone-500 mt-2">
                Izaberi ili slobodno upiši bilo koje svoje mesto
              </p>
            </div>

            {/* 3. Persons */}
            <div className="bg-stone-50 rounded-xl p-3.5 border border-stone-200">
              <label className="text-xs font-semibold text-stone-700 flex items-center gap-1.5 mb-2">
                <Users className="w-4 h-4 text-amber-600" />
                Broj putnika
              </label>
              <div className="grid grid-cols-4 gap-1">
                {[1, 2, 3, 4].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => onFilterChange('persons', num)}
                    className={`cursor-pointer py-2 text-xs font-semibold rounded-lg transition-colors ${
                      filters.persons === num
                        ? 'bg-stone-900 text-white'
                        : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    {num} {num === 1 ? 'osoba' : 'osobe'}
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-stone-500 mt-2">
                Kalkuliše trošak po osobi i po sobi
              </p>
            </div>

            {/* 4. Transport Filter */}
            <div className="bg-stone-50 rounded-xl p-3.5 border border-stone-200">
              <label className="text-xs font-semibold text-stone-700 flex items-center gap-1.5 mb-2">
                <span>Vrsta prevoza</span>
              </label>
              <select
                value={filters.transportType}
                onChange={(e) =>
                  onFilterChange('transportType', e.target.value as TransportType | 'sve')
                }
                className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-sm font-medium text-stone-800 focus:ring-2 focus:ring-amber-500 focus:outline-none"
              >
                {TRANSPORTS.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.label}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-stone-500 mt-2">
                FlixBus, Niš-Ekspres, Wizz Air, Air Serbia
              </p>
            </div>
          </div>

          {/* Category Filter Tabs & CTA Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-stone-200">
            {/* Category Segmented Buttons */}
            <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
              {CATEGORIES.map((cat) => {
                const isActive = filters.category === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => onFilterChange('category', cat.id)}
                    className={`cursor-pointer px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                      isActive
                        ? 'bg-amber-600 text-white'
                        : 'bg-stone-100 text-stone-600 hover:text-stone-900 hover:bg-stone-200'
                    }`}
                  >
                    {cat.label}
                  </button>
                );
              })}
            </div>

            {/* Match Counter & Scroll CTA */}
            <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
              <div className="text-right hidden sm:block">
                <div className="text-xs font-bold text-stone-900 tabular-nums">
                  {totalMatches} dostupnih opcija
                </div>
                <div className="text-[11px] text-emerald-700 font-medium">
                  Uklopljeno u tvoj budžet
                </div>
              </div>
              <button
                type="button"
                onClick={onScrollToResults}
                className="cursor-pointer w-full sm:w-auto px-5 py-2.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-xl transition-colors shadow-sm flex items-center justify-center gap-2"
              >
                <span>Prikaži ponude ({totalMatches})</span>
                <span>→</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
