import React, { useState, useEffect } from 'react';
import {
  X,
  Layers,
  Code,
  CheckCircle,
  ArrowRight,
  Activity,
  RefreshCw,
  Key,
  ExternalLink,
  Sun,
  DollarSign,
  MapPin,
  Plane,
  Building2,
  ShieldCheck,
} from 'lucide-react';
import {
  getLiveWeather,
  getLiveExchangeRate,
  searchCityCoordinates,
  verifyRapidApiKey,
  searchAirportsLive,
  verifyDuffelToken,
  searchDuffelFlightsLive,
  DEFAULT_RAPIDAPI_KEY,
  DEFAULT_DUFFEL_TOKEN,
  LiveWeatherInfo,
  LiveExchangeRateInfo,
  RapidApiVerificationResult,
  LiveAirportResult,
  DuffelFlightOffer,
  DuffelVerificationResult,
} from '../services/liveApis';

interface ApiArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApiArchitectureModal: React.FC<ApiArchitectureModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'status' | 'arhitektura'>('status');

  // Live test states
  const [weatherData, setWeatherData] = useState<LiveWeatherInfo | null>(null);
  const [exchangeData, setExchangeData] = useState<LiveExchangeRateInfo | null>(null);
  const [isLoadingWeather, setIsLoadingWeather] = useState(false);
  const [isLoadingExchange, setIsLoadingExchange] = useState(false);
  const [testCity, setTestCity] = useState('Vranje');
  const [geoResult, setGeoResult] = useState<{ lat: number; lng: number; displayName: string } | null>(null);
  const [isLoadingGeo, setIsLoadingGeo] = useState(false);

  // RapidAPI tester state with default user key
  const [rapidKeyInput, setRapidKeyInput] = useState<string>(() => {
    try {
      return localStorage.getItem('gde_za_novac_rapid_key') || DEFAULT_RAPIDAPI_KEY;
    } catch {
      return DEFAULT_RAPIDAPI_KEY;
    }
  });
  const [rapidTestResult, setRapidTestResult] = useState<RapidApiVerificationResult | null>(null);
  const [isTestingRapid, setIsTestingRapid] = useState(false);

  // Live airport search test
  const [testAirportQuery, setTestAirportQuery] = useState('Serbia');
  const [airportsResult, setAirportsResult] = useState<LiveAirportResult[]>([]);
  const [isLoadingAirports, setIsLoadingAirports] = useState(false);

  // Duffel.com API state
  const [duffelTokenInput, setDuffelTokenInput] = useState<string>(() => {
    try {
      return localStorage.getItem('gde_za_novac_duffel_token') || DEFAULT_DUFFEL_TOKEN;
    } catch {
      return DEFAULT_DUFFEL_TOKEN;
    }
  });
  const [duffelTestResult, setDuffelTestResult] = useState<DuffelVerificationResult | null>(null);
  const [isTestingDuffel, setIsTestingDuffel] = useState(false);
  const [duffelOriginIata, setDuffelOriginIata] = useState('BEG');
  const [duffelDestIata, setDuffelDestIata] = useState('FCO');
  const [duffelOffers, setDuffelOffers] = useState<DuffelFlightOffer[]>([]);
  const [isLoadingDuffelOffers, setIsLoadingDuffelOffers] = useState(false);

  useEffect(() => {
    if (isOpen) {
      handleTestWeather();
      handleTestExchange();
      handleTestGeo('Vranje');
      // Auto-verify active RapidAPI key
      const keyToUse = localStorage.getItem('gde_za_novac_rapid_key') || DEFAULT_RAPIDAPI_KEY;
      setIsTestingRapid(true);
      verifyRapidApiKey(keyToUse).then((res) => {
        setRapidTestResult(res);
        setIsTestingRapid(false);
      });
      // Initial live airports test
      setIsLoadingAirports(true);
      searchAirportsLive('Serbia', keyToUse).then((list) => {
        setAirportsResult(list);
        setIsLoadingAirports(false);
      });

      // Auto-verify Duffel.com token
      const tokenToUse = localStorage.getItem('gde_za_novac_duffel_token') || DEFAULT_DUFFEL_TOKEN;
      setIsTestingDuffel(true);
      verifyDuffelToken(tokenToUse).then((res) => {
        setDuffelTestResult(res);
        setIsTestingDuffel(false);
      });

      // Initial Duffel live flights test (BEG -> FCO)
      setIsLoadingDuffelOffers(true);
      searchDuffelFlightsLive('BEG', 'FCO', undefined, tokenToUse).then((list) => {
        setDuffelOffers(list);
        setIsLoadingDuffelOffers(false);
      });
    }
  }, [isOpen]);

  const handleTestWeather = async () => {
    setIsLoadingWeather(true);
    // Belgrade coordinates
    const res = await getLiveWeather(44.8176, 20.4633);
    setWeatherData(res);
    setIsLoadingWeather(false);
  };

  const handleTestExchange = async () => {
    setIsLoadingExchange(true);
    const res = await getLiveExchangeRate();
    setExchangeData(res);
    setIsLoadingExchange(false);
  };

  const handleTestGeo = async (city: string) => {
    setIsLoadingGeo(true);
    const res = await searchCityCoordinates(city);
    setGeoResult(res);
    setIsLoadingGeo(false);
  };

  const handleTestRapidKey = async (overrideKey?: string) => {
    const keyToTest = (overrideKey !== undefined ? overrideKey : rapidKeyInput).trim();
    if (!keyToTest) return;
    setIsTestingRapid(true);
    try {
      localStorage.setItem('gde_za_novac_rapid_key', keyToTest);
    } catch {
      // ignore
    }
    const result = await verifyRapidApiKey(keyToTest);
    setRapidTestResult(result);
    setIsTestingRapid(false);

    // Refresh live airports
    setIsLoadingAirports(true);
    const list = await searchAirportsLive(testAirportQuery, keyToTest);
    setAirportsResult(list);
    setIsLoadingAirports(false);
  };

  const handleSearchLiveAirports = async () => {
    if (!testAirportQuery.trim()) return;
    setIsLoadingAirports(true);
    const list = await searchAirportsLive(testAirportQuery, rapidKeyInput);
    setAirportsResult(list);
    setIsLoadingAirports(false);
  };

  const handleTestDuffelToken = async (overrideToken?: string) => {
    const tokenToTest = (overrideToken !== undefined ? overrideToken : duffelTokenInput).trim();
    if (!tokenToTest) return;
    setIsTestingDuffel(true);
    try {
      localStorage.setItem('gde_za_novac_duffel_token', tokenToTest);
    } catch {
      // ignore
    }
    const result = await verifyDuffelToken(tokenToTest);
    setDuffelTestResult(result);
    setIsTestingDuffel(false);

    // Refresh flight search with this token
    handleSearchDuffelFlights(tokenToTest);
  };

  const handleSearchDuffelFlights = async (tokenToUse?: string) => {
    setIsLoadingDuffelOffers(true);
    const offers = await searchDuffelFlightsLive(
      duffelOriginIata,
      duffelDestIata,
      undefined,
      tokenToUse || duffelTokenInput
    );
    setDuffelOffers(offers);
    setIsLoadingDuffelOffers(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden border border-stone-200">
        {/* Header */}
        <div className="p-6 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center font-bold">
              <Layers className="w-5 h-5 text-amber-700" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-stone-900">
                API Servisi & Tehnička Integracija
              </h3>
              <p className="text-xs text-stone-500">
                Pregled aktivnih otvorenih servisa i besplatnih turističkih API ključeva
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="cursor-pointer p-2 rounded-full hover:bg-stone-200 text-stone-600 transition-colors"
            aria-label="Zatvori prozor"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 px-6 pt-4 border-b border-stone-200 bg-white">
          <button
            onClick={() => setActiveTab('status')}
            className={`cursor-pointer pb-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'status'
                ? 'border-amber-600 text-amber-900'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Activity className="w-4 h-4 text-emerald-600" />
            <span>Aktivni servisi & Besplatni ključevi (Uživo)</span>
          </button>
          <button
            onClick={() => setActiveTab('arhitektura')}
            className={`cursor-pointer pb-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'arhitektura'
                ? 'border-amber-600 text-amber-900'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Code className="w-4 h-4 text-sky-600" />
            <span>Struktura koda & DTO modeli</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-xs text-stone-700 leading-relaxed">
          {activeTab === 'status' && (
            <div className="space-y-6">
              {/* Introduction Banner */}
              <div className="bg-emerald-50/80 rounded-2xl p-4 border border-emerald-200/80 flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-emerald-950 text-xs mb-1">
                    Aplikacija već koristi 3 100% besplatna živa API izvora bez potrebe za ključem
                  </h4>
                  <p className="text-stone-700 text-xs leading-relaxed">
                    Za osnovne funkcije putovanja (vremenska prognoza, realni kurs dinara u odnosu na evro,
                    i geolokacija bilo kog grada na Balkanu), povezali smo javne servise koji rade odmah i
                    ne zahtevaju nikakvu registraciju ili plaćanje. Ispod možete videti njihov živi status.
                  </p>
                </div>
              </div>

              {/* 3 Active Live Services Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* 1. Live Weather */}
                <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
                          <Sun className="w-4 h-4" />
                        </div>
                        <span className="font-bold text-stone-900 text-xs">Open-Meteo Weather</span>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                        Aktivan uživo
                      </span>
                    </div>

                    <p className="text-[11px] text-stone-600 mb-3">
                      Meteorološki API bez limita i bez ključa. Prikazuje trenutno vreme i temperaturu za svaku destinaciju.
                    </p>

                    {weatherData ? (
                      <div className="bg-white p-2.5 rounded-xl border border-stone-200 space-y-1 text-[11px]">
                        <div className="text-stone-500">Test Beograd (trenutno):</div>
                        <div className="flex items-center gap-2 font-bold text-stone-900 text-sm">
                          <span>{weatherData.icon}</span>
                          <span>{weatherData.temperature}°C</span>
                          <span className="font-normal text-xs text-stone-600">· {weatherData.conditionText}</span>
                        </div>
                        <div className="text-[10px] text-stone-400">Vetar: {weatherData.windSpeed} km/h</div>
                      </div>
                    ) : (
                      <div className="text-stone-400 text-center py-2">Učitavanje podataka...</div>
                    )}
                  </div>

                  <button
                    onClick={handleTestWeather}
                    disabled={isLoadingWeather}
                    className="cursor-pointer mt-3 w-full py-1.5 px-3 bg-white border border-stone-200 hover:bg-stone-100 text-stone-800 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1.5"
                  >
                    <RefreshCw className={`w-3 h-3 ${isLoadingWeather ? 'animate-spin' : ''}`} />
                    <span>Osveži vremenske podatke</span>
                  </button>
                </div>

                {/* 2. Live Exchange Rate */}
                <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                          <DollarSign className="w-4 h-4" />
                        </div>
                        <span className="font-bold text-stone-900 text-xs">Kurs EUR ➔ RSD</span>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                        Aktivan uživo
                      </span>
                    </div>

                    <p className="text-[11px] text-stone-600 mb-3">
                      Direktan feed Evropske centralne banke. Automatski preračunava budžet u dinare.
                    </p>

                    {exchangeData ? (
                      <div className="bg-white p-2.5 rounded-xl border border-stone-200 space-y-1 text-[11px]">
                        <div className="text-stone-500">Zvanični kurs:</div>
                        <div className="font-bold text-stone-900 text-base">
                          1 € = {exchangeData.rate} RSD
                        </div>
                        <div className="text-[10px] text-stone-400">Izvor: {exchangeData.provider}</div>
                      </div>
                    ) : (
                      <div className="text-stone-400 text-center py-2">Učitavanje kursa...</div>
                    )}
                  </div>

                  <button
                    onClick={handleTestExchange}
                    disabled={isLoadingExchange}
                    className="cursor-pointer mt-3 w-full py-1.5 px-3 bg-white border border-stone-200 hover:bg-stone-100 text-stone-800 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1.5"
                  >
                    <RefreshCw className={`w-3 h-3 ${isLoadingExchange ? 'animate-spin' : ''}`} />
                    <span>Osveži kursnu listu</span>
                  </button>
                </div>

                {/* 3. OpenStreetMap Geocoding */}
                <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
                          <MapPin className="w-4 h-4" />
                        </div>
                        <span className="font-bold text-stone-900 text-xs">OSM Nominatim Geo</span>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                        Aktivan uživo
                      </span>
                    </div>

                    <p className="text-[11px] text-stone-600 mb-2">
                      Pronalazi GPS koordinate za bilo koje mesto na Balkanu i računa distancu.
                    </p>

                    <div className="flex gap-1.5 mb-2">
                      <input
                        type="text"
                        value={testCity}
                        onChange={(e) => setTestCity(e.target.value)}
                        className="w-full px-2 py-1 bg-white border border-stone-300 rounded text-xs"
                        placeholder="Npr. Vranje, Pirot, Bar..."
                      />
                      <button
                        onClick={() => handleTestGeo(testCity)}
                        className="px-2.5 py-1 bg-stone-900 text-white rounded text-[11px] font-bold"
                      >
                        Nađi
                      </button>
                    </div>

                    {geoResult && (
                      <div className="bg-white p-2 rounded-lg border border-stone-200 text-[10px] text-stone-600 space-y-0.5">
                        <div className="font-semibold text-stone-900 truncate">{geoResult.displayName}</div>
                        <div>GPS: {geoResult.lat.toFixed(4)}, {geoResult.lng.toFixed(4)}</div>
                      </div>
                    )}
                  </div>

                  <div className="mt-3 text-[10px] text-stone-400 text-center">
                    Automatski računa gorivo i putarine ako nema autobusa
                  </div>
                </div>
              </div>

              {/* Free Tier Commercial APIs Guide */}
              <div className="bg-white rounded-2xl border border-stone-200 p-5 space-y-4 shadow-sm">
                <div className="flex items-center gap-2 text-stone-900 font-display font-bold text-sm">
                  <Key className="w-4 h-4 text-amber-600" />
                  <span>Besplatni API ključevi za avio-karte i hotele (Free Tiers)</span>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Da biste povlačili stvarne redove letenja i cene karata u realnom vremenu za pretragu letova (Wizz Air, Ryanair, Air Serbia),
                  možete se besplatno registrovati na sledećim servisima koji pružaju besplatne pakete za programere:
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                  {/* Duffel.com - AKTIVNO */}
                  <div className="p-3.5 rounded-xl border border-emerald-300 bg-emerald-50/60 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-emerald-950 text-xs flex items-center gap-1.5">
                        <Plane className="w-4 h-4 text-emerald-700" />
                        <span>Duffel.com Flights API</span>
                      </span>
                      <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                        4.000 upita / min · AKTIVNO
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-700 leading-normal">
                      Zvanični agregator vodećih svetskih avio-kompanija (Lufthansa, Air Serbia, Ryanair, Wizz Air).
                      Vaš uneti token <code>duffel_test_...</code> je uspešno povezan i proveren uživo!
                    </p>
                    <a
                      href="https://duffel.com/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] text-emerald-900 font-semibold hover:underline"
                    >
                      <span>Zvanična Duffel dokumentacija</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  {/* Kiwi */}
                  <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                        <Plane className="w-4 h-4 text-sky-600" />
                        <span>Kiwi Tequila API</span>
                      </span>
                      <span className="text-[10px] font-semibold text-sky-800 bg-sky-100 px-2 py-0.5 rounded">
                        10.000 upita / mes. BESPLATNO
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-600 leading-normal">
                      Agregator za niskotarifne letove iz Niša, Beograda, Skoplja i Budimpešte.
                      Besplatna registracija na <code>tequila.kiwi.com</code>.
                    </p>
                    <a
                      href="https://tequila.kiwi.com/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] text-amber-800 font-semibold hover:underline"
                    >
                      <span>Registruj besplatan Kiwi nalog</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  {/* Amadeus */}
                  <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                        <Plane className="w-4 h-4 text-stone-700" />
                        <span>Amadeus for Developers</span>
                      </span>
                      <span className="text-[10px] font-semibold text-stone-800 bg-stone-200 px-2 py-0.5 rounded">
                        2.000 upita / mes. BESPLATNO
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-600 leading-normal">
                      Zvanični GDS sistem koji koriste najveće svetske avio-kompanije.
                      Daje direktne cene i pretragu najjeftinijih letova za bilo koji zadati budžet.
                    </p>
                    <a
                      href="https://developers.amadeus.com/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] text-amber-800 font-semibold hover:underline"
                    >
                      <span>Preuzmi besplatan Amadeus ključ</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  {/* Booking */}
                  <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                        <Building2 className="w-4 h-4 text-emerald-600" />
                        <span>Booking.com (preko RapidAPI)</span>
                      </span>
                      <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                        500 upita / mes. BESPLATNO
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-600 leading-normal">
                      Omogućava pretragu privatnog smeštaja, soba i hotela sa cenama, slikama i recenzijama u realnom vremenu.
                    </p>
                    <a
                      href="https://rapidapi.com/collection/booking-apis"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] text-amber-800 font-semibold hover:underline"
                    >
                      <span>RapidAPI Booking nalog</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  {/* BalkanViator / Bus Scraper */}
                  <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-stone-900 text-xs">Regionalni Autobusi (BalkanViator)</span>
                      <span className="text-[10px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                        Otvoren web pristup
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-600 leading-normal">
                      Baza redova vožnje međugradskih autobusa (Lasta, Niš-Ekspres, BS Tours, Božur)
                      koju naš sistem u pozadini mapira prema zadatim destinacijama.
                    </p>
                  </div>
                </div>

                {/* Interactive RapidAPI Key Tester Widget */}
                <div className="bg-stone-50 rounded-2xl p-4 sm:p-5 border border-stone-200 space-y-3 mt-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                        <Key className="w-4 h-4 text-emerald-700" />
                      </div>
                      <div>
                        <h4 className="font-bold text-stone-900 text-xs">
                          Testiraj svoj RapidAPI ključ uživo
                        </h4>
                        <span className="text-[10px] text-stone-500">
                          Upiši ili nalepi ključ kako bismo proverili da li je aktivan
                        </span>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                      Direktan test
                    </span>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2">
                    <input
                      type="text"
                      value={rapidKeyInput}
                      onChange={(e) => setRapidKeyInput(e.target.value)}
                      placeholder="Nalepi svoj RapidAPI ključ (npr. a1b2c3d4...)"
                      className="flex-1 px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs font-mono text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-600"
                    />
                    <button
                      onClick={() => handleTestRapidKey()}
                      disabled={isTestingRapid || !rapidKeyInput.trim()}
                      className="cursor-pointer px-4 py-2 bg-stone-900 hover:bg-stone-800 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shrink-0 shadow-sm"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isTestingRapid ? 'animate-spin' : ''}`} />
                      <span>{isTestingRapid ? 'Proveravam...' : 'Proveri ključ'}</span>
                    </button>
                  </div>

                  {rapidTestResult && (
                    <div
                      className={`p-3.5 rounded-xl border text-xs space-y-2 transition-all ${
                        rapidTestResult.isValid
                          ? 'bg-emerald-50/90 border-emerald-300 text-emerald-950'
                          : 'bg-rose-50/90 border-rose-300 text-rose-950'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between font-bold text-xs gap-2">
                        <span className="flex items-center gap-1.5">
                          <CheckCircle className="w-4 h-4 text-emerald-600" />
                          <span>{rapidTestResult.statusText}</span>
                        </span>
                        {rapidTestResult.remainingQuota && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">
                            {rapidTestResult.remainingQuota}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] leading-relaxed opacity-90">
                        {rapidTestResult.details}
                      </p>

                      {/* Live Airport Query Test Box */}
                      {rapidTestResult.isValid && (
                        <div className="pt-2 border-t border-emerald-200/80 mt-2 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-bold text-stone-800 flex items-center gap-1">
                              <Plane className="w-3.5 h-3.5 text-sky-600" />
                              <span>Probaj pretragu aerodroma uživo preko ovog API-ja:</span>
                            </span>
                            <span className="text-[10px] text-stone-500">Google Flights 2</span>
                          </div>

                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={testAirportQuery}
                              onChange={(e) => setTestAirportQuery(e.target.value)}
                              placeholder="Unesi zemlju ili grad (npr. Serbia, Rome, Budapest)..."
                              className="flex-1 px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs"
                            />
                            <button
                              onClick={handleSearchLiveAirports}
                              disabled={isLoadingAirports}
                              className="cursor-pointer px-3 py-1.5 bg-stone-900 text-white rounded-lg text-xs font-bold shrink-0 flex items-center gap-1"
                            >
                              <RefreshCw className={`w-3 h-3 ${isLoadingAirports ? 'animate-spin' : ''}`} />
                              <span>Pretraži</span>
                            </button>
                          </div>

                          {/* Airport Results List */}
                          {airportsResult.length > 0 && (
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                              {airportsResult.map((a, idx) => (
                                <div key={idx} className="bg-white p-2 rounded-lg border border-stone-200 text-[11px]">
                                  <div className="font-bold text-stone-900 flex items-center justify-between">
                                    <span>{a.code}</span>
                                    <span className="text-[9px] bg-sky-50 text-sky-800 font-bold px-1 rounded">IATA</span>
                                  </div>
                                  <div className="text-stone-700 font-medium truncate">{a.name}</div>
                                  <div className="text-[10px] text-stone-400 truncate">{a.city}</div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Interactive Duffel.com Live Flights & Token Widget */}
                <div className="bg-stone-50 rounded-2xl p-4 sm:p-5 border border-stone-200 space-y-3 mt-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-sky-100 text-sky-800 flex items-center justify-center font-bold">
                        <Plane className="w-4 h-4 text-sky-700" />
                      </div>
                      <div>
                        <h4 className="font-bold text-stone-900 text-xs">
                          Duffel.com API — Pretraga stvarnih letova uživo
                        </h4>
                        <span className="text-[10px] text-stone-500">
                          Pretražuje stvarne redove letenja i cene karata direktno iz GDS sistema (4.000 upita/min)
                        </span>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                      Duffel Token povezan
                    </span>
                  </div>

                  {/* Token Input Bar */}
                  <div className="flex flex-col sm:flex-row gap-2">
                    <input
                      type="text"
                      value={duffelTokenInput}
                      onChange={(e) => setDuffelTokenInput(e.target.value)}
                      placeholder="Duffel token (npr. duffel_test_...)"
                      className="flex-1 px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs font-mono text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-sky-500/30 focus:border-sky-600"
                    />
                    <button
                      onClick={() => handleTestDuffelToken()}
                      disabled={isTestingDuffel || !duffelTokenInput.trim()}
                      className="cursor-pointer px-4 py-2 bg-stone-900 hover:bg-stone-800 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shrink-0 shadow-sm"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isTestingDuffel ? 'animate-spin' : ''}`} />
                      <span>{isTestingDuffel ? 'Proveravam...' : 'Proveri token'}</span>
                    </button>
                  </div>

                  {/* Duffel Token Result Status Box */}
                  {duffelTestResult && (
                    <div
                      className={`p-3.5 rounded-xl border text-xs space-y-1.5 transition-all ${
                        duffelTestResult.isValid
                          ? 'bg-emerald-50/90 border-emerald-300 text-emerald-950'
                          : 'bg-rose-50/90 border-rose-300 text-rose-950'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between font-bold text-xs gap-2">
                        <span className="flex items-center gap-1.5">
                          <CheckCircle className="w-4 h-4 text-emerald-600" />
                          <span>{duffelTestResult.statusText}</span>
                        </span>
                        {duffelTestResult.remainingQuota && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">
                            Kvota: {duffelTestResult.remainingQuota}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] leading-relaxed opacity-90">
                        {duffelTestResult.details}
                      </p>
                    </div>
                  )}

                  {/* Duffel Live Route Flight Searcher */}
                  <div className="pt-2 border-t border-stone-200 mt-2 space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <span className="text-[11px] font-bold text-stone-800 flex items-center gap-1.5">
                        <Plane className="w-3.5 h-3.5 text-sky-600" />
                        <span>Pretraži prave avio karte za regionalne rute:</span>
                      </span>
                      <span className="text-[10px] text-stone-400">
                        Podaci direktno od avio-kompanija
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <div>
                        <label className="text-[10px] font-bold text-stone-500 uppercase block mb-1">
                          Polazni aerodrom:
                        </label>
                        <select
                          value={duffelOriginIata}
                          onChange={(e) => setDuffelOriginIata(e.target.value)}
                          className="w-full px-2.5 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-semibold text-stone-900"
                        >
                          <option value="BEG">BEG — Beograd Nikola Tesla</option>
                          <option value="INI">INI — Niš Konstantin Veliki</option>
                          <option value="SKP">SKP — Skoplje</option>
                          <option value="BUD">BUD — Budimpešta</option>
                          <option value="SOF">SOF — Sofija</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-stone-500 uppercase block mb-1">
                          Odredišni aerodrom:
                        </label>
                        <select
                          value={duffelDestIata}
                          onChange={(e) => setDuffelDestIata(e.target.value)}
                          className="w-full px-2.5 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-semibold text-stone-900"
                        >
                          <option value="FCO">FCO — Rim Fiumicino</option>
                          <option value="VIE">VIE — Beč Schwechat</option>
                          <option value="BUD">BUD — Budimpešta</option>
                          <option value="MUC">MUC — Minhen</option>
                          <option value="CDG">CDG — Pariz Charles de Gaulle</option>
                          <option value="ATH">ATH — Atina</option>
                        </select>
                      </div>

                      <div className="flex items-end">
                        <button
                          onClick={() => handleSearchDuffelFlights()}
                          disabled={isLoadingDuffelOffers}
                          className="cursor-pointer w-full py-1.5 px-3 bg-sky-900 hover:bg-sky-800 disabled:opacity-50 text-white rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-sm"
                        >
                          <RefreshCw className={`w-3.5 h-3.5 ${isLoadingDuffelOffers ? 'animate-spin' : ''}`} />
                          <span>{isLoadingDuffelOffers ? 'Tražim letove...' : 'Pronađi letove'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Live Flight Offers Results */}
                    {isLoadingDuffelOffers ? (
                      <div className="p-4 text-center bg-white rounded-xl border border-stone-200 text-xs text-stone-500">
                        <RefreshCw className="w-4 h-4 animate-spin mx-auto mb-1 text-sky-600" />
                        <span>Pretražujem ponude avio-kompanija preko Duffel sistema...</span>
                      </div>
                    ) : duffelOffers.length > 0 ? (
                      <div className="space-y-2 pt-1">
                        <div className="text-[11px] font-bold text-stone-700 flex items-center justify-between">
                          <span>
                            Pronađeno {duffelOffers.length} letova ({duffelOriginIata} ➔ {duffelDestIata}):
                          </span>
                          <span className="text-[10px] text-stone-400">Izvor: Duffel GDS feed</span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {duffelOffers.map((f) => (
                            <div
                              key={f.id}
                              className="bg-white p-3 rounded-xl border border-stone-200 hover:border-sky-300 transition-all shadow-xs space-y-1.5"
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  {f.airlineLogoUrl ? (
                                    <img
                                      src={f.airlineLogoUrl}
                                      alt={f.airlineName}
                                      className="w-5 h-5 object-contain"
                                      onError={(e) => {
                                        (e.target as HTMLElement).style.display = 'none';
                                      }}
                                    />
                                  ) : (
                                    <Plane className="w-4 h-4 text-sky-600" />
                                  )}
                                  <span className="font-bold text-stone-900 text-xs">{f.airlineName}</span>
                                </div>
                                <span className="font-display font-bold text-emerald-800 text-sm">
                                  {f.totalAmountEUR} €
                                  <span className="text-[10px] font-normal text-stone-500 block text-right">
                                    ~{Math.round(f.totalAmountEUR * 117.2).toLocaleString()} RSD
                                  </span>
                                </span>
                              </div>

                              <div className="flex items-center justify-between text-[11px] text-stone-600 pt-1 border-t border-stone-100">
                                <div>
                                  <span className="font-bold text-stone-900">{f.departingAt}</span> ({f.originIata}) ➔{' '}
                                  <span className="font-bold text-stone-900">{f.arrivingAt}</span> ({f.destinationIata})
                                </div>
                                <span className="text-stone-500 text-[10px]">{f.duration}</span>
                              </div>

                              <div className="flex items-center justify-between text-[10px] text-stone-400">
                                <span>
                                  Let: {f.flightNumber} · {f.aircraftName || 'Avion'}
                                </span>
                                <span className="bg-stone-100 text-stone-700 font-semibold px-1.5 py-0.5 rounded">
                                  {f.stopsCount === 0 ? 'Direktan let' : `${f.stopsCount} presedanje`}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 text-center bg-white rounded-xl border border-stone-200 text-[11px] text-stone-500">
                        Izaberite rutu i kliknite „Pronađi letove“ da biste videli stvarne ponude sa Duffel API-ja.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'arhitektura' && (
            <div className="space-y-6">
              {/* Architecture diagram & Code contracts */}
              <div className="space-y-4">
                <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider">
                  Sloj adaptera: Kako se API podaci vezuju na korisnički budžet
                </h4>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Sistem je projektovan sa strogim TypeScript interfejsima (<code>TravelPackage</code>, <code>TransportOption</code>, <code>AccommodationOption</code>).
                  To znači da bilo koji spoljni API jednostavno mapira svoja JSON polja u ove modele bez menjanja izgleda korisničkog interfejsa.
                </p>

                <div className="bg-stone-900 text-stone-200 p-4 rounded-2xl font-mono text-[11px] space-y-2 overflow-x-auto">
                  <div className="text-stone-400">// Primer poziva i mapiranja u src/services/liveApis.ts</div>
                  <div className="text-amber-400">async function searchKiwiFlights(origin, dest, maxEUR) &#123;</div>
                  <div className="pl-4 text-stone-300">
                    const res = await fetch(`https://api.tequila.kiwi.com/v2/search?fly_from=$&#123;origin&#125;&fly_to=$&#123;dest&#125;&price_to=$&#123;maxEUR&#125;`, &#123;
                  </div>
                  <div className="pl-8 text-stone-400">headers: &#123; apikey: process.env.KIWI_TEQUILA_API_KEY &#125;</div>
                  <div className="pl-4 text-stone-300">&#125;);</div>
                  <div className="pl-4 text-stone-300">return res.json().map(item =&gt; toTransportOption(item));</div>
                  <div className="text-amber-400">&#125;</div>
                </div>
              </div>

              {/* Security & Env Variables */}
              <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-bold text-stone-900 text-xs mb-1">
                    Bezbednost: Ključevi se čuvaju u serverskom .env okruženju
                  </h5>
                  <p className="text-stone-600 text-xs leading-relaxed">
                    Svi API ključevi su definisani u <code>.env.example</code> fajlu i nikada se ne izlažu u pretraživaču.
                    Pozivi idu preko interne serverske rute (proxy), čime se štiti vaša besplatna mesečna kvota.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-100 border-t border-stone-200 flex items-center justify-between">
          <div className="text-[11px] text-stone-500 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Open-Meteo, ECB i Nominatim su aktivni u realnom vremenu</span>
          </div>
          <button
            onClick={onClose}
            className="cursor-pointer px-4 py-2 bg-stone-900 text-white rounded-xl text-xs font-semibold hover:bg-stone-800 transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <span>Zatvori pregled</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
