import React, { useState } from 'react';
import { TravelPackage } from '../types/travel';
import { calculateTripFinancials, EUR_TO_RSD_RATE } from '../services/travelApi';
import {
  TrendingDown,
  Building2,
  Sparkles,
  Check,
  X,
  Users,
  Clock,
  ArrowRight,
  ShieldCheck,
  Percent,
  PiggyBank,
  Compass,
} from 'lucide-react';

interface AgencySavingsSectionProps {
  packages: TravelPackage[];
  currency: 'EUR' | 'RSD';
  originCity: string;
  onSelectPackage: (pkg: TravelPackage) => void;
}

export const AgencySavingsSection: React.FC<AgencySavingsSectionProps> = ({
  packages,
  currency,
  originCity,
  onSelectPackage,
}) => {
  // Pre-filter packages with benchmark comparisons available
  const benchmarkPackages = packages.filter((p) => p.agencyBenchmarkPriceEUR);
  const [selectedPkgId, setSelectedPkgId] = useState<string>(
    benchmarkPackages.find((p) => p.id === 'pkg-rim-nis')?.id || benchmarkPackages[0]?.id || ''
  );
  const [persons, setPersons] = useState<number>(2);

  const selectedPkg =
    benchmarkPackages.find((p) => p.id === selectedPkgId) || benchmarkPackages[0];

  const fin = selectedPkg
    ? calculateTripFinancials(
        selectedPkg,
        undefined,
        undefined,
        selectedPkg.defaultNights,
        persons,
        999,
        originCity
      )
    : null;

  const formatPrice = (eur: number) => {
    if (currency === 'RSD') {
      return `${Math.round(eur * EUR_TO_RSD_RATE).toLocaleString()} RSD`;
    }
    return `${Math.round(eur)} €`;
  };

  const getSavingsContext = (savingsEUR: number) => {
    if (savingsEUR >= 200) {
      return 'Dovoljno novca za još jedan ceo vikend odmor u banji ili na planini za dvoje!';
    }
    if (savingsEUR >= 100) {
      return 'Pokriva kompletan džeparac, sve restorane, kafane i ulaznice na ovom putovanju!';
    }
    return 'Značajna ušteda koja ostaje u tvom džepu umesto u agencijskoj proviziji.';
  };

  return (
    <section
      id="usteda-agencije-sekcija"
      className="py-16 sm:py-20 bg-gradient-to-b from-stone-50 via-white to-stone-50 border-t border-stone-200"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100/80 px-3 py-1 rounded-md uppercase tracking-wider mb-3">
            <PiggyBank className="w-4 h-4 text-emerald-700" />
            <span>Poređenje troškova</span>
          </div>
          <h2 className="font-display text-2xl sm:text-4xl font-bold text-stone-900 tracking-tight mb-3">
            Uštedi u odnosu na turističke agencije
          </h2>
          <p className="text-sm sm:text-base text-stone-600 leading-relaxed">
            Zašto plaćati posredničke provizije od 40% do 60%? Tradicionalne agencije naplaćuju fiksne
            marže, najam autobusa i posredovanje. Pogledaj tačnu računicu kako samostalnim
            kombinovanjem prevoza i smeštaja štediš stotine evra po putovanju.
          </p>
        </div>

        {/* Interactive Comparison Tool */}
        <div className="bg-white rounded-3xl border border-stone-200 shadow-xl overflow-hidden mb-12">
          {/* Top Controls Bar */}
          <div className="bg-stone-900 text-white p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="text-xs font-semibold text-amber-300 uppercase tracking-wider block mb-1">
                Izaberi primer za kalkulaciju:
              </span>
              <div className="flex flex-wrap gap-2 mt-2">
                {benchmarkPackages.slice(0, 6).map((pkg) => (
                  <button
                    key={pkg.id}
                    onClick={() => setSelectedPkgId(pkg.id)}
                    className={`cursor-pointer px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      selectedPkg?.id === pkg.id
                        ? 'bg-amber-600 text-white shadow-md'
                        : 'bg-white/10 hover:bg-white/20 text-stone-300'
                    }`}
                  >
                    {pkg.destinationName}
                  </button>
                ))}
              </div>
            </div>

            {/* Persons Selector */}
            <div className="shrink-0 flex items-center gap-3">
              <span className="text-xs text-stone-300 flex items-center gap-1.5">
                <Users className="w-4 h-4 text-stone-400" />
                <span>Broj putnika:</span>
              </span>
              <div className="flex items-center gap-1 bg-white/10 p-1 rounded-xl">
                {[1, 2, 3, 4].map((p) => (
                  <button
                    key={p}
                    onClick={() => setPersons(p)}
                    className={`cursor-pointer px-3 py-1 text-xs font-bold rounded-lg transition-colors ${
                      persons === p
                        ? 'bg-white text-stone-900 shadow-sm'
                        : 'text-stone-300 hover:text-white'
                    }`}
                  >
                    {p} {p === 1 ? 'osoba' : 'osobe'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Side-by-Side Comparison Cards */}
          {fin && selectedPkg && (
            <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
              {/* Left Column: Traditional Travel Agency */}
              <div className="lg:col-span-5 bg-stone-50 rounded-2xl p-6 border border-stone-200 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between pb-4 border-b border-stone-200 mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-xl bg-stone-200 text-stone-700 flex items-center justify-center font-bold">
                        <Building2 className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-display font-bold text-stone-900 text-base">
                          Turistička agencija
                        </h3>
                        <span className="text-[11px] text-stone-500">Klasičan paket aranžman</span>
                      </div>
                    </div>
                    <span className="text-xs font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded">
                      Standardna cena
                    </span>
                  </div>

                  <div className="space-y-3 text-xs text-stone-600 mb-6">
                    <div className="flex items-start gap-2.5">
                      <X className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      <span>
                        <strong className="text-stone-900">Prevoz:</strong> Grupni autobus sa 50+
                        putnika, polazak u rano jutro, višečasovna čekanja na granicama.
                      </span>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <X className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      <span>
                        <strong className="text-stone-900">Smeštaj:</strong> Hoteli na periferiji
                        ili industrijskoj zoni (dodatni troškovi za taksi ili prevoz do centra).
                      </span>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <X className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      <span>
                        <strong className="text-stone-900">Marže:</strong> Uključena agencijska provizija,
                        troškovi vodiča i administrativne takse.
                      </span>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <X className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      <span>
                        <strong className="text-stone-900">Izleti:</strong> Skupi fakultativni izleti
                        (30–50 € po osobi za osnovno razgledanje).
                      </span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-stone-200">
                  <div className="flex items-baseline justify-between mb-1">
                    <span className="text-xs text-stone-500">Ukupan trošak agencije:</span>
                    <span className="font-display text-2xl font-bold text-stone-900 line-through text-stone-400 tabular-nums">
                      {formatPrice(fin.totalAgencyCostEUR)}
                    </span>
                  </div>
                  <div className="text-right text-[11px] text-stone-400 tabular-nums">
                    (~{formatPrice(fin.totalAgencyCostEUR / persons)} po osobi)
                  </div>
                </div>
              </div>

              {/* Center Savings Pill / Callout */}
              <div className="lg:col-span-2 flex flex-col items-center justify-center text-center p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200/80">
                <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mb-3 shadow-md">
                  <Percent className="w-6 h-6" />
                </div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 mb-1">
                  Direktna ušteda
                </span>
                <div className="font-display text-3xl sm:text-4xl font-extrabold text-emerald-700 tabular-nums mb-1">
                  {formatPrice(fin.savingsEUR)}
                </div>
                <div className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full mb-3">
                  -{fin.savingsPercentage}% jeftinije!
                </div>
                <p className="text-[11px] text-emerald-900/80 leading-tight">
                  {getSavingsContext(fin.savingsEUR)}
                </p>
              </div>

              {/* Right Column: DIY Platform "Gde za moj novac?" */}
              <div className="lg:col-span-5 bg-gradient-to-br from-amber-50/40 via-white to-amber-50/20 rounded-2xl p-6 border-2 border-amber-600/40 flex flex-col justify-between shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-amber-600 text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-bl-xl shadow-sm">
                  Preporučeni izbor
                </div>

                <div>
                  <div className="flex items-center justify-between pb-4 border-b border-stone-200 mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-xl bg-amber-600 text-white flex items-center justify-center font-bold">
                        <Sparkles className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-display font-bold text-stone-900 text-base">
                          Gde za moj novac?
                        </h3>
                        <span className="text-[11px] text-amber-800 font-semibold">
                          Pametno samostalno putovanje
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3 text-xs text-stone-700 mb-6">
                    <div className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>
                        <strong className="text-stone-900">Prevoz:</strong> {fin.transport.provider}{' '}
                        ({fin.transport.durationHours}h vožnje, fleksibilan raspored).
                      </span>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>
                        <strong className="text-stone-900">Smeštaj:</strong> {fin.accommodation.name}{' '}
                        ({fin.accommodation.rating}★ ocena, u centru ili blizu atrakcija).
                      </span>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>
                        <strong className="text-stone-900">Bez marži:</strong> 0% agencijske provizije,
                        direktne cene prevoza i smeštaja.
                      </span>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>
                        <strong className="text-stone-900">Sloboda:</strong> Vi birate vreme polaska,
                        restorane i tempo obilaska bez grupnog pritiska.
                      </span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-stone-200">
                  <div className="flex items-baseline justify-between mb-1">
                    <span className="text-xs text-stone-600 font-medium">Ukupna stvarna cena:</span>
                    <span className="font-display text-3xl font-extrabold text-stone-900 tabular-nums">
                      {formatPrice(fin.totalBaseCostEUR)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-stone-500 mb-4">
                    <span>
                      Za {persons} {persons === 1 ? 'osobu' : 'osobe'} · {selectedPkg.defaultNights} noći
                    </span>
                    <span className="tabular-nums font-semibold text-stone-800">
                      ({formatPrice(fin.costPerPersonEUR)} / os.)
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => onSelectPackage(selectedPkg)}
                    className="cursor-pointer w-full py-3 px-4 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-sm hover:shadow"
                  >
                    <span>Pogledaj detalje & rezerviši samostalno</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 4 Pillars: Why do agencies cost so much more? */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center mb-4">
              <TrendingDown className="w-5 h-5" />
            </div>
            <h4 className="font-display font-bold text-stone-900 text-base mb-2">
              1. Agencijska provizija i troškovi
            </h4>
            <p className="text-xs text-stone-600 leading-relaxed">
              Agencije moraju da plate zakup poslovnog prostora, marketing, radnike i zaradu.
              Zato na cenu prevoza i smeštaja dodaju maržu od 30% do čak 60%.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-800 flex items-center justify-center mb-4">
              <Compass className="w-5 h-5" />
            </div>
            <h4 className="font-display font-bold text-stone-900 text-base mb-2">
              2. Smeštaj u centru vs periferija
            </h4>
            <p className="text-xs text-stone-600 leading-relaxed">
              Agencije često nude jeftinije hotele daleko van grada kako bi imale veći profit.
              Naša platforma pronalazi povoljne privatne apartmane i boutique hotele u centru,
              gde peške obilazite sve atrakcije.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-4">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h4 className="font-display font-bold text-stone-900 text-base mb-2">
              3. Transparentna matematika bez tajni
            </h4>
            <p className="text-xs text-stone-600 leading-relaxed">
              „Gde za moj novac?“ ti tačno prikazuje koliko košta karta za bus/avion, a koliko noćenje.
              Nema doplata za gorivo, skrivenih taksi ili ucenjivanja fakultativnim izletima.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
