import React from 'react';
import { Compass, Heart } from 'lucide-react';

interface FooterProps {
  onOpenApiModal: () => void;
  onScrollToTop: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenApiModal, onScrollToTop }) => {
  return (
    <footer className="bg-stone-900 text-stone-300 border-t border-stone-800 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <span className="font-display text-white font-bold text-lg tracking-tight">
                Gde za moj novac?
              </span>
            </div>
            <p className="text-stone-400 max-w-sm text-xs leading-relaxed">
              Prva regionalna turistička platforma u Srbiji i na Balkanu posvećena putovanjima
              isključivo prema realnom budžetu korisnika.
            </p>
            <div className="text-[11px] text-stone-500">
              Informativni kurs: 1 € ≈ 117.2 RSD · Cene prevoza i smeštaja verifikovane za 2026.
            </div>
          </div>

          {/* Destinacije */}
          <div className="space-y-2">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider">
              Popularne kategorije
            </h4>
            <ul className="space-y-1.5 text-stone-400">
              <li>Vrnjačka Banja i Sokobanja</li>
              <li>Planina Tara i Zlatibor</li>
              <li>Ohridsko jezero i Palić</li>
              <li>Boka Kotorska i Solun</li>
              <li>Vikend City Break u Rimu i Budimpešti</li>
            </ul>
          </div>

          {/* Tehnologija & Arhitektura */}
          <div className="space-y-2">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider">
              Platforma & API
            </h4>
            <ul className="space-y-1.5 text-stone-400">
              <li>
                <button
                  onClick={onOpenApiModal}
                  className="hover:text-amber-300 transition-colors cursor-pointer text-left"
                >
                  API arhitektura (Amadeus / Booking)
                </button>
              </li>
              <li>Modularni proračun troškova</li>
              <li>Autobuski i avio agregator</li>
              <li>Nema skrivenih naknada</li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-stone-500 text-[11px]">
          <div>
            © {new Date().getFullYear()} Gde za moj novac? Sva prava zadržana.
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={onScrollToTop}
              className="hover:text-stone-300 transition-colors cursor-pointer"
            >
              Povratak na vrh ↑
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
