import React, { useState, useEffect } from 'react';
import {
  TravelPackage,
  SearchFilters,
  DestinationCategory,
  TripDurationType,
} from './types/travel';
import { DEMO_PACKAGES, filterPackages } from './services/travelApi';
import { Navbar } from './components/Navbar';
import { BudgetHero } from './components/BudgetHero';
import { Quick150Feature } from './components/Quick150Feature';
import { BudgetMap } from './components/BudgetMap';
import { BorderWaitTimesSection } from './components/BorderWaitTimesSection';
import { AgencySavingsSection } from './components/AgencySavingsSection';
import { PackageList } from './components/PackageList';
import { CategoriesShowcase } from './components/CategoriesShowcase';
import { TransportAccommodationExplorer } from './components/TransportAccommodationExplorer';
import { PackageDetailModal } from './components/PackageDetailModal';
import { SavedTripsModal } from './components/SavedTripsModal';
import { ApiArchitectureModal } from './components/ApiArchitectureModal';
import { Footer } from './components/Footer';

const INITIAL_FILTERS: SearchFilters = {
  originCity: 'Beograd',
  maxBudgetEUR: 200,
  persons: 2,
  category: 'sve',
  durationType: 'sve',
  transportType: 'sve',
  sortBy: 'price_asc',
  currency: 'EUR',
};

// Nazivi tabova (koriste se i kao #hash u adresi) i ID sekcija na koje vode
const TAB_TARGETS: Record<string, string | null> = {
  pretraga: null,
  'za-150': 'za-150-sekcija',
  mapa: 'mapa-budzeta-sekcija',
  granice: 'granice-sekcija',
  'usteda-agencije': 'usteda-agencije-sekcija',
  kategorije: 'kategorije-sekcija',
  'prevoz-smestaj': 'prevoz-smestaj-sekcija',
};

function scrollToTab(tab: string) {
  const target = TAB_TARGETS[tab];
  if (target === undefined) return;
  if (target === null) {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } else {
    document.getElementById(target)?.scrollIntoView({ behavior: 'smooth' });
  }
}

export default function App() {
  const [filters, setFilters] = useState<SearchFilters>(INITIAL_FILTERS);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [selectedPackage, setSelectedPackage] = useState<TravelPackage | null>(null);
  const [isSavedModalOpen, setIsSavedModalOpen] = useState(false);
  const [isApiModalOpen, setIsApiModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('pretraga');

  // Load saved trips from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem('gde_za_novac_saved');
      if (stored) {
        setSavedIds(new Set(JSON.parse(stored)));
      }
    } catch {
      // fallback
    }
  }, []);

  const handleToggleSave = (pkg: TravelPackage) => {
    setSavedIds((prev) => {
      const next = new Set(prev);
      if (next.has(pkg.id)) {
        next.delete(pkg.id);
      } else {
        next.add(pkg.id);
      }
      try {
        localStorage.setItem('gde_za_novac_saved', JSON.stringify(Array.from(next)));
      } catch {
        // storage ignored
      }
      return next;
    });
  };

  const handleFilterChange = <K extends keyof SearchFilters>(
    key: K,
    value: SearchFilters[K]
  ) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const handleQuickPreset = (amountEUR: number) => {
    setFilters((prev) => ({ ...prev, maxBudgetEUR: amountEUR }));
    // Scroll gently to results
    const el = document.getElementById('rezultati-pretrage');
    el?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleResetFilters = () => {
    setFilters(INITIAL_FILTERS);
  };

  const handleToggleCurrency = () => {
    setFilters((prev) => ({
      ...prev,
      currency: prev.currency === 'EUR' ? 'RSD' : 'EUR',
    }));
  };

  const handleSelectNavTab = (tab: string) => {
    setActiveTab(tab);
    scrollToTab(tab);
    // Upisujemo #hash u adresu da svaka sekcija ima link koji se može podeliti
    try {
      const url = tab === 'pretraga' ? window.location.pathname + window.location.search : `#${tab}`;
      window.history.replaceState(null, '', url);
    } catch {
      // ignore
    }
  };

  // Otvaranje direktnog linka (npr. sajt.com/#granice) i reagovanje na promenu hash-a
  useEffect(() => {
    const applyHash = () => {
      const tab = window.location.hash.replace('#', '');
      if (tab && tab in TAB_TARGETS) {
        setActiveTab(tab);
        // kratko čekanje da se sadržaj iscrta pre skrolovanja
        window.setTimeout(() => scrollToTab(tab), 300);
      }
    };
    applyHash();
    window.addEventListener('hashchange', applyHash);
    return () => window.removeEventListener('hashchange', applyHash);
  }, []);

  const filteredPackages = filterPackages(DEMO_PACKAGES, filters);

  const savedPackagesList = DEMO_PACKAGES.filter((p) => savedIds.has(p.id));

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 text-stone-900">
      {/* 1. Header & Navigation */}
      <Navbar
        currentTab={activeTab}
        onSelectTab={handleSelectNavTab}
        currency={filters.currency}
        onToggleCurrency={handleToggleCurrency}
        savedCount={savedIds.size}
        onOpenSaved={() => setIsSavedModalOpen(true)}
        onOpenApiModal={() => setIsApiModalOpen(true)}
      />

      <main className="flex-1">
        {/* 2. Hero with Interactive Search Console */}
        <BudgetHero
          filters={filters}
          onFilterChange={handleFilterChange}
          onQuickPreset={handleQuickPreset}
          totalMatches={filteredPackages.length}
          onScrollToResults={() => {
            const el = document.getElementById('rezultati-pretrage');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* 3. Special Feature: „Gde mogu da otputujem za 150 €?“ */}
        <Quick150Feature
          currency={filters.currency}
          onSelectPackage={(pkg) => setSelectedPackage(pkg)}
          originCity={filters.originCity}
        />

        {/* 4. Interaktivna Mapa Budžeta (Radar destinacija prema budžetu) */}
        <BudgetMap
          packages={DEMO_PACKAGES}
          filters={filters}
          onFilterChange={handleFilterChange}
          onSelectPackage={(pkg) => setSelectedPackage(pkg)}
        />

        {/* 5. Stanje na graničnim prelazima uživo (AMSS zadržavanja, prohodnost i kamere) */}
        <BorderWaitTimesSection
          onSelectDestination={(dest) => {
            const el = document.getElementById('rezultati-pretrage');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* 6. Uštedi u odnosu na agencije (Poređenje samostalnog putovanja vs agencije) */}
        <AgencySavingsSection
          packages={DEMO_PACKAGES}
          currency={filters.currency}
          originCity={filters.originCity}
          onSelectPackage={(pkg) => setSelectedPackage(pkg)}
        />

        {/* 6. Filtered Results Grid */}
        <PackageList
          packages={filteredPackages}
          filters={filters}
          onFilterChange={handleFilterChange}
          onResetFilters={handleResetFilters}
          savedIds={savedIds}
          onToggleSave={handleToggleSave}
          onOpenDetails={(pkg) => setSelectedPackage(pkg)}
        />

        {/* 5. Destinacije po tipu odmora (Banje, Jezera, Planine, More, Vikend) */}
        <CategoriesShowcase
          onSelectCategory={(cat: DestinationCategory) => {
            handleFilterChange('category', cat);
            const el = document.getElementById('rezultati-pretrage');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          onSelectDuration={(dur: TripDurationType) => {
            handleFilterChange('durationType', dur);
            const el = document.getElementById('rezultati-pretrage');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* 6. Pojedinačna pretraga letova, autobusa i smeštaja */}
        <TransportAccommodationExplorer currency={filters.currency} />
      </main>

      {/* 7. Footer */}
      <Footer
        onOpenApiModal={() => setIsApiModalOpen(true)}
        onScrollToTop={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      />

      {/* Modals */}
      <PackageDetailModal
        pkg={selectedPackage}
        onClose={() => setSelectedPackage(null)}
        currency={filters.currency}
        initialPersons={filters.persons}
        userBudgetEUR={filters.maxBudgetEUR}
        originCity={filters.originCity}
      />

      <SavedTripsModal
        isOpen={isSavedModalOpen}
        onClose={() => setIsSavedModalOpen(false)}
        savedPackages={savedPackagesList}
        onRemove={(id) => handleToggleSave(DEMO_PACKAGES.find((p) => p.id === id)!)}
        onSelectPackage={(pkg) => setSelectedPackage(pkg)}
        currency={filters.currency}
      />

      <ApiArchitectureModal
        isOpen={isApiModalOpen}
        onClose={() => setIsApiModalOpen(false)}
      />
    </div>
  );
}
