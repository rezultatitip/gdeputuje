export type DestinationCategory = 'banje' | 'jezera' | 'planine' | 'more' | 'gradovi';

export type TripDurationType = 'vikend' | 'kratki' | 'nedeljni' | 'last_minute';

export type TransportType = 'flight' | 'bus' | 'car';

export interface TransportOption {
  id: string;
  type: TransportType;
  provider: string; // e.g., 'Wizz Air', 'Air Serbia', 'Ryanair', 'Niš-Ekspres', 'FlixBus', 'BS Tours', 'Sopstveni auto'
  originCity: string;
  destinationCity: string;
  departureTime: string;
  arrivalTime: string;
  durationHours: number;
  pricePerPersonEUR: number;
  returnDepartureTime: string;
  returnArrivalTime: string;
  baggageNote: string;
  isDirect: boolean;
  bookingNote: string;
}

export interface AccommodationOption {
  id: string;
  name: string;
  type: 'apartman' | 'hotel' | 'privatni_smestaj' | 'spa_resort' | 'vila' | 'etno_selo';
  stars?: number;
  rating: number; // e.g. 9.1
  reviewCount: number;
  pricePerNightEUR: number;
  locationDescription: string;
  amenities: string[];
  roomType: string;
  image: string;
}

export interface TravelPackage {
  id: string;
  title: string;
  destinationName: string;
  country: string;
  category: DestinationCategory;
  durationType: TripDurationType;
  defaultNights: number;
  originCity: string;
  heroImage: string;
  highlights: string[];
  description: string;
  recommendedDailyBudgetEUR: number;
  bestSeason: string;
  isLastMinute?: boolean;
  isPopular?: boolean;
  transports: TransportOption[];
  accommodations: AccommodationOption[];
  defaultTransportId: string;
  defaultAccommodationId: string;
  whatToSee: string[];
  budgetTips: string[];
  coordinates?: { lat: number; lng: number };
  agencyBenchmarkPriceEUR?: number; // Prosečna cena turističke agencije za ovakav aranžman po osobi
}

export interface SearchFilters {
  originCity: string;
  maxBudgetEUR: number;
  persons: number;
  category: DestinationCategory | 'sve';
  durationType: TripDurationType | 'sve';
  transportType: TransportType | 'sve';
  sortBy: 'price_asc' | 'savings_desc' | 'rating' | 'budget_fit';
  currency: 'EUR' | 'RSD';
}

export interface SavedTrip {
  id: string;
  packageId: string;
  title: string;
  destinationName: string;
  totalCostEUR: number;
  persons: number;
  transportType: TransportType;
  transportProvider: string;
  accommodationName: string;
  heroImage: string;
  savedAt: string;
}
