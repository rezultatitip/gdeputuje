/**
 * Tipovi podataka za stanje i zadržavanje na graničnim prelazima
 */

export type BorderTrafficStatus = 'prohodno' | 'umereno' | 'guzva' | 'zastoj';

export type BorderCountryCode = 'ALL' | 'HU' | 'MK' | 'GR' | 'ME' | 'BA' | 'HR' | 'BG' | 'RO';

export interface BorderAlternative {
  name: string;
  waitMinutes: number;
  note: string;
}

export interface BorderCrossing {
  id: string;
  name: string;
  countryPair: string; // npr. "Srbija – Mađarska"
  neighborCrossingName?: string; // npr. "Röszke", "Tabanovce", "Bajakovo"
  targetCountryCode: BorderCountryCode;
  targetCountryName: string; // npr. "Mađarska", "Severna Makedonija"
  flagEmoji: string;
  routeHint: string; // npr. "Auto-put E-75 ka Budimpešti i Beču"
  waitPassengerExitMin: number; // Izlaz iz Srbije (putnička vozila)
  waitPassengerEntryMin: number; // Ulaz u Srbiju (putnička vozila)
  waitBusExitMin: number; // Zadržavanje autobusa na izlazu
  waitBusEntryMin: number; // Zadržavanje autobusa na ulazu
  status: BorderTrafficStatus;
  workingHours: string; // npr. "00-24h" ili "07:00 - 19:00"
  trafficTypes: ('auto' | 'bus' | 'kamion')[];
  isIntegratedControl: boolean; // Jedinstvena kontrola na jednom mestu
  alternative?: BorderAlternative;
  hasCamera: boolean;
  cameraUrl?: string; // Link ka zvaničnoj AMSS/MUP kameri
  lastUpdated: string;
  advisoryNote?: string;
  connectedDestinationNames?: string[]; // npr. ['Budimpešta', 'Beč', 'Solun', 'Kotor']
}
