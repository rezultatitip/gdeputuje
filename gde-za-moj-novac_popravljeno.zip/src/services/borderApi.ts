import { BorderCrossing, BorderCountryCode, BorderTrafficStatus } from '../types/border';

export const BORDER_CROSSINGS_DATA: BorderCrossing[] = [
  // 1. MAĐARSKA
  {
    id: 'border-horgos-1',
    name: 'Horgoš I (Auto-put E-75)',
    countryPair: 'Srbija – Mađarska',
    neighborCrossingName: 'Röszke (Autópálya)',
    targetCountryCode: 'HU',
    targetCountryName: 'Mađarska',
    flagEmoji: '🇭🇺',
    routeHint: 'Glavni auto-put ka Budimpešti, Bratislavi i Beču',
    waitPassengerExitMin: 45,
    waitPassengerEntryMin: 30,
    waitBusExitMin: 70,
    waitBusEntryMin: 50,
    status: 'guzva',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus', 'kamion'],
    isIntegratedControl: false,
    alternative: {
      name: 'Kelebija ili Horgoš II',
      waitMinutes: 15,
      note: 'Za putnička vozila preporučujemo Kelebiju (00-24h) ili Bačke Vinograde (radi do 19h).',
    },
    hasCamera: true,
    cameraUrl: 'https://kamere.amss.org.rs/',
    lastUpdated: 'Pre 10 min',
    advisoryNote: 'U toku su povremeni radovi na mađarskoj strani. Očekujte kolone vikendom.',
    connectedDestinationNames: ['Budimpešta', 'Palić i Subotica', 'Beč', 'Prag'],
  },
  {
    id: 'border-kelebija',
    name: 'Kelebija',
    countryPair: 'Srbija – Mađarska',
    neighborCrossingName: 'Tompa',
    targetCountryCode: 'HU',
    targetCountryName: 'Mađarska',
    flagEmoji: '🇭🇺',
    routeHint: 'Pravac preko Subotice ka Segedinu i Budimpešti',
    waitPassengerExitMin: 15,
    waitPassengerEntryMin: 15,
    waitBusExitMin: 25,
    waitBusEntryMin: 20,
    status: 'prohodno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus', 'kamion'],
    isIntegratedControl: false,
    hasCamera: true,
    cameraUrl: 'https://kamere.amss.org.rs/',
    lastUpdated: 'Pre 12 min',
    advisoryNote: 'Stabilan protok saobraćaja, preporučena alternativa za Horgoš.',
    connectedDestinationNames: ['Budimpešta', 'Palić i Subotica'],
  },
  {
    id: 'border-backi-vinogradi',
    name: 'Bački Vinogradi',
    countryPair: 'Srbija – Mađarska',
    neighborCrossingName: 'Ásotthalom',
    targetCountryCode: 'HU',
    targetCountryName: 'Mađarska',
    flagEmoji: '🇭🇺',
    routeHint: 'Lokalni prelaz za putnička vozila, blizu auto-puta E-75',
    waitPassengerExitMin: 10,
    waitPassengerEntryMin: 10,
    waitBusExitMin: 0,
    waitBusEntryMin: 0,
    status: 'prohodno',
    workingHours: '07:00 – 19:00',
    trafficTypes: ['auto'],
    isIntegratedControl: false,
    hasCamera: false,
    lastUpdated: 'Pre 15 min',
    advisoryNote: 'Samo za putnička vozila državljana Srbije i EU/Šengena. Ne važi za autobuse.',
    connectedDestinationNames: ['Budimpešta', 'Palić i Subotica'],
  },

  // 2. SEVERNA MAKEDONIJA
  {
    id: 'border-presevo',
    name: 'Preševo (Auto-put E-75)',
    countryPair: 'Srbija – Severna Makedonija',
    neighborCrossingName: 'Tabanovce',
    targetCountryCode: 'MK',
    targetCountryName: 'Severna Makedonija',
    flagEmoji: '🇲🇰',
    routeHint: 'Glavni koridor 10 ka Skoplju, Ohridu i Grčkoj (Egejsko more)',
    waitPassengerExitMin: 20,
    waitPassengerEntryMin: 15,
    waitBusExitMin: 30,
    waitBusEntryMin: 25,
    status: 'prohodno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus', 'kamion'],
    isIntegratedControl: true,
    alternative: {
      name: 'Prohor Pčinjski',
      waitMinutes: 5,
      note: 'Prelaz Prohor Pčinjski kod manastira je skoro uvek potpuno prazan.',
    },
    hasCamera: true,
    cameraUrl: 'https://kamere.amss.org.rs/',
    lastUpdated: 'Pre 8 min',
    advisoryNote: 'U funkciji je integrisano jedno zaustavljanje (One-Stop-Shop) sa makedonskim kolegama.',
    connectedDestinationNames: ['Ohrid', 'Solun i Halkidiki', 'Skoplje', 'Atina'],
  },
  {
    id: 'border-prohor-pcinski',
    name: 'Prohor Pčinjski',
    countryPair: 'Srbija – Severna Makedonija',
    neighborCrossingName: 'Pelince',
    targetCountryCode: 'MK',
    targetCountryName: 'Severna Makedonija',
    flagEmoji: '🇲🇰',
    routeHint: 'Slikovita trasa pored reke Pčinje i manastira',
    waitPassengerExitMin: 5,
    waitPassengerEntryMin: 5,
    waitBusExitMin: 10,
    waitBusEntryMin: 10,
    status: 'prohodno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus'],
    isIntegratedControl: false,
    hasCamera: false,
    lastUpdated: 'Pre 20 min',
    advisoryNote: 'Idealan izbor kada je na Preševu gužva preko 45 minuta.',
    connectedDestinationNames: ['Ohrid', 'Solun i Halkidiki'],
  },

  // 3. GRČKA (MKD – GR)
  {
    id: 'border-bogorodica',
    name: 'Bogorodica / Evzoni',
    countryPair: 'Severna Makedonija – Grčka',
    neighborCrossingName: 'Evzoni (Εύζωνοι)',
    targetCountryCode: 'GR',
    targetCountryName: 'Grčka',
    flagEmoji: '🇬🇷',
    routeHint: 'Glavni ulaz u Grčku ka Solunu, Halkidikiju, Olimpskoj regiji',
    waitPassengerExitMin: 35,
    waitPassengerEntryMin: 20,
    waitBusExitMin: 45,
    waitBusEntryMin: 30,
    status: 'umereno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus', 'kamion'],
    isIntegratedControl: false,
    alternative: {
      name: 'Dojran (Star Dojran)',
      waitMinutes: 10,
      note: 'Prijatna vožnja uz Dojransko jezero, prelazak traje svega nekoliko minuta.',
    },
    hasCamera: true,
    cameraUrl: 'https://kamere.amss.org.rs/',
    lastUpdated: 'Pre 14 min',
    advisoryNote: 'Prosečno zadržavanje 30-40 min. Grčka carina povremeno detaljnije pregleda prtljag.',
    connectedDestinationNames: ['Solun i Halkidiki'],
  },
  {
    id: 'border-dojran',
    name: 'Dojran / Doirani',
    countryPair: 'Severna Makedonija – Grčka',
    neighborCrossingName: 'Doirani (Δοϊράνη)',
    targetCountryCode: 'GR',
    targetCountryName: 'Grčka',
    flagEmoji: '🇬🇷',
    routeHint: 'Pravac preko Valandova i Dojranskog jezera ka Kilkisu i Solunu',
    waitPassengerExitMin: 10,
    waitPassengerEntryMin: 10,
    waitBusExitMin: 15,
    waitBusEntryMin: 15,
    status: 'prohodno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus'],
    isIntegratedControl: false,
    hasCamera: false,
    lastUpdated: 'Pre 18 min',
    advisoryNote: 'Odlična opcija za putnike koji žele opušteniji put bez stresa na Evzoniju.',
    connectedDestinationNames: ['Solun i Halkidiki'],
  },

  // 4. CRNA GORA
  {
    id: 'border-gostun',
    name: 'Gostun (Prijepolje)',
    countryPair: 'Srbija – Crna Gora',
    neighborCrossingName: 'Dobrakovo (Bijelo Polje)',
    targetCountryCode: 'ME',
    targetCountryName: 'Crna Gora',
    flagEmoji: '🇲🇪',
    routeHint: 'Glavni magistralni pravac ka Podgorici, Bokokotorskom zalivu i Budvi',
    waitPassengerExitMin: 20,
    waitPassengerEntryMin: 15,
    waitBusExitMin: 30,
    waitBusEntryMin: 20,
    status: 'prohodno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus', 'kamion'],
    isIntegratedControl: false,
    alternative: {
      name: 'Jabuka',
      waitMinutes: 10,
      note: 'Preko Prijepolja i Pljevalja ka Žabljaku (Durmitor) ili primorju.',
    },
    hasCamera: true,
    cameraUrl: 'https://kamere.amss.org.rs/',
    lastUpdated: 'Pre 11 min',
    advisoryNote: 'Saobraćaj teče umereno. Put kroz kanjon Morače je u dobrom stanju.',
    connectedDestinationNames: ['Boka Kotorska i Perast', 'Kotor', 'Podgorica', 'Bar'],
  },
  {
    id: 'border-jabuka',
    name: 'Jabuka',
    countryPair: 'Srbija – Crna Gora',
    neighborCrossingName: 'Ranče (Pljevlja)',
    targetCountryCode: 'ME',
    targetCountryName: 'Crna Gora',
    flagEmoji: '🇲🇪',
    routeHint: 'Planinski prelaz preko Pljevalja ka Tari, Žabljaku ili Boki',
    waitPassengerExitMin: 10,
    waitPassengerEntryMin: 10,
    waitBusExitMin: 15,
    waitBusEntryMin: 15,
    status: 'prohodno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus'],
    isIntegratedControl: false,
    hasCamera: false,
    lastUpdated: 'Pre 22 min',
    advisoryNote: 'Manje frekventan prelaz, brža procedura.',
    connectedDestinationNames: ['Boka Kotorska i Perast', 'Kotor'],
  },
  {
    id: 'border-spiljani',
    name: 'Špiljani',
    countryPair: 'Srbija – Crna Gora',
    neighborCrossingName: 'Dračenovac (Rožaje)',
    targetCountryCode: 'ME',
    targetCountryName: 'Crna Gora',
    flagEmoji: '🇲🇪',
    routeHint: 'Pravac preko Novog Pazara i Ribarića ka Beranama',
    waitPassengerExitMin: 15,
    waitPassengerEntryMin: 15,
    waitBusExitMin: 20,
    waitBusEntryMin: 20,
    status: 'prohodno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus', 'kamion'],
    isIntegratedControl: false,
    hasCamera: true,
    cameraUrl: 'https://kamere.amss.org.rs/',
    lastUpdated: 'Pre 25 min',
    advisoryNote: 'Preporučeno za putnike sa juga i istoka Srbije.',
    connectedDestinationNames: ['Boka Kotorska i Perast', 'Kotor'],
  },

  // 5. HRVATSKA
  {
    id: 'border-batrovci',
    name: 'Batrovci (Auto-put E-70)',
    countryPair: 'Srbija – Hrvatska',
    neighborCrossingName: 'Bajakovo',
    targetCountryCode: 'HR',
    targetCountryName: 'Hrvatska',
    flagEmoji: '🇭🇷',
    routeHint: 'Glavni auto-put ka Zagrebu, Ljubljani, Istri i Italiji (Rim)',
    waitPassengerExitMin: 55,
    waitPassengerEntryMin: 30,
    waitBusExitMin: 80,
    waitBusEntryMin: 45,
    status: 'guzva',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus', 'kamion'],
    isIntegratedControl: false,
    alternative: {
      name: 'Šid ili Tovarnik',
      waitMinutes: 15,
      note: 'Isključite se kod Sremske Mitrovice ili Kuzmina ka Šidu za kraće čekanje.',
    },
    hasCamera: true,
    cameraUrl: 'https://kamere.amss.org.rs/',
    lastUpdated: 'Pre 7 min',
    advisoryNote: 'Ulazak u Šengen zonu zahteva detaljnije provere pasoša. Kamionske kolone na teretnom terminalu.',
    connectedDestinationNames: ['Rim', 'Zagreb', 'Ljubljana', 'Istra'],
  },
  {
    id: 'border-sid',
    name: 'Šid',
    countryPair: 'Srbija – Hrvatska',
    neighborCrossingName: 'Tovarnik',
    targetCountryCode: 'HR',
    targetCountryName: 'Hrvatska',
    flagEmoji: '🇭🇷',
    routeHint: 'Alternativni pravac preko grada Šida',
    waitPassengerExitMin: 20,
    waitPassengerEntryMin: 15,
    waitBusExitMin: 35,
    waitBusEntryMin: 25,
    status: 'prohodno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus'],
    isIntegratedControl: false,
    hasCamera: true,
    cameraUrl: 'https://kamere.amss.org.rs/',
    lastUpdated: 'Pre 16 min',
    advisoryNote: 'Znatno manja gužva u odnosu na Batrovce.',
    connectedDestinationNames: ['Rim', 'Zagreb'],
  },

  // 6. BOSNA I HERCEGOVINA
  {
    id: 'border-kotroman',
    name: 'Kotroman (Mokra Gora)',
    countryPair: 'Srbija – Bosna i Hercegovina',
    neighborCrossingName: 'Vardište (Višegrad)',
    targetCountryCode: 'BA',
    targetCountryName: 'Bosna i Hercegovina',
    flagEmoji: '🇧🇦',
    routeHint: 'Preko Zlatibora i Tare ka Višegradu, Andrićgradu i Sarajevu',
    waitPassengerExitMin: 15,
    waitPassengerEntryMin: 10,
    waitBusExitMin: 20,
    waitBusEntryMin: 15,
    status: 'prohodno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus'],
    isIntegratedControl: false,
    hasCamera: true,
    cameraUrl: 'https://kamere.amss.org.rs/',
    lastUpdated: 'Pre 13 min',
    advisoryNote: 'Saobraćaj se odvija bez dužih zadržavanja. Povoljno za vikend izlete.',
    connectedDestinationNames: ['Tara i Zaovine', 'Zlatibor', 'Sarajevo'],
  },
  {
    id: 'border-sremska-raca',
    name: 'Sremska Rača',
    countryPair: 'Srbija – Bosna i Hercegovina',
    neighborCrossingName: 'Bosanska Rača',
    targetCountryCode: 'BA',
    targetCountryName: 'Bosna i Hercegovina',
    flagEmoji: '🇧🇦',
    routeHint: 'Pravac preko Kuzmina ka Bijeljini, Brčkom i Banjaluci',
    waitPassengerExitMin: 20,
    waitPassengerEntryMin: 15,
    waitBusExitMin: 25,
    waitBusEntryMin: 20,
    status: 'prohodno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus', 'kamion'],
    isIntegratedControl: true,
    hasCamera: true,
    cameraUrl: 'https://kamere.amss.org.rs/',
    lastUpdated: 'Pre 19 min',
    advisoryNote: 'U toku su radovi na novom mostu i auto-putu Beograd–Bijeljina.',
    connectedDestinationNames: ['Banjaluka', 'Bijeljina'],
  },

  // 7. BUGARSKA
  {
    id: 'border-gradina',
    name: 'Gradina (Dimitrovgrad)',
    countryPair: 'Srbija – Bugarska',
    neighborCrossingName: 'Kalotina',
    targetCountryCode: 'BG',
    targetCountryName: 'Bugarska',
    flagEmoji: '🇧🇬',
    routeHint: 'Auto-put E-80 (Istočni krak Koridora 10) ka Sofiji, Plovdivu i Turskoj',
    waitPassengerExitMin: 30,
    waitPassengerEntryMin: 20,
    waitBusExitMin: 45,
    waitBusEntryMin: 30,
    status: 'umereno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus', 'kamion'],
    isIntegratedControl: false,
    hasCamera: true,
    cameraUrl: 'https://kamere.amss.org.rs/',
    lastUpdated: 'Pre 9 min',
    advisoryNote: 'Periodični talasi turskih tranzitnih putnika vikendom. Otvoreno 6 traka.',
    connectedDestinationNames: ['Sofija', 'Plovdiv'],
  },

  // 8. RUMUNIJA
  {
    id: 'border-vatin',
    name: 'Vatin (Vršac)',
    countryPair: 'Srbija – Rumunija',
    neighborCrossingName: 'Stamora Moravița',
    targetCountryCode: 'RO',
    targetCountryName: 'Rumunija',
    flagEmoji: '🇷🇴',
    routeHint: 'Glavni put od Beograda i Pančeva ka Temišvaru',
    waitPassengerExitMin: 10,
    waitPassengerEntryMin: 10,
    waitBusExitMin: 15,
    waitBusEntryMin: 15,
    status: 'prohodno',
    workingHours: '00–24h',
    trafficTypes: ['auto', 'bus', 'kamion'],
    isIntegratedControl: false,
    hasCamera: true,
    cameraUrl: 'https://kamere.amss.org.rs/',
    lastUpdated: 'Pre 21 min',
    advisoryNote: 'Brz prelazak bez gužve, odlično za šoping i vikend posete Temišvaru.',
    connectedDestinationNames: ['Temišvar'],
  },
];

/**
 * Vraća status i boju za prikaz zastoja
 */
export function getStatusBadge(status: BorderTrafficStatus): {
  label: string;
  bgClass: string;
  textClass: string;
  borderClass: string;
  dotColor: string;
} {
  switch (status) {
    case 'prohodno':
      return {
        label: 'Prohodno (0–20 min)',
        bgClass: 'bg-emerald-50',
        textClass: 'text-emerald-800',
        borderClass: 'border-emerald-200',
        dotColor: 'bg-emerald-500',
      };
    case 'umereno':
      return {
        label: 'Umereno (20–45 min)',
        bgClass: 'bg-amber-50',
        textClass: 'text-amber-800',
        borderClass: 'border-amber-200',
        dotColor: 'bg-amber-500',
      };
    case 'guzva':
      return {
        label: 'Gužva (45–90 min)',
        bgClass: 'bg-orange-50',
        textClass: 'text-orange-800',
        borderClass: 'border-orange-200',
        dotColor: 'bg-orange-500',
      };
    case 'zastoj':
      return {
        label: 'Veći zastoj (90+ min)',
        bgClass: 'bg-rose-50',
        textClass: 'text-rose-800',
        borderClass: 'border-rose-200',
        dotColor: 'bg-rose-500',
      };
  }
}

/**
 * Filtrira prelaze po destinaciji paketa
 */
export function getBorderCrossingsForDestination(
  destinationName: string,
  country?: string
): BorderCrossing[] {
  const destLower = destinationName.toLowerCase();
  const countryLower = (country || '').toLowerCase();

  return BORDER_CROSSINGS_DATA.filter((b) => {
    // 1. Ako je eksplicitno na listi povezanih destinacija
    if (
      b.connectedDestinationNames &&
      b.connectedDestinationNames.some(
        (name) => destLower.includes(name.toLowerCase()) || name.toLowerCase().includes(destLower)
      )
    ) {
      return true;
    }

    // 2. Prema zemlji
    if (countryLower.includes('mađarska') && b.targetCountryCode === 'HU') return true;
    if (countryLower.includes('makedonija') && b.targetCountryCode === 'MK') return true;
    if (countryLower.includes('grčka') && (b.targetCountryCode === 'GR' || b.targetCountryCode === 'MK')) return true;
    if (countryLower.includes('crna gora') && b.targetCountryCode === 'ME') return true;
    if (countryLower.includes('bosna') && b.targetCountryCode === 'BA') return true;
    if (countryLower.includes('hrvatska') && b.targetCountryCode === 'HR') return true;
    if (countryLower.includes('bugarska') && b.targetCountryCode === 'BG') return true;
    if (countryLower.includes('rumunija') && b.targetCountryCode === 'RO') return true;

    return false;
  });
}
