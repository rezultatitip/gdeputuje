import {
  TravelPackage,
  SearchFilters,
  TransportOption,
  AccommodationOption,
} from '../types/travel';

// High-fidelity photography assets bundled by Vite
import heroImg from '../assets/images/hero_balkan_travel_1794239671859.jpg';
import taraImg from '../assets/images/dest_mountain_tara_1794239672330.jpg';
import kotorImg from '../assets/images/dest_sea_mediterranean_1794239673631.jpg';
import ohridImg from '../assets/images/dest_lake_ohrid_1794239674029.jpg';

export const IMAGES = {
  hero: heroImg,
  tara: taraImg,
  kotor: kotorImg,
  ohrid: ohridImg,
};

export const EUR_TO_RSD_RATE = 117.2;

export const CITY_COORDINATES: Record<string, { lat: number; lng: number }> = {
  // Srbija — veći gradovi i centri
  'Beograd': { lat: 44.7866, lng: 20.4489 },
  'Novi Sad': { lat: 45.2671, lng: 19.8335 },
  'Niš': { lat: 43.3209, lng: 21.8958 },
  'Kragujevac': { lat: 44.0128, lng: 20.9260 },
  'Subotica': { lat: 46.1005, lng: 19.6651 },
  'Vranje': { lat: 42.5514, lng: 21.9003 },
  'Leskovac': { lat: 42.9981, lng: 21.9461 },
  'Čačak': { lat: 43.8914, lng: 20.3497 },
  'Užice': { lat: 43.8556, lng: 19.8425 },
  'Kruševac': { lat: 43.5800, lng: 21.3339 },
  'Kraljevo': { lat: 43.7258, lng: 20.6894 },
  'Valjevo': { lat: 44.2751, lng: 19.8982 },
  'Šabac': { lat: 44.7489, lng: 19.6908 },
  'Novi Pazar': { lat: 43.1367, lng: 20.5122 },
  'Pančevo': { lat: 44.8708, lng: 20.6403 },
  'Zrenjanin': { lat: 45.3836, lng: 20.3906 },
  'Sombor': { lat: 45.7742, lng: 19.1122 },
  'Pirot': { lat: 43.1531, lng: 22.5861 },
  'Zaječar': { lat: 43.9036, lng: 22.2747 },
  'Požarevac': { lat: 44.6213, lng: 21.1878 },
  'Smederevo': { lat: 44.6628, lng: 20.9300 },
  'Jagodina': { lat: 43.9771, lng: 21.2612 },
  'Bor': { lat: 44.0749, lng: 22.0959 },
  'Prokuplje': { lat: 43.2342, lng: 21.5878 },
  'Kikinda': { lat: 45.8297, lng: 20.4653 },

  // Region & Susedstvo — veći centri van Srbije
  'Zagreb': { lat: 45.8150, lng: 15.9819 },
  'Split': { lat: 43.5081, lng: 16.4402 },
  'Rijeka': { lat: 45.3271, lng: 14.4422 },
  'Osijek': { lat: 45.5550, lng: 18.6955 },
  'Sofija': { lat: 42.6977, lng: 23.3219 },
  'Skoplje': { lat: 41.9981, lng: 21.4254 },
  'Bitolj': { lat: 41.0319, lng: 21.3347 },
  'Podgorica': { lat: 42.4304, lng: 19.2594 },
  'Nikšić': { lat: 42.7731, lng: 18.9445 },
  'Bar': { lat: 42.0931, lng: 19.1003 },
  'Sarajevo': { lat: 43.8563, lng: 18.4131 },
  'Banjaluka': { lat: 44.7722, lng: 17.1910 },
  'Tuzla': { lat: 44.5384, lng: 18.6671 },
  'Mostar': { lat: 43.3438, lng: 17.8078 },
  'Bijeljina': { lat: 44.7587, lng: 19.2144 },
  'Ljubljana': { lat: 46.0569, lng: 14.5058 },
  'Maribor': { lat: 46.5547, lng: 15.6459 },
  'Budimpešta': { lat: 47.4979, lng: 19.0402 },
  'Segedin': { lat: 46.2530, lng: 20.1414 },
  'Temišvar': { lat: 45.7537, lng: 21.2257 },
  'Beč': { lat: 48.2082, lng: 16.3738 },
  'Solun': { lat: 40.6401, lng: 22.9444 },
};

export const PRESET_CITIES = [
  'Svi gradovi',
  // Srbija
  'Beograd',
  'Novi Sad',
  'Niš',
  'Kragujevac',
  'Subotica',
  'Vranje',
  'Leskovac',
  'Čačak',
  'Užice',
  'Kruševac',
  'Kraljevo',
  'Valjevo',
  'Šabac',
  'Novi Pazar',
  'Pančevo',
  'Zrenjanin',
  'Sombor',
  'Pirot',
  'Zaječar',
  'Požarevac',
  // Region & Susedstvo
  'Zagreb',
  'Skoplje',
  'Sofija',
  'Podgorica',
  'Sarajevo',
  'Banjaluka',
  'Tuzla',
  'Mostar',
  'Ljubljana',
  'Budimpešta',
  'Temišvar',
  'Split',
];

/**
 * ARHITEKTURA API INTEGRACIJE:
 * Ovaj servis služi kao apstrakcija i fasada (Adapter pattern) za turističke podatke.
 * U fazi 1 koristi verodostojne demonstracione podatke sa stvarnim regionalnim rutama i cenama.
 * Za produkciju se u funkcijama ispod dodaju pozivi ka:
 *  - Amadeus / Skyscanner Flights API (avionske karte)
 *  - BalkanViator / FlixBus API (autobuske linije)
 *  - Booking.com / Hotelbeds / Airbnb API (smeštajni kapaciteti)
 */

export const DEMO_PACKAGES: TravelPackage[] = [
  {
    id: 'pkg-vrnjacka-banja',
    title: 'Vikend opuštanje u Vrnjačkoj Banji',
    destinationName: 'Vrnjačka Banja',
    country: 'Srbija',
    category: 'banje',
    durationType: 'vikend',
    defaultNights: 2,
    originCity: 'Beograd',
    heroImage: IMAGES.hero,
    coordinates: { lat: 43.623, lng: 20.895 },
    highlights: ['Termalni izvori', 'Japanski vrt', 'Most ljubavi', 'Promenada'],
    description: 'Najpoznatija srpska banja sa lekovitim izvorima, prelepim banjskim parkom i bogatom spa ponudom idealnom za beg od gradske gužve.',
    recommendedDailyBudgetEUR: 18,
    bestSeason: 'Tokom cele godine',
    agencyBenchmarkPriceEUR: 85,
    isPopular: true,
    transports: [
      {
        id: 'tr-vb-bus-1',
        type: 'bus',
        provider: 'Niš-Ekspres',
        originCity: 'Beograd',
        destinationCity: 'Vrnjačka Banja',
        departureTime: '07:30',
        arrivalTime: '10:45',
        durationHours: 3.25,
        pricePerPersonEUR: 14,
        returnDepartureTime: '17:15',
        returnArrivalTime: '20:30',
        baggageNote: 'Uključen 1 kofer + ručni prtljag',
        isDirect: true,
        bookingNote: 'Polazak sa BAS stanice Beograd',
      },
      {
        id: 'tr-vb-bus-2',
        type: 'bus',
        provider: 'Lasta',
        originCity: 'Beograd',
        destinationCity: 'Vrnjačka Banja',
        departureTime: '12:00',
        arrivalTime: '15:20',
        durationHours: 3.3,
        pricePerPersonEUR: 13.5,
        returnDepartureTime: '18:30',
        returnArrivalTime: '21:50',
        baggageNote: 'Uključen kofer',
        isDirect: true,
        bookingNote: 'Redovna linija sa novim autobusima',
      },
      {
        id: 'tr-vb-car',
        type: 'car',
        provider: 'Sopstveni automobil (procenjeno)',
        originCity: 'Beograd',
        destinationCity: 'Vrnjačka Banja',
        departureTime: 'Fleksibilno',
        arrivalTime: 'Po želji (~2.5h)',
        durationHours: 2.5,
        pricePerPersonEUR: 11, // proračun goriva i putarine po osobi za dvoje (ukupno ~22€)
        returnDepartureTime: 'Fleksibilno',
        returnArrivalTime: 'Fleksibilno',
        baggageNote: 'Neograničen gepek',
        isDirect: true,
        bookingNote: 'Auto-put Miloš Veliki ili Koridor 10',
      },
    ],
    accommodations: [
      {
        id: 'acc-vb-studio',
        name: 'Apartmani Sunčana Dolina',
        type: 'apartman',
        rating: 9.3,
        reviewCount: 148,
        pricePerNightEUR: 28,
        locationDescription: '350m od Promenade i izvora Snežnik',
        amenities: ['Besplatan WiFi', 'Parking', 'Kuhinja', 'Terasa', 'Klima'],
        roomType: 'Studio apartman sa bračnim krevetom',
        image: IMAGES.hero,
      },
      {
        id: 'acc-vb-spa-hotel',
        name: 'Hotel & Spa Fontana',
        type: 'spa_resort',
        stars: 4,
        rating: 9.1,
        reviewCount: 312,
        pricePerNightEUR: 62,
        locationDescription: 'U samom centru banjskog parka',
        amenities: ['Neograničen Spa & Wellness', 'Doručak uključen', 'Bazen', 'Sauna'],
        roomType: 'Standardna dvokrevetna soba',
        image: IMAGES.hero,
      },
    ],
    defaultTransportId: 'tr-vb-bus-1',
    defaultAccommodationId: 'acc-vb-studio',
    whatToSee: [
      'Izvori Topla Voda, Snežnik i Jezero',
      'Šetnja kroz uređeni Japanski vrt',
      'Most ljubavi sa katancima',
      'Zamak Belimarković (muzej)',
    ],
    budgetTips: [
      'Ponesite staklenu flašicu za besplatno točenje mineralne vode na izvorima.',
      'Dnevni spa ulaz u javnim kupatilima košta svega 6–8 € ako ne uzimate hotel sa spa centrom.',
      'Ručak u lokalnim kafanama ("Kruna", "Cvetni konaci") košta oko 7–10 € po osobi sa pićem.',
    ],
  },
  {
    id: 'pkg-rim-nis',
    title: 'Rim City Break avionom iz Niša',
    destinationName: 'Rim',
    country: 'Italija',
    category: 'gradovi',
    durationType: 'kratki',
    defaultNights: 3,
    originCity: 'Niš',
    heroImage: IMAGES.kotor,
    coordinates: { lat: 41.902, lng: 12.496 },
    highlights: ['Koloseum', 'Fontana di Trevi', 'Vatikan', 'Trastevere'],
    description: 'Direktan niskotarifni let iz Niša za Rim Fiumicino ili Ciampino. Fantastičan produženi vikend u Večnom gradu za neverovatno povoljan budžet.',
    recommendedDailyBudgetEUR: 30,
    bestSeason: 'Proleće i jesen',
    agencyBenchmarkPriceEUR: 220,
    isPopular: true,
    transports: [
      {
        id: 'tr-rome-wizz',
        type: 'flight',
        provider: 'Wizz Air (direktan let)',
        originCity: 'Niš (INI)',
        destinationCity: 'Rim Fiumicino (FCO)',
        departureTime: '06:15',
        arrivalTime: '07:55',
        durationHours: 1.6,
        pricePerPersonEUR: 42,
        returnDepartureTime: '08:30',
        returnArrivalTime: '10:10',
        baggageNote: 'Uključen ručni ranac (40x30x20cm)',
        isDirect: true,
        bookingNote: 'Redovna linija utorkom, četvrtkom i nedeljom',
      },
      {
        id: 'tr-rome-ryanair',
        type: 'flight',
        provider: 'Ryanair (iz Niša)',
        originCity: 'Niš (INI)',
        destinationCity: 'Rim Ciampino (CIA)',
        departureTime: '13:40',
        arrivalTime: '15:20',
        durationHours: 1.6,
        pricePerPersonEUR: 49,
        returnDepartureTime: '16:00',
        returnArrivalTime: '17:40',
        baggageNote: 'Ručni prtljag uključen',
        isDirect: true,
        bookingNote: 'Najjeftinije karte 3–6 nedelja pre polaska',
      },
    ],
    accommodations: [
      {
        id: 'acc-rome-guesthouse',
        name: 'Trastevere Cozy Rooms',
        type: 'privatni_smestaj',
        rating: 8.9,
        reviewCount: 95,
        pricePerNightEUR: 34,
        locationDescription: 'Blizu stanice metroa i linija ka centru',
        amenities: ['Besplatan WiFi', 'Klima', 'Sopstveno kupatilo', 'Aparat za espreso'],
        roomType: 'Dvokrevetna soba',
        image: IMAGES.kotor,
      },
      {
        id: 'acc-rome-hotel',
        name: 'Hotel San Marco',
        type: 'hotel',
        stars: 3,
        rating: 8.6,
        reviewCount: 220,
        pricePerNightEUR: 55,
        locationDescription: '5 minuta hoda od stanice Termini',
        amenities: ['Doručak', 'Recepcija 24h', 'WiFi', 'Klima'],
        roomType: 'Standard dvokrevetna soba',
        image: IMAGES.kotor,
      },
    ],
    defaultTransportId: 'tr-rome-wizz',
    defaultAccommodationId: 'acc-rome-guesthouse',
    whatToSee: [
      'Panteon i Fontana di Trevi (besplatan obilazak)',
      'Šetnja istorijskim kvartom Trastevere uveče',
      'Koloseum i Rimski Forum',
      'Trg Svetog Petra i Vatikanski muzeji',
    ],
    budgetTips: [
      'Kupite Metro 24/48h kartu za neograničen gradski prevoz.',
      'Pizza al taglio (pica na meru) u pekarama je vrhunska i košta 4–6 € za obilan obrok.',
      'Flašicu sa vodom dopunjujte na legendarnim rimskim česmama "nasoni" sa pijaćom ledenom vodom.',
    ],
  },
  {
    id: 'pkg-ohrid-jezero',
    title: 'Magični Ohrid: Jezero, tradicija i sunce',
    destinationName: 'Ohrid',
    country: 'Severna Makedonija',
    category: 'jezera',
    durationType: 'kratki',
    defaultNights: 3,
    originCity: 'Beograd',
    heroImage: IMAGES.ohrid,
    coordinates: { lat: 41.117, lng: 20.801 },
    highlights: ['Sveti Jovan Kaneo', 'Sveti Naum', 'Starogradska čaršija', 'Plaža Ljubaništa'],
    description: 'Jedno od najstarijih i najlepših jezera u Evropi. Izuzetno pristupačne cene hrane, smeštaja i prevoza čine Ohrid pravim biserom za budžetska putovanja.',
    recommendedDailyBudgetEUR: 15,
    bestSeason: 'Od maja do oktobra',
    agencyBenchmarkPriceEUR: 115,
    isPopular: true,
    transports: [
      {
        id: 'tr-oh-bus-1',
        type: 'bus',
        provider: 'BS Tours / Galeb',
        originCity: 'Beograd',
        destinationCity: 'Ohrid',
        departureTime: '21:00',
        arrivalTime: '06:30',
        durationHours: 9.5,
        pricePerPersonEUR: 32,
        returnDepartureTime: '20:30',
        returnArrivalTime: '06:00',
        baggageNote: 'Noćna vožnja – štedi jedno noćenje!',
        isDirect: true,
        bookingNote: 'Polazak iz Beograda i Niša',
      },
      {
        id: 'tr-oh-car',
        type: 'car',
        provider: 'Sopstveni automobil (preko Skoplja)',
        originCity: 'Beograd',
        destinationCity: 'Ohrid',
        departureTime: 'Fleksibilno',
        arrivalTime: 'Nakon ~6.5h',
        durationHours: 6.5,
        pricePerPersonEUR: 26,
        returnDepartureTime: 'Fleksibilno',
        returnArrivalTime: 'Fleksibilno',
        baggageNote: 'Neograničen gepek',
        isDirect: true,
        bookingNote: 'Gorivo u Makedoniji je znatno jeftinije!',
      },
    ],
    accommodations: [
      {
        id: 'acc-oh-apartman',
        name: 'Villa Kaneo View Apartments',
        type: 'apartman',
        rating: 9.5,
        reviewCount: 164,
        pricePerNightEUR: 22,
        locationDescription: 'Stari grad, 100m od jezera',
        amenities: ['Pogled na jezero', 'WiFi', 'Balkon', 'Kuhinjica'],
        roomType: 'Apartman sa pogledom na vodu',
        image: IMAGES.ohrid,
      },
      {
        id: 'acc-oh-hotel',
        name: 'Hotel Tino Sveti Stefan',
        type: 'hotel',
        stars: 4,
        rating: 9.0,
        reviewCount: 305,
        pricePerNightEUR: 48,
        locationDescription: 'Uz samu obalu, privatna plaža',
        amenities: ['Spa centar', 'Doručak uključen', 'Bazen', 'Besplatan parking'],
        roomType: 'Dvokrevetna soba',
        image: IMAGES.ohrid,
      },
    ],
    defaultTransportId: 'tr-oh-bus-1',
    defaultAccommodationId: 'acc-oh-apartman',
    whatToSee: [
      'Crkva Sv. Jovan Kaneo na steni iznad jezera',
      'Izvori Crnog Drima kod manastira Sveti Naum',
      'Vožnja čamcem po jezeru',
      'Samoilova tvrđava i Antički teatar',
    ],
    budgetTips: [
      'Probajte ohridsku pastrmku i tavče na gravče – kompletan tradicionalni ručak je 6–8 €.',
      'Ulaznice za muzeje i tvrđavu su samo 1.5–2 €.',
      'Kupovina ohridskih bisera u porodičnim radnjama Filevi ili Talevi ima sertifikat autentičnosti.',
    ],
  },
  {
    id: 'pkg-tara-zlatibor',
    title: 'Vikend u brvnarama Nacionalnog parka Tara',
    destinationName: 'Tara i Zaovine',
    country: 'Srbija',
    category: 'planine',
    durationType: 'vikend',
    defaultNights: 2,
    originCity: 'Beograd',
    heroImage: IMAGES.tara,
    coordinates: { lat: 43.914, lng: 19.421 },
    highlights: ['Vidikovac Banjska stena', 'Jezero Zaovine', 'Kaluđerske bare', 'Perućac'],
    description: 'Čist planinski vazduh, miris borove šume, nestvarni vidikovci nad kanjonom Drine i autentične drvene brvnare za savršen reset uma.',
    recommendedDailyBudgetEUR: 16,
    bestSeason: 'Tokom cele godine',
    agencyBenchmarkPriceEUR: 90,
    isPopular: true,
    transports: [
      {
        id: 'tr-tara-car',
        type: 'car',
        provider: 'Sopstveni automobil (preporučeno)',
        originCity: 'Beograd',
        destinationCity: 'Tara (Mitrovac)',
        departureTime: 'Fleksibilno',
        arrivalTime: 'Za ~3.5h',
        durationHours: 3.5,
        pricePerPersonEUR: 14,
        returnDepartureTime: 'Fleksibilno',
        returnArrivalTime: 'Fleksibilno',
        baggageNote: 'Auto je idealan za obilazak vidikovaca na Tari',
        isDirect: true,
        bookingNote: 'Preko Valjeva i Bajine Bašte ili preko Užica',
      },
      {
        id: 'tr-tara-bus',
        type: 'bus',
        provider: 'Raketa / Severtrans',
        originCity: 'Beograd',
        destinationCity: 'Bajina Bašta / Tara',
        departureTime: '08:00',
        arrivalTime: '12:15',
        durationHours: 4.25,
        pricePerPersonEUR: 13,
        returnDepartureTime: '16:00',
        returnArrivalTime: '20:15',
        baggageNote: 'Uključen prtljag',
        isDirect: true,
        bookingNote: 'Polazak iz Beograda i Valjeva',
      },
    ],
    accommodations: [
      {
        id: 'acc-tara-brvnara',
        name: 'Drvene Brvnare Zaovinska Čarolija',
        type: 'etno_selo',
        rating: 9.6,
        reviewCount: 88,
        pricePerNightEUR: 32,
        locationDescription: 'Mitrovac na Tari, okruženo omorikama',
        amenities: ['Kamin', 'Drvena terasa', 'Besplatan roštilj', 'WiFi', 'Parking'],
        roomType: 'Kompletna planinska brvnara',
        image: IMAGES.tara,
      },
      {
        id: 'acc-tara-hotel',
        name: 'Vojna Ustanova Tara (Omorika)',
        type: 'hotel',
        stars: 3,
        rating: 8.7,
        reviewCount: 260,
        pricePerNightEUR: 45,
        locationDescription: 'Kaluđerske Bare, trim staze',
        amenities: ['Zatvoreni bazen', 'Polupansion uključen', 'Sauna', 'Kuglana'],
        roomType: 'Dvokrevetna soba',
        image: IMAGES.tara,
      },
    ],
    defaultTransportId: 'tr-tara-car',
    defaultAccommodationId: 'acc-tara-brvnara',
    whatToSee: [
      'Vidikovac Banjska Stena sa pogledom na jezero Perućac',
      'Tepih livada i stanište Pančićeve omorike',
      'Kupanje ili kajaking na Zaovinskom jezeru',
      'Reka Vrelo (Godina) dužine tačno 365 metara',
    ],
    budgetTips: [
      'Ulaz u Nacionalni park se plaća simboličnih 300 RSD (2.5 €) po vozilu.',
      'Spremite domaći roštilj na drva uz jezero umesto svakodnevnih restorana.',
      'Kupite domaći planinski med i sir direktno od meštana u selu Zaovine.',
    ],
  },
  {
    id: 'pkg-kotor-boka',
    title: 'Boka Kotorska i Perast: Jadranski fjord',
    destinationName: 'Kotor',
    country: 'Crna Gora',
    category: 'more',
    durationType: 'kratki',
    defaultNights: 3,
    originCity: 'Beograd',
    heroImage: IMAGES.kotor,
    coordinates: { lat: 42.424, lng: 18.771 },
    highlights: ['Kotorski Stari Grad', 'Gospa od Škrpjela', 'Serpentina ka Njegušima', 'Perast'],
    description: 'Jedan od najspektakularnijih zaliva na svetu pod zaštitom UNESCO-a. Kamene palate, uske kalete, čisto more i venecijanska istorija.',
    recommendedDailyBudgetEUR: 24,
    bestSeason: 'Od maja do oktobra',
    agencyBenchmarkPriceEUR: 165,
    isPopular: true,
    transports: [
      {
        id: 'tr-ko-bus',
        type: 'bus',
        provider: 'Božur / Blue Line',
        originCity: 'Beograd',
        destinationCity: 'Kotor',
        departureTime: '20:30',
        arrivalTime: '07:45',
        durationHours: 11.25,
        pricePerPersonEUR: 33,
        returnDepartureTime: '19:00',
        returnArrivalTime: '06:30',
        baggageNote: 'Noćna linija (ušteda 1 noćenja)',
        isDirect: true,
        bookingNote: 'Prolazi kroz Čačak, Užice i Podgoricu',
      },
      {
        id: 'tr-ko-air',
        type: 'flight',
        provider: 'Air Montenegro / Air Serbia',
        originCity: 'Beograd (BEG)',
        destinationCity: 'Tivat (TIV)',
        departureTime: '09:10',
        arrivalTime: '10:00',
        durationHours: 0.85,
        pricePerPersonEUR: 68,
        returnDepartureTime: '16:40',
        returnArrivalTime: '17:30',
        baggageNote: '8kg ručni prtljag uključen',
        isDirect: true,
        bookingNote: 'Aerodrom Tivat je samo 8km od Starog grada Kotora',
      },
    ],
    accommodations: [
      {
        id: 'acc-ko-oldtown',
        name: 'Palazzo Drago Historic Rooms',
        type: 'privatni_smestaj',
        rating: 9.4,
        reviewCount: 130,
        pricePerNightEUR: 36,
        locationDescription: 'Unutar zidina Starog grada Kotora',
        amenities: ['Autentični kameni zidovi', 'WiFi', 'Klima', 'Pogled na trg'],
        roomType: 'Rustična dvokrevetna soba',
        image: IMAGES.kotor,
      },
      {
        id: 'acc-ko-hotel',
        name: 'Boutique Hotel Astoria',
        type: 'hotel',
        stars: 4,
        rating: 9.1,
        reviewCount: 198,
        pricePerNightEUR: 75,
        locationDescription: 'Pored Trga od oružja',
        amenities: ['Doručak uključen', 'Restoran', 'Bar', 'Room service'],
        roomType: 'Deluxe dvokrevetna soba',
        image: IMAGES.kotor,
      },
    ],
    defaultTransportId: 'tr-ko-bus',
    defaultAccommodationId: 'acc-ko-oldtown',
    whatToSee: [
      'Penjanje na tvrđavu Sveti Ivan (1350 stepenika) za nestvaran pogled',
      'Izlet brodićem do Gospe od Škrpjela u Perastu',
      'Muzički trgovi i restorani u Starom gradu',
      'Kupanje u obližnjim Prčanju ili Dobroti',
    ],
    budgetTips: [
      'Ako se penjete na tvrđavu pre 08:00 ujutru, ulaz se često ne naplaćuje, a izbegavate podnevnu vrućinu.',
      'Gradski plavi autobus ("Blue Line") vozi duž cele obale zaliva za samo 1.5–2 €.',
      'Sveže girice i lignje u lokalnim konobama su znatno povoljnije nego fensi restorani na rivi.',
    ],
  },
  {
    id: 'pkg-solun-egej',
    title: 'Solun i Egejska obala: Šoping, hrana i more',
    destinationName: 'Solun i Halkidiki',
    country: 'Grčka',
    category: 'more',
    durationType: 'kratki',
    defaultNights: 3,
    originCity: 'Beograd',
    heroImage: IMAGES.kotor,
    coordinates: { lat: 40.640, lng: 22.944 },
    highlights: ['Bela kula', 'Aristotelov trg', 'Kafane u Ladadici', 'Plaže na Kasandri'],
    description: 'Najomiljenija grčka destinacija za ljude iz Srbije. Fantastičan miks mediteranske hrane, šopinga i prelepih peščanih plaža.',
    recommendedDailyBudgetEUR: 25,
    bestSeason: 'Od aprila do oktobra',
    agencyBenchmarkPriceEUR: 145,
    isPopular: true,
    transports: [
      {
        id: 'tr-skg-bus',
        type: 'bus',
        provider: 'FP Travel / Siamos Tours',
        originCity: 'Beograd',
        destinationCity: 'Solun',
        departureTime: '21:30',
        arrivalTime: '07:30',
        durationHours: 9.0,
        pricePerPersonEUR: 35,
        returnDepartureTime: '19:00',
        returnArrivalTime: '05:30',
        baggageNote: '2 kofera uključena po putniku',
        isDirect: true,
        bookingNote: 'Redovni polasci iz Beograda i Niša',
      },
      {
        id: 'tr-skg-air',
        type: 'flight',
        provider: 'Air Serbia (direktno)',
        originCity: 'Beograd (BEG)',
        destinationCity: 'Solun (SKG)',
        departureTime: '11:45',
        arrivalTime: '14:00',
        durationHours: 1.25,
        pricePerPersonEUR: 58,
        returnDepartureTime: '14:45',
        returnArrivalTime: '15:00',
        baggageNote: 'Ručni prtljag uključen',
        isDirect: true,
        bookingNote: 'Dostupno tokom cele letnje i jesenje sezone',
      },
    ],
    accommodations: [
      {
        id: 'acc-skg-apt',
        name: 'Thessaloniki Urban Studios',
        type: 'apartman',
        rating: 9.0,
        reviewCount: 215,
        pricePerNightEUR: 32,
        locationDescription: '800m od Aristotelovog trga',
        amenities: ['Klima', 'WiFi', 'Potpuno opremljena kuhinja', 'Smart TV'],
        roomType: 'Moderni studio apartman',
        image: IMAGES.kotor,
      },
      {
        id: 'acc-skg-hotel',
        name: 'Capsis Hotel Thessaloniki',
        type: 'hotel',
        stars: 4,
        rating: 8.8,
        reviewCount: 420,
        pricePerNightEUR: 64,
        locationDescription: 'Blizu železničke stanice i centra',
        amenities: ['Bazen na krovu', 'Doručak uključen', 'Sauna', 'Fitnes'],
        roomType: 'Dvokrevetna soba',
        image: IMAGES.kotor,
      },
    ],
    defaultTransportId: 'tr-skg-bus',
    defaultAccommodationId: 'acc-skg-apt',
    whatToSee: [
      'Zalazak sunca kod Bele kule na solunskoj promenadi',
      'Večera uz buzuki i meze u boemskoj četvrti Ladadika',
      'Obilazak vizantijske tvrđave Ano Poli',
      'Dnevni izlet na tirkizne plaže Kasandre ili Sitonije',
    ],
    budgetTips: [
      'Giros u Solunu je ogroman i košta samo 3.8–4.5 €.',
      'Kafa "freddo espresso" na šetalištu često uključuje besplatnu flaširanu vodu i kolačić.',
      'Lokalni gradski autobus OASTH košta samo 0.90 € po vožnji.',
    ],
  },
  {
    id: 'pkg-sokobanja',
    title: 'Sokobanja: „Sokobanja, Soko-grad, dođeš star, odeš mlad“',
    destinationName: 'Sokobanja',
    country: 'Srbija',
    category: 'banje',
    durationType: 'vikend',
    defaultNights: 2,
    originCity: 'Niš',
    heroImage: IMAGES.hero,
    coordinates: { lat: 43.645, lng: 21.875 },
    highlights: ['Banjica plaža', 'Tursko kupatilo Amam', 'Bovansko jezero', 'Vodopad Ripaljka'],
    description: 'Najzelenija srpska banja sa neverovatnom koncentracijom negativnih jona, lekovitim vazduhom i prelepom prirodom podno planine Ozren.',
    recommendedDailyBudgetEUR: 14,
    bestSeason: 'Proleće, leto i jesen',
    agencyBenchmarkPriceEUR: 65,
    isPopular: true,
    transports: [
      {
        id: 'tr-sb-bus-nis',
        type: 'bus',
        provider: 'Niš-Ekspres',
        originCity: 'Niš',
        destinationCity: 'Sokobanja',
        departureTime: '08:15',
        arrivalTime: '09:30',
        durationHours: 1.25,
        pricePerPersonEUR: 5.5,
        returnDepartureTime: '17:00',
        returnArrivalTime: '18:15',
        baggageNote: 'Kratka vožnja, polasci na svakih sat vremena',
        isDirect: true,
        bookingNote: 'Najpovoljniji vikend izlazak iz južne Srbije',
      },
      {
        id: 'tr-sb-bus-bg',
        type: 'bus',
        provider: 'Soko Prevoz / Niš-Ekspres',
        originCity: 'Beograd',
        destinationCity: 'Sokobanja',
        departureTime: '07:00',
        arrivalTime: '10:30',
        durationHours: 3.5,
        pricePerPersonEUR: 14,
        returnDepartureTime: '16:30',
        returnArrivalTime: '20:00',
        baggageNote: 'Kofer uključen',
        isDirect: true,
        bookingNote: 'Polazak svakog jutra sa BAS',
      },
    ],
    accommodations: [
      {
        id: 'acc-sb-apartman',
        name: 'Vila Oaza Sokobanja',
        type: 'privatni_smestaj',
        rating: 9.4,
        reviewCount: 112,
        pricePerNightEUR: 20,
        locationDescription: '400m od mermernog šetališta',
        amenities: ['Dvorište sa cvećem', 'WiFi', 'Parking', 'Kuhinja'],
        roomType: 'Komforan studio apartman',
        image: IMAGES.hero,
      },
      {
        id: 'acc-sb-spa',
        name: 'Hotel Sunce Sokobanja',
        type: 'spa_resort',
        stars: 4,
        rating: 9.3,
        reviewCount: 380,
        pricePerNightEUR: 68,
        locationDescription: 'Uz samu reku Moravicu',
        amenities: ['Najveći Spa & Wellness na Balkanu', 'Doručak i večera', 'Unutrašnji bazeni'],
        roomType: 'Superior soba',
        image: IMAGES.hero,
      },
    ],
    defaultTransportId: 'tr-sb-bus-nis',
    defaultAccommodationId: 'acc-sb-apartman',
    whatToSee: [
      'Autentično tursko kupatilo Amam iz 15. veka',
      'Vodopad Ripaljka na Ozrenu (visok 17.5m)',
      'Odmorište Lepterija i pećina',
      'Izletište i kupalište na Bovanskom jezeru',
    ],
    budgetTips: [
      'Kupanje u bazenima turskog amama košta svega 400 RSD (3.5 €) po terminu.',
      'Čuvena sokobanjska lepinja sa kajmakom i pršutom je 3–4 €.',
      'Sokobanjski banjski park je besplatan i nudi besplatne večernje koncerte leti.',
    ],
  },
  {
    id: 'pkg-budimpesta-vikend',
    title: 'Budimpešta City Break: Dunav, terme i dvorci',
    destinationName: 'Budimpešta',
    country: 'Mađarska',
    category: 'gradovi',
    durationType: 'vikend',
    defaultNights: 2,
    originCity: 'Novi Sad',
    heroImage: IMAGES.kotor,
    coordinates: { lat: 47.497, lng: 19.040 },
    highlights: ['Ribarski bastion', 'Zgrada Parlamenta', 'Terme Sečenji', 'Ruin barovi'],
    description: 'Jedna od najlepših evropskih metropola na samo par sati vožnje od Novog Sada i Beograda. Kraljevska arhitektura i termalna kupatila.',
    recommendedDailyBudgetEUR: 28,
    bestSeason: 'Tokom cele godine',
    agencyBenchmarkPriceEUR: 125,
    isPopular: true,
    transports: [
      {
        id: 'tr-bud-bus',
        type: 'bus',
        provider: 'FlixBus',
        originCity: 'Novi Sad',
        destinationCity: 'Budimpešta (Népliget)',
        departureTime: '07:15',
        arrivalTime: '11:45',
        durationHours: 4.5,
        pricePerPersonEUR: 21,
        returnDepartureTime: '17:30',
        returnArrivalTime: '22:00',
        baggageNote: 'Besplatan Wi-Fi i utičnice u busu',
        isDirect: true,
        bookingNote: 'Najudobniji direktan autobus preko prelaza Horgoš/Kelebija',
      },
      {
        id: 'tr-bud-car',
        type: 'car',
        provider: 'Sopstveni automobil (auto-put M5)',
        originCity: 'Novi Sad',
        destinationCity: 'Budimpešta',
        departureTime: 'Fleksibilno',
        arrivalTime: 'Za ~3.5h',
        durationHours: 3.5,
        pricePerPersonEUR: 16,
        returnDepartureTime: 'Fleksibilno',
        returnArrivalTime: 'Fleksibilno',
        baggageNote: 'Potrebna mađarska e-vinjeta (~15€ za 10 dana po vozilu)',
        isDirect: true,
        bookingNote: 'Deljenje troška goriva i vinjete na 2–4 osobe je super povoljno',
      },
    ],
    accommodations: [
      {
        id: 'acc-bud-apt',
        name: 'Budapest Central Jewish Quarter Studio',
        type: 'apartman',
        rating: 9.1,
        reviewCount: 340,
        pricePerNightEUR: 35,
        locationDescription: '7. distrikt, srce ruin barova i restorana',
        amenities: ['Klima', 'WiFi', 'Kuhinja', 'Lift'],
        roomType: 'Kompletno renoviran studio apartman',
        image: IMAGES.kotor,
      },
      {
        id: 'acc-bud-hotel',
        name: 'Ibis Budapest Heroes Square',
        type: 'hotel',
        stars: 3,
        rating: 8.7,
        reviewCount: 450,
        pricePerNightEUR: 52,
        locationDescription: 'Pored Trga Heroja i Sečenji banje',
        amenities: ['Doručak uključen', 'Recepcija 24h', 'Klima'],
        roomType: 'Standard dvokrevetna soba',
        image: IMAGES.kotor,
      },
    ],
    defaultTransportId: 'tr-bud-bus',
    defaultAccommodationId: 'acc-bud-apt',
    whatToSee: [
      'Panoramski pogled sa Ribarskog bastiona na Peštu',
      'Večernje krstarenje Dunavom pored osvetljenog Parlamenta',
      'Opuštanje u toplim bazenima Széchenyi termi',
      'Pivo u kultnom ruin pubu Szimpla Kert',
    ],
    budgetTips: [
      'Budimpeštanska 24h ili 72h karta važi za metro, tramvaje i žute istorijske linije.',
      'Probajte lángos sa sirom i pavlakom na Velikoj pijaci (Nagy Vásárcsarnok) za ~3–4 €.',
      'Mnogi vidikovci i dvorci u Budimu su besplatni za spoljni obilazak.',
    ],
  },
  {
    id: 'pkg-palic-subotica',
    title: 'Vikend secesije i vina na Palićkom jezeru',
    destinationName: 'Palić i Subotica',
    country: 'Srbija',
    category: 'jezera',
    durationType: 'vikend',
    defaultNights: 2,
    originCity: 'Beograd',
    heroImage: IMAGES.ohrid,
    coordinates: { lat: 46.104, lng: 19.761 },
    highlights: ['Palićka promenada', 'Gradska kuća Subotica', 'Vinski salaši', 'Zoološki vrt Palić'],
    description: 'Bajkovita arhitektura mađarske secesije, mirno jezero, autentični vojvođanski salaši sa tamburašima i vrhunskim peskovitim vinima.',
    recommendedDailyBudgetEUR: 16,
    bestSeason: 'Proleće, leto i jesen',
    agencyBenchmarkPriceEUR: 75,
    isPopular: false,
    transports: [
      {
        id: 'tr-palic-train',
        type: 'bus', // Brzi voz Soko + bus
        provider: 'Srbija Voz (Brzi voz Soko do Subotice)',
        originCity: 'Beograd (Prokop)',
        destinationCity: 'Subotica / Palić',
        departureTime: '09:00',
        arrivalTime: '10:15',
        durationHours: 1.25,
        pricePerPersonEUR: 11,
        returnDepartureTime: '18:30',
        returnArrivalTime: '19:45',
        baggageNote: 'Brzi voz 200 km/h sa besplatnim WiFi-jem',
        isDirect: true,
        bookingNote: 'Do Palića vozi gradski bus br. 6 na svakih 15 min',
      },
      {
        id: 'tr-palic-car',
        type: 'car',
        provider: 'Sopstveni automobil (auto-put E-75)',
        originCity: 'Beograd',
        destinationCity: 'Palić',
        departureTime: 'Fleksibilno',
        arrivalTime: 'Za ~2h',
        durationHours: 2.0,
        pricePerPersonEUR: 12,
        returnDepartureTime: 'Fleksibilno',
        returnArrivalTime: 'Fleksibilno',
        baggageNote: 'Direktan izlaz sa auto-puta',
        isDirect: true,
        bookingNote: 'Putarina i gorivo podeljeni na dvoje',
      },
    ],
    accommodations: [
      {
        id: 'acc-palic-vila',
        name: 'Vila Palićka Idila',
        type: 'apartman',
        rating: 9.2,
        reviewCount: 94,
        pricePerNightEUR: 24,
        locationDescription: '200m od Velikog parka i obale jezera',
        amenities: ['Veliko dvorište', 'WiFi', 'Parking', 'Klima'],
        roomType: 'Studio sa francuskim ležajem',
        image: IMAGES.ohrid,
      },
      {
        id: 'acc-palic-hotel',
        name: 'Hotel Prezident Palić',
        type: 'hotel',
        stars: 4,
        rating: 8.9,
        reviewCount: 180,
        pricePerNightEUR: 54,
        locationDescription: 'U srcu stogodišnjeg parka',
        amenities: ['Zatvoreni i otvoreni bazen', 'Doručak uključen', 'Wellness', 'Masaže'],
        roomType: 'Komforna dvokrevetna soba',
        image: IMAGES.ohrid,
      },
    ],
    defaultTransportId: 'tr-palic-train',
    defaultAccommodationId: 'acc-palic-vila',
    whatToSee: [
      'Gradska kuća i Sinagoga u Subotici – remek-dela secesije',
      'Šetnja Ženskim štrandom i Velikom terasom na Paliću',
      'Poseta Vinskom dvoru ili vinariji Zvonko Bogdan',
      'Degustacija vojvođanskog perkelta i štrudli na salašu',
    ],
    budgetTips: [
      'Ulaznica za Subotičku sinagogu je simboličnih 250 RSD (~2 €).',
      'Rentirajte bicikl pored jezera za 3 € na ceo dan.',
      'Porcije na salašima su ogromne – jedno glavno jelo je često dovoljno za dvoje!',
    ],
  },
  {
    id: 'pkg-zlatibor-lastminute',
    title: 'Last-minute Zlatibor: Borovi vazduh i planinski beg',
    destinationName: 'Zlatibor',
    country: 'Srbija',
    category: 'planine',
    durationType: 'last_minute',
    defaultNights: 2,
    originCity: 'Beograd',
    heroImage: IMAGES.tara,
    coordinates: { lat: 43.726, lng: 19.699 },
    highlights: ['Zlatiborsko jezero', 'Gold Gondola', 'Stopića pećina', 'Sirogojno'],
    description: 'Trenutna last-minute ponuda sa popustom na smeštaj. Uživajte u komplet lepinjama, vožnji najdužom gondolom na svetu i čistom vazduhu.',
    recommendedDailyBudgetEUR: 18,
    bestSeason: 'Tokom cele godine',
    agencyBenchmarkPriceEUR: 80,
    isLastMinute: true,
    isPopular: true,
    transports: [
      {
        id: 'tr-zlat-bus',
        type: 'bus',
        provider: 'Gaga Turs / Raketa',
        originCity: 'Beograd',
        destinationCity: 'Zlatibor (Autobuska)',
        departureTime: '08:00',
        arrivalTime: '11:45',
        durationHours: 3.75,
        pricePerPersonEUR: 13,
        returnDepartureTime: '16:00',
        returnArrivalTime: '19:45',
        baggageNote: 'Direktno u centar Zlatibora',
        isDirect: true,
        bookingNote: 'Svakodnevni polasci',
      },
    ],
    accommodations: [
      {
        id: 'acc-zlat-apt',
        name: 'Apartmani Planinski Biser (Last Minute -25%)',
        type: 'apartman',
        rating: 9.3,
        reviewCount: 204,
        pricePerNightEUR: 25,
        locationDescription: 'Naselje Obudojevica, 600m od jezera',
        amenities: ['Besplatan parking', 'WiFi', 'Terasa sa pogledom na borove', 'Kuhinja'],
        roomType: 'Kompletan jednosoban apartman',
        image: IMAGES.tara,
      },
    ],
    defaultTransportId: 'tr-zlat-bus',
    defaultAccommodationId: 'acc-zlat-apt',
    whatToSee: [
      'Vožnja Gold Gondolom do vrha Tornik (9 km dužine)',
      'Stopića pećina sa krečnjačkim kadama',
      'Etno-selo Sirogojno i Muzej na otvorenom',
      'Vodopad Gostilje',
    ],
    budgetTips: [
      'Čuvenu komplet lepinju kod "Šuljage" ili u "Zlatiborskim noćima" možete pojesti za oko 3–4 €.',
      'Pešačke staze ka Spomeniku na Šumatnom brdu su potpuno besplatne i obeležene.',
    ],
  },
];

/**
 * Računa približnu drumsku udaljenost (km) između grada polaska i destinacije.
 */
export function calculateRoadDistanceKm(
  originCity: string,
  destinationCoords?: { lat: number; lng: number }
): number {
  if (!destinationCoords) return 220;
  // Pokušaj pronaći koordinate za uneto mesto
  const clean = originCity?.trim() || 'Beograd';
  const origin = CITY_COORDINATES[clean] || CITY_COORDINATES['Beograd'];
  const R = 6371; // km
  const dLat = ((destinationCoords.lat - origin.lat) * Math.PI) / 180;
  const dLon = ((destinationCoords.lng - origin.lng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((origin.lat * Math.PI) / 180) *
      Math.cos((destinationCoords.lat * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const straightLine = R * c;
  // Regionalni faktor krivudavosti puteva i autoputeva
  return Math.max(30, Math.round(straightLine * 1.34));
}

/**
 * Pronalazi odgovarajući prevoz iz paketa ili dinamički generiše
 * opciju za sopstveni prevoz (automobil) ako nema direktnog autobusa/leta.
 */
export function resolveTransportForCity(
  pkg: TravelPackage,
  originCity: string,
  persons = 2,
  selectedTransportId?: string
): {
  transport: TransportOption;
  isAutoGeneratedCar: boolean;
  hasDirectPublicTransport: boolean;
  advisoryNote?: string;
} {
  // Ako je izričito odabran ID prevoza iz paketa
  if (selectedTransportId) {
    const directMatch = pkg.transports.find((t) => t.id === selectedTransportId);
    if (directMatch) {
      return {
        transport: directMatch,
        isAutoGeneratedCar: directMatch.type === 'car',
        hasDirectPublicTransport: directMatch.type === 'flight' || directMatch.type === 'bus',
      };
    }
  }

  const cleanOrigin = originCity?.trim() || '';

  // 1. Provera da li paket već sadrži direktnu liniju koja eksplicitno pominje ovaj grad
  if (cleanOrigin && cleanOrigin !== 'Svi gradovi') {
    const directForOrigin = pkg.transports.find(
      (t) =>
        t.originCity.toLowerCase().includes(cleanOrigin.toLowerCase()) ||
        cleanOrigin.toLowerCase().includes(t.originCity.toLowerCase())
    );
    if (directForOrigin) {
      return {
        transport: directForOrigin,
        isAutoGeneratedCar: directForOrigin.type === 'car',
        hasDirectPublicTransport: directForOrigin.type === 'flight' || directForOrigin.type === 'bus',
      };
    }
  }

  // 2. Ako je "Svi gradovi" ili Beograd (glavno čvorište)
  if (!cleanOrigin || cleanOrigin === 'Svi gradovi' || cleanOrigin.toLowerCase() === 'beograd') {
    const defaultTr =
      pkg.transports.find((t) => t.id === pkg.defaultTransportId) || pkg.transports[0];
    return {
      transport: defaultTr,
      isAutoGeneratedCar: defaultTr.type === 'car',
      hasDirectPublicTransport: defaultTr.type === 'flight' || defaultTr.type === 'bus',
    };
  }

  // 3. Za bilo koji uneti grad koji NEMA direktan javni prevoz (npr. Vranje, Leskovac, Zagreb, Užice...)
  // Automatski kalkulišemo sopstveni prevoz (automobil):
  const distanceKm = calculateRoadDistanceKm(cleanOrigin, pkg.coordinates);
  const roundTripKm = distanceKm * 2;
  // Potrošnja ~7.2L/100km * 1.55€/L ≈ 0.11€/km + procenjene putarine
  const totalFuelAndTolls = Math.max(16, Math.round(roundTripKm * 0.12));
  const costPerPerson = Math.max(5, Math.round(totalFuelAndTolls / Math.max(1, persons)));
  const durationHours = Math.round((distanceKm / 75) * 10) / 10;

  const hasFlight = pkg.transports.some((t) => t.type === 'flight');
  const nearestHub = ['vranje', 'leskovac', 'pirot', 'prokuplje'].includes(cleanOrigin.toLowerCase())
    ? 'Niš'
    : ['zagreb', 'osijek', 'subotica', 'sombor'].includes(cleanOrigin.toLowerCase())
    ? 'Budimpešta / Beograd'
    : 'Beograd';

  const connectionHint = hasFlight
    ? ` Za letove za ${pkg.destinationName}, preporučujemo auto/bus do aerodroma (${nearestHub}), odakle polazi direktan let.`
    : '';

  const generatedCar: TransportOption = {
    id: `auto-car-${cleanOrigin.toLowerCase()}-${pkg.id}`,
    type: 'car',
    provider: `Sopstveni automobil (Polazak: ${cleanOrigin})`,
    originCity: cleanOrigin,
    destinationCity: pkg.destinationName,
    departureTime: 'Fleksibilno (po dogovoru)',
    arrivalTime: `Za ~${durationHours}h`,
    durationHours,
    pricePerPersonEUR: costPerPerson,
    returnDepartureTime: 'Fleksibilno',
    returnArrivalTime: 'Fleksibilno',
    baggageNote: 'Neograničen gepek za sve putnike u autu',
    isDirect: true,
    bookingNote: `Nema direktnog autobusa/leta iz mesta ${cleanOrigin}. Preporučujemo sopstveni automobil (~${distanceKm} km u jednom smeru, gorivo i putarine podeljeni na ${persons} putnika).${connectionHint}`,
  };

  return {
    transport: generatedCar,
    isAutoGeneratedCar: true,
    hasDirectPublicTransport: false,
    advisoryNote: `Nema direktnog javnog prevoza iz mesta ${cleanOrigin}. Proračunat je sopstveni prevoz automobilom (ušteda goriva i putarine na ${persons} putnika).`,
  };
}

/**
 * Kalkuliše troškove celog aranžmana:
 * - Ukupan trošak za dati broj osoba i noćenja
 * - Trošak po osobi
 * - Preostali novac od maksimalnog budžeta (za hranu, suvenire, lokalni prevoz)
 */
export function calculateTripFinancials(
  pkg: TravelPackage,
  selectedTransportId?: string,
  selectedAccommodationId?: string,
  nights?: number,
  persons = 2,
  userBudgetEUR = 200,
  originCity = 'Beograd'
) {
  const actualNights = nights ?? pkg.defaultNights;

  const { transport, isAutoGeneratedCar, hasDirectPublicTransport, advisoryNote } =
    resolveTransportForCity(pkg, originCity, persons, selectedTransportId);

  const accommodation =
    pkg.accommodations.find((a) => a.id === selectedAccommodationId) ||
    pkg.accommodations.find((a) => a.id === pkg.defaultAccommodationId) ||
    pkg.accommodations[0];

  // Prevoz je po osobi (povratna karta ili udeo u gorivu/putarini)
  const totalTransportCostEUR = (transport?.pricePerPersonEUR || 0) * persons;

  // Smeštaj je po sobi/apartmanu za date noći (pokriva navedeni broj osoba u apartmanu)
  const totalAccommodationCostEUR = (accommodation?.pricePerNightEUR || 0) * actualNights;

  // Ukupan obavezan trošak (Prevoz + Smeštaj)
  const totalBaseCostEUR = totalTransportCostEUR + totalAccommodationCostEUR;

  // Trošak po osobi
  const costPerPersonEUR = totalBaseCostEUR / persons;

  // Preporučeni džeparac (hrana, ulaznice, kafa)
  const recommendedSpendingTotalEUR =
    pkg.recommendedDailyBudgetEUR * actualNights * persons;

  // Preostalo od korisnikovog budžeta
  const remainingBudgetEUR = userBudgetEUR - totalBaseCostEUR;
  const isWithinBudget = totalBaseCostEUR <= userBudgetEUR;

  // Procena cene turističke agencije za ovakav aranžman
  const singleAgencyPrice = pkg.agencyBenchmarkPriceEUR || Math.round(costPerPersonEUR * 1.8);
  const totalAgencyCostEUR = singleAgencyPrice * persons;
  const savingsEUR = Math.max(0, totalAgencyCostEUR - totalBaseCostEUR);
  const savingsPercentage =
    totalAgencyCostEUR > 0 ? Math.round((savingsEUR / totalAgencyCostEUR) * 100) : 0;

  return {
    transport,
    accommodation,
    actualNights,
    persons,
    totalTransportCostEUR,
    totalAccommodationCostEUR,
    totalBaseCostEUR,
    costPerPersonEUR,
    recommendedSpendingTotalEUR,
    remainingBudgetEUR,
    isWithinBudget,
    isAutoGeneratedCar,
    hasDirectPublicTransport,
    advisoryNote,
    // Poređenje sa turističkim agencijama
    totalAgencyCostEUR,
    savingsEUR,
    savingsPercentage,
    totalAgencyCostRSD: Math.round(totalAgencyCostEUR * EUR_TO_RSD_RATE),
    savingsRSD: Math.round(savingsEUR * EUR_TO_RSD_RATE),
    // Proračuni u RSD
    totalBaseCostRSD: Math.round(totalBaseCostEUR * EUR_TO_RSD_RATE),
    costPerPersonRSD: Math.round(costPerPersonEUR * EUR_TO_RSD_RATE),
    remainingBudgetRSD: Math.round(remainingBudgetEUR * EUR_TO_RSD_RATE),
  };
}

/**
 * Filter funkcija prema parametrima koje korisnik unosi
 */
export function filterPackages(packages: TravelPackage[], filters: SearchFilters) {
  return packages
    .filter((pkg) => {
      // 1. Kategorija
      if (filters.category !== 'sve' && pkg.category !== filters.category) {
        return false;
      }

      // 2. Trajanje
      if (filters.durationType !== 'sve' && pkg.durationType !== filters.durationType) {
        return false;
      }

      // 3. Tip prevoza (ako korisnik izričito želi samo let ili samo autobus)
      if (filters.transportType !== 'sve') {
        const hasMatchingTransport = pkg.transports.some((t) => t.type === filters.transportType);
        if (!hasMatchingTransport) return false;
      }

      // 4. Mesto polaska i budžet provera
      // Za bilo koji grad polaska (Beograd, Niš, Vranje, Zagreb, Sofija...), računamo tačne troškove
      const financials = calculateTripFinancials(
        pkg,
        undefined,
        undefined,
        pkg.defaultNights,
        filters.persons,
        filters.maxBudgetEUR,
        filters.originCity
      );

      // Dopustamo prikaz i onih koji su do 15% iznad budžeta kako bi korisnik video opcije sa oznakom
      return financials.totalBaseCostEUR <= filters.maxBudgetEUR * 1.15;
    })
    .sort((a, b) => {
      const finA = calculateTripFinancials(
        a,
        undefined,
        undefined,
        a.defaultNights,
        filters.persons,
        filters.maxBudgetEUR,
        filters.originCity
      );
      const finB = calculateTripFinancials(
        b,
        undefined,
        undefined,
        b.defaultNights,
        filters.persons,
        filters.maxBudgetEUR,
        filters.originCity
      );

      if (filters.sortBy === 'price_asc') {
        return finA.totalBaseCostEUR - finB.totalBaseCostEUR;
      }
      if (filters.sortBy === 'savings_desc') {
        return finB.remainingBudgetEUR - finA.remainingBudgetEUR;
      }
      if (filters.sortBy === 'budget_fit') {
        return (
          Math.abs(filters.maxBudgetEUR - finA.totalBaseCostEUR) -
          Math.abs(filters.maxBudgetEUR - finB.totalBaseCostEUR)
        );
      }
      const ratingA = a.accommodations[0]?.rating || 8.0;
      const ratingB = b.accommodations[0]?.rating || 8.0;
      return ratingB - ratingA;
    });
}

/**
 * Ključna funkcija za zahtev:
 * „Gde mogu da otputujem za 150 €?“ (ili 100 €, 200 €, 300 €)
 */
export function getQuickBudgetHighlights(targetBudgetEUR = 150, persons = 1, originCity = 'Beograd') {
  return DEMO_PACKAGES.map((pkg) => {
    const fin = calculateTripFinancials(
      pkg,
      undefined,
      undefined,
      pkg.defaultNights,
      persons,
      targetBudgetEUR,
      originCity
    );
    return {
      package: pkg,
      financials: fin,
    };
  })
    .filter((item) => item.financials.totalBaseCostEUR <= targetBudgetEUR)
    .sort((a, b) => a.financials.totalBaseCostEUR - b.financials.totalBaseCostEUR);
}
