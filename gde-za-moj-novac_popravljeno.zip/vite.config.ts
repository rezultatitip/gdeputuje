import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, loadEnv} from 'vite';

export default defineConfig(({mode}) => {
  // Token čitamo iz .env / Secrets, nikad ne upisujemo u kod.
  const env = loadEnv(mode, process.cwd(), '');
  const duffelToken = env.DUFFEL_TOKEN;
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
      proxy: {
        '/api/duffel': {
          target: 'https://api.duffel.com',
          changeOrigin: true,
          secure: true,
          rewrite: (path) => path.replace(/^\/api\/duffel/, ''),
          headers: {
            ...(duffelToken ? {'Authorization': `Bearer ${duffelToken}`} : {}),
            'Duffel-Version': 'v2',
            'Accept': 'application/json',
          },
        },
      },
    },
  };
});
